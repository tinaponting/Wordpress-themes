<?php
/**
 * Plugin Name: Koalogger Addons
 * Plugin URI:  http://#
 * Description: Add functional for Koalogger Theme
 * Version:     1.0
 * Author:      AN2 studio
 * Author URI:  http://an2-studio.xyz
 * License:     GPL v3
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // exit if accessed directly
}

function disable_upload_sizes( $sizes, $metadata ) {
    // Get filetype data.
    $filetype = wp_check_filetype($metadata['file']);
    // Check if is gif. 
    if($filetype['type'] == 'image/gif') {
        // Unset sizes if file is gif.
        $sizes = array();
    }
    // Return sizes you want to create from image (None if image is gif.)
    return $sizes;
}   
add_filter('intermediate_image_sizes_advanced', 'disable_upload_sizes', 10, 2); 

/* Social share */
function koalogger_addon_css_and_js() {
    wp_register_style( 'koalogger_addon_style', plugins_url('/css/style.css',__FILE__ ) );
    wp_enqueue_style( 'koalogger_addon_style');
    wp_register_script( 'koalogger_addon_js', plugins_url('/js/social-likes.min.js',__FILE__ ), array('jquery'), '0.1', $in_footer = true );
    wp_enqueue_script( 'koalogger_addon_js' );
}
add_action( 'wp_enqueue_scripts', 'koalogger_addon_css_and_js' );

function koalogger_after_post_social( $content ) {
    if( is_single() ) {
        $soc_shares = '
        <div class="social-wrap">
            <div class="social-likes" data-counters="no">
                <div class="facebook"></div>
                <div class="twitter"></div>
                <div class="plusone"></div>
            </div>
            <span class="social-label">' . esc_html( 'Share', 'koalogger' ) . '</span>' . '
        </div>
        ';
        $fullcontent = $content . $soc_shares;
        return $fullcontent;
    } else {
        $fullcontent = $content;
        return $fullcontent;
    }
}
add_filter('wp_link_pages', 'koalogger_after_post_social');

// Get our data
function fetchData($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
function koalogger_instagram( $instagram_token, $instagram_id) {
	if ( $instagram_token != '' && $instagram_id != '' ){
        // Pull and parse data.
        $result = fetchData( "https://api.instagram.com/v1/users/{$instagram_id}/media/recent/?access_token={$instagram_token}" );
        $result = json_decode( $result );
        $limit = 10; // Amount of images to show
        $i = 0;

        foreach ( $result->data as $post ){
            if ( $i < $limit ){
                echo '<a class="insta-wrap__link" rel="nofollow" target="_blank" href="' . esc_url( $post->link ) . '">';
                echo '<img class="insta-wrap__image" src="' . esc_url( $post->images->low_resolution->url ) . '" alt="">';
                echo '</a>';
                $i ++;
            }
        }
    }
}

/* Shortcode */
function koalogger_cs_wide_block( $atts, $content ) {
    
    $atts = shortcode_atts( array(
        'cs_wide_block_title' => '',
        'cs_wide_block_image' => '',
        'cs_wide_block_content' => '',
        'cs_wide_block_link' => '',
    ), $atts );
    $wide_block_img = wp_get_attachment_image_src( $atts['cs_wide_block_image'], 'medium' );
    ob_start();
    echo '<div class="wide-block">
                <div class="wide-block-inner">
                    <div class="wide-block-img"><img src="' . $wide_block_img[0] . '" alt=""></div>
                    <div class="wide-block-content">
                        <div class="wide-block-title">' . $atts['cs_wide_block_title'] . '</div>
                        <div class="wide-block-text">' . $atts['cs_wide_block_content'] . '</div>
                        <a class="wide-block-link" href="' . $atts['cs_wide_block_link'] . '">' . esc_html( 'Read more', 'koalogger' ) . 
                        '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 7 9" style="enable-background:new 0 0 7 9;" xml:space="preserve">
<polygon points="7,4.5 0,0 0,9 "/>
</svg></a>
                    </div>
                </div>
            </div>';
    $output = ob_get_contents();
    ob_end_clean(); 
    return $output;
}
add_shortcode( 'cs_wide_block', 'koalogger_cs_wide_block' );

function koalogger_cs_button( $atts, $content ) {
    
    $atts = shortcode_atts( array(
        'cs_button_title' => esc_html__( 'Link', 'koalogger' ),
        'cs_button_link' => '',
        'cs_button_color' => '',
        'cs_button_color_hover' => '',
    ), $atts );
    ob_start();
    echo '<a class="shortcode-button" data-color="' . $atts['cs_button_color'] . '" data-hover="' . $atts['cs_button_color_hover'] . '" href="' . $atts['cs_button_link'] . '">' . $atts['cs_button_title'] . '</a>';
    $output = ob_get_contents();
    ob_end_clean(); 
    return $output;
}
add_shortcode( 'cs_button', 'koalogger_cs_button' );

/* Shortcode */
function koalogger_cs_faq( $atts, $content ) {
    $atts = shortcode_atts( array(
        'title' => '',
        'content' => '',
    ), $atts );
    return '<div class="faq-question notopen">' . $atts['title'] . '</div>'. '<div class="faq-answer">' . $content . '</div>';
}
add_shortcode( 'cs_faq', 'koalogger_cs_faq' );

/* Circle progress bar */
function koalogger_cs_circle( $atts, $content ) {
    $atts = shortcode_atts( array(
        'cs_circle_title' => '',
        'cs_circle_num' => '',
        'cs_circle_color' => '#f9f837',
    ), $atts );
    return '<div data-color="' . $atts['cs_circle_color'] . '" class="ko-progress-circle" data-progress="0" data-progress-finish="' . $atts['cs_circle_num'] . '">
                <div class="ko-progress-border"></div>
                <div class="ko-circle">
                    <div class="full ko-progress-circle__slice">
                    <div class="ko-progress-circle__fill"></div>
                </div>
                <div class="ko-progress-circle__slice">
                    <div class="ko-progress-circle__fill"></div>
                    <div class="ko-progress-circle__fill ko-progress-circle__bar"></div>
                </div>
                </div>
                <div class="ko-progress-circle__overlay">' . $atts['cs_circle_num'] . '</div>
                <div class="ko-progress-title">'. $atts['cs_circle_title'] .'</div>
            </div>';
}
add_shortcode( 'cs_circle_bar', 'koalogger_cs_circle' );

/* Widget */

/* Author widget */
add_action( 'widgets_init', 'koalogger_author_widget' );

// add js for author widget
add_action('admin_enqueue_scripts', 'koalogger_wdscript');
function koalogger_wdscript() {
    wp_enqueue_media();
    wp_enqueue_script('koalogger_addon_script', plugins_url('koalogger-addons') . '/js/widget.js', false, '1.0', true);
}

function koalogger_author_widget() {
    register_widget( 'koalogger_Author_Widget' );
}

class koalogger_Author_Widget extends WP_Widget {

    function __construct(){
        $widget_ops = array( 'classname' => 'author', 'description' => __('A widget that displays the authors info', 'koalogger') );
        
        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'koalogger-author-widget' );
        
        parent::__construct( 'koalogger-author-widget', __('Author Widget', 'koalogger'), $widget_ops, $control_ops );
    }
    
    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $bio = $instance['bio'];
        $nick = $instance['nick'];
        $photo = $instance['image_uri'];

        echo $before_widget;

        if ( $photo ){
            $photo_img = $instance['image_uri'];
            $path_info = pathinfo($photo_img);
            echo '<div class="avatar"><img src="' . esc_url( $path_info['dirname'] ) . '/' . esc_attr( $path_info['filename'] ) . '.' . esc_attr( $path_info['extension'] ) . '" alt="' . $title . '"></div>';
        }
        // Display the widget title 
        if ( $title ){
            echo $before_title . esc_attr( $title ) . $after_title;
        }
        //Display the nick 
        if ( $nick ){
            echo '<div class="nick"><p>' . esc_attr( $nick ) . '</p></div>';
        }

        //Display the name 
        if ( $bio ){
            echo '<div class="clear"></div>';
            echo '<div class="bio"><p>' . esc_attr( $bio ) . '</p></div>';
        }
        
        echo $after_widget;
    }

    //Update the widget 
     
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML 
        $instance['image_uri'] = strip_tags( $new_instance['image_uri'] );
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['bio'] = strip_tags( $new_instance['bio'] );
        $instance['nick'] = strip_tags( $new_instance['nick'] );

        return $instance;
    }

    
    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Your name', 'koalogger'), 'nick'=>'', 'bio' => __('Some bio text', 'koalogger'), 'image_uri' => __('', 'koalogger') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Your Name:', 'koalogger' ); ?></label>
            <input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>"><?php echo esc_html__( 'Your bio:', 'koalogger' ); ?></label>
            <textarea id="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bio' ) ); ?>" style="height:100px;width:100%;"><?php echo esc_attr( $instance['bio'] ); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'nick' ) ); ?>"><?php echo esc_html__( 'Your nickname:', 'koalogger' ); ?></label>
            <input id="<?php echo esc_attr( $this->get_field_id( 'nick' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'nick' ) ); ?>" value="<?php echo esc_attr( $instance['nick'] ); ?>" style="width:100%;" />
        </p>
        <p>
            <label style="display: block;" for="<?php echo esc_attr( $this->get_field_id( 'image_uri' ) ); ?>"><?php echo esc_html__( 'Your photo:', 'koalogger' ); ?></label>

            <?php
                if ( $instance['image_uri'] != '' ) :
                    echo '<img class="custom_media_image" src="' . esc_attr( $instance['image_uri'] ) . '" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" /><br />';
                endif;
            ?>
            <input type="text" class="widefat custom_media_url" name="<?php echo esc_attr( $this->get_field_name( 'image_uri' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'image_uri' ) ); ?>" value="<?php echo $instance['image_uri']; ?>" style="margin-top:5px;">
            <input type="button" class="button button-primary custom_media_button" id="custom_media_button" name="<?php echo esc_attr( $this->get_field_name( 'image_uri' ) ); ?>" value="<?php echo esc_html__( 'Upload photo', 'koalogger' ); ?>" style="margin-top:5px;" />
        </p>

    <?php
    }
}


function WPTime_get_soundcloud_track($url){ // Function By Qassim Hassan
 
    $transient_name = md5($url);
    $get_transient = "enter your client id";
 
    if ( empty( $get_transient ) ){
        $client_id = get_option('wptime_theme_soundcloud_api');
        $get = wp_remote_get("https://api.soundcloud.com/resolve.json?url=$url&client_id=$client_id");
        $retrieve = wp_remote_retrieve_body($get);
        $result = json_decode($retrieve, true);
 
        if( preg_match("/(errors)+/", $retrieve) ){
            return false;
        }
 
        $track_id = $result['id'];
 
        set_transient($transient_name, $track_id, 3600 * 24 * 30); // cache time is 1 month
        return $track_id;
    }
 
    else{
        return $get_transient;
    }
 
}