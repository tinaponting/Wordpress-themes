<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
// -----------------------------------------
// Post Metabox Options                    -
// -----------------------------------------

  $options[]    = array(
    'id'        => 'link_box',
    'title'     => esc_html__( 'Link options', 'koalogger' ),
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(

      array(
        'name'   => 'section_link',
        'fields' => array(
          array(
            'id'    => 'post_link',
            'type'  => 'text',
            'title' => esc_html__( 'Link to', 'koalogger' ),
            'desc'    => esc_html__( 'For example: https://www.google.com', 'koalogger' ),
          ),
          array(
            'id'    => 'post_link_text',
            'type'  => 'text',
            'title' => esc_html__( 'Link text', 'koalogger' ),
          ),
        ),
      ),

    ),
  );

  $options[]    = array(
    'id'        => 'video_box',
    'title'     => esc_html__( 'Video options', 'koalogger' ),
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(

      array(
        'name'   => 'section_video',
        'fields' => array(
          array(
            'id'      => 'video_service',
            'type'    => 'radio',
            'title'   => esc_html__( 'Video Service', 'koalogger' ),
            'options' => array(
              'youtube'   => 'Youtube',
              'vimeo'    => 'Vimeo',
            ),
          ),
          array(
            'id'    => 'video_link',
            'type'  => 'text',
            'title' => esc_html__( 'Link to video', 'koalogger' ),
            'desc'    => esc_html__( 'For example: https://www.youtube.com/watch?v=zc8hbSM1zVo or https://vimeo.com/22780182', 'koalogger' ),
          ),

        ),
      ),

    ),
  );

  $options[]    = array(
    'id'        => 'audio_box',
    'title'     => esc_html__( 'Audio options', 'koalogger' ),
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(

      array(
        'name'   => 'section_audio',
        'fields' => array(
          array(
            'id'    => 'audio_link',
            'type'  => 'text',
            'title' => esc_html__( 'Link to SoundCloud', 'koalogger' ),
            'desc'    => esc_html__( 'For example: https://soundcloud.com/carnivalyouth/octopus', 'koalogger' ),
          ),

        ),
      ),

    ),
  );

  $options[]    = array(
    'id'        => 'quote_box',
    'title'     => esc_html__( 'Quote options', 'koalogger' ),
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(

      array(
        'name'   => 'section_quote',
        'fields' => array(
          array(
            'id'    => 'quote_text',
            'type'  => 'textarea',
            'title' => esc_html__( 'Quote', 'koalogger' ),
          ),
          array(
            'id'    => 'quote_author',
            'type'  => 'text',
            'title' => esc_html__( 'Quote author', 'koalogger' ),
          ),

        ),
      ),

    ),
  );


$options[]    = array(
  'id'        => '_contact_page_options',
  'title'     => esc_html__( 'Contact page', 'koalogger' ),
  'post_type' => 'page',
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(
    array(
      'name'   => 'section_contacts',
      'fields' => array(
   
        array(
          'id'              => 'cont_attributes',
          'type'            => 'group',
          'title'           => esc_html__( 'Contacts attributes', 'koalogger' ),
          'button_title'    => esc_html__( 'Add new row', 'koalogger' ),
          'accordion_title' => esc_html__( 'Attributes row', 'koalogger' ),
          'fields'          => array(

            array(
              'id'    => 'cont_attribute_label',
              'type'  => 'text',
              'title' => esc_html__( 'Label', 'koalogger' ),
              'desc'  => esc_html__( 'For example: Address, email, etc.', 'koalogger' ),
            ),
            array(
              'id'    => 'cont_attribute_value',
              'type'  => 'text',
              'title' => esc_html__( 'Value', 'koalogger' ),
              'desc'  => esc_html__( 'For example: NY, JohnDoe@gmail.com', 'koalogger' ),
            ),

          ),
        ),
        array(
          'id'    => 'contact_form_shortcode',
          'type'  => 'textarea',
          'title' => esc_html__( 'Contact Form 7 shortcode', 'koalogger' ),
          'desc'  => esc_html__( 'For example: ', 'koalogger' ) . '[contact-form-7 id="1828" title="Contact form 1"]',
        ),
        array(
          'type'  => 'heading',
          'content' => esc_html__( 'Google map', 'pandafolio' ),
        ),
        array(
          'id'    => 'api_key',
          'type'  => 'text',
          'title' => esc_html__( 'Google map api key', 'pandafolio' ),
          'desc'  => esc_html__( 'Tutorail: https://www.youtube.com/watch?v=e3FQzh2qkjQ', 'pandafolio' ),
        ),
        array(
          'id'    => 'location',
          'type'  => 'google_map',// this type name must be same
          'title' => esc_html__( 'Google Map', 'koalogger' )
        ),
      ),

    ),
  ),
);



CSFramework_Metabox::instance( $options );