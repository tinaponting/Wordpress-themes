<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings		   = array(
  'menu_title'	  =>  esc_html__( 'Theme options', 'koalogger' ),
  'menu_type'	   => 'menu',
  'menu_slug'	   => 'cs-framework',
  'ajax_save'	   => false,
  'show_reset_all'  => false,
  'framework_title' => 'Codestar Framework <small>by Codestar</small>',
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options		= array();

// ----------------------------------------
// a option section for options overview  -
// ----------------------------------------

// ------------------------------
// General					    -
// ------------------------------
$options[]	  = array(
	'name'		=> 'general',
	'title'	   	=> esc_html__( 'General settings', 'koalogger' ),
	'icon'		=> 'fa fa-file-text-o',
	'fields'	=> array(
		array(
			'type'		=> 'heading',
			'content' 	=> esc_html__( 'Documentation', 'koalogger' ),
		),
		array(
		  	'type'    => 'notice',
		  	'class'   => 'info',
		  	'content' => esc_html__( 'Documentation', 'koalogger' ) . ' <a href="/wp-content/themes/koalogger/lib/doc/index.html" target="_blank">' . esc_html__( 'here', 'koalogger' ) . '</a>',
		),

		array(
			'type'		=> 'heading',
			'content' 	=> esc_html__( 'Common settings', 'koalogger' ),
		),
		/*
		array(
			'id'    => 'logo',
			'type'  => 'image',
			'title' => esc_html__( 'Logo', 'koalogger' ),
		),*/
		array(
			'type'		=> 'heading',
			'content' 	=> esc_html__( 'New logo settings. You could set logo ', 'koalogger' ) . '<a href="'. get_home_url().'/wp-admin/customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Dcs-framework">'. esc_html__( 'here', 'koalogger' ) . '</a>',
		),
		array(
		  'id'      => 'primary_color',
		  'type'    => 'color_picker',
		  'title'   => esc_html__( 'Primary color', 'koalogger' ),
		  'default' => '#fbed2c',
		),

		array(
			'type'		=> 'heading',
			'content' 	=> esc_html__( 'Slider on main page', 'koalogger' ),
		),
		array(
			'id'	  => 'banner_enable',
			'type'	=> 'switcher',
			'title'   => esc_html__( 'Show slider on home page?', 'koalogger' ),
			'default' => true
		),
		
		array(
		  'id'              => 'slider',
		  'type'            => 'group',
		  'title'           => esc_html__( 'Slider', 'koalogger' ),
		  'button_title'    => esc_html__( 'Add New slide', 'koalogger' ),
		  'accordion_title' => esc_html__( 'Fill fields', 'koalogger' ),
		  'dependency'   	=> array( 'banner_enable', '==', 'true' ),
		  'fields'          => array(
		  	array(
			  'id'        => 'slide_img',
			  'type'      => 'image',
			  'title'     => esc_html__( 'Slide image', 'koalogger' ),
			  'add_title' => esc_html__( 'Add image', 'koalogger' ),
			  
			),
		    array(
		      'id'    => 'slide_text',
		      'type'  => 'textarea',
		      'title' => esc_html__( 'Text on slide', 'koalogger' ),
		    ),
		    array(
			  'id'    => 'slide_color',
			  'type'  => 'color_picker',
			  'title' => esc_html__( 'Color of text', 'koalogger' ),
			  'default' => '#000',
			),
		  ),
		),

		
		array(
			'type'		=> 'heading',
			'content' 	=> esc_html__( 'Layout', 'koalogger' ),
		),
		array(
		  'id'         => 'layout',
		  'type'       => 'radio',
		  'title'      => esc_html__( 'Layouts', 'koalogger' ),
		  'options'    => array(
		    'one'    => esc_html__( '1 column', 'koalogger' ),
		    'two'     => esc_html__( '2 columns', 'koalogger' ),
		    'three'   => esc_html__( '3 columns', 'koalogger' ),
		  ),
		  'default'    => 'three'
		),
		array(
			'id'	  => 'meta_hide',
			'type'	=> 'switcher',
			'title'   => esc_html__( 'Hide post meta (comments, views) in posts list', 'koalogger' ),
			'default' => false
		),

		array(
			'type'		=> 'heading',
			'content' 	=> esc_html__( 'AJAX load posts', 'koalogger' ),
		),
		array(
			'id'	  => 'ajax_load',
			'type'	=> 'switcher',
			'title'   => esc_html__( 'Enable AJAX load posts', 'koalogger' ),
			'default' => false
		),


		array(
		  'type'    => 'notice',
		  'class'   => 'info',
		  'content' => ''
		),
				
		array(
			'type'	=> 'heading',
			'content' => esc_html__( 'Instagram', 'koalogger' ),
		),
		array(
		  'id'      => 'show-instagram',
		  'type'    => 'switcher',
		  'title'   => esc_html__( 'Show instagram before footer?', 'koalogger' ) . '<br><img src="' . get_template_directory_uri() . '/images/settings/insta.jpg" alt="">',
		  'default' => false
		),
		array(
			'id'    => 'instagram-name',
			'type'  => 'text',
			'title' => esc_html__( 'Fill your instagram name', 'koalogger' ),
		  	'dependency'   => array( 'show-instagram', '==', 'true' ),
		),
		array(
			'id'    => 'instagram-token',
			'type'  => 'text',
			'title' => esc_html__( 'Fill your instagram token', 'koalogger' ),
		  	'dependency'   => array( 'show-instagram', '==', 'true' ),
		),
		array(
			'id'    => 'instagram-id',
			'type'  => 'text',
			'title' => esc_html__( 'Fill your instagram user id', 'koalogger' ),
		  	'dependency'   => array( 'show-instagram', '==', 'true' ),
		),
		
	)
);

// ------------------------------
// Social settings 			    -
// ------------------------------
$options[]	  = array(
	'name'		=> 'social',
	'title'	   	=> esc_html__( 'Social settings', 'koalogger' ),
	'icon'		=> 'fa fa-facebook-official',
	'fields'	=> array(
		array(
		  	'id'      => 'enable_social',
		  	'type'    => 'switcher',
		  	'title'   => esc_html__( 'Enable social links in footer', 'koalogger' ),
		  	'default' => true
		),
		array(
			'id'      => 'facebook',
			'type'    => 'text',
			'title'   => esc_html__( 'Facebook link', 'koalogger' ),
			'dependency' => array( 'enable_social', '==', 'true' ),
			'desc'    => esc_html__( 'For example:', 'koalogger' ) . ' https://facebook.com/#'
		),
		array(
			'id'      => 'google_plus',
			'type'    => 'text',
			'title'   => esc_html__( 'Google+ link', 'koalogger' ),
			'dependency' => array( 'enable_social', '==', 'true' ),
			'desc'    => esc_html__( 'For example:', 'koalogger' ) . ' https://google.com/#'
		),
		array(
			'id'      => 'twitter',
			'type'    => 'text',
			'title'   => esc_html__( 'Twitter link', 'koalogger' ),
			'dependency' => array( 'enable_social', '==', 'true' ),
			'desc'    => esc_html__( 'For example:', 'koalogger' ) . ' https://twitter.com/#'
		),
		array(
			'id'      => 'instagram',
			'type'    => 'text',
			'title'   => esc_html__( 'Instagram link', 'koalogger' ),
			'dependency' => array( 'enable_social', '==', 'true' ),
			'desc'    => esc_html__( 'For example:', 'koalogger' ) . 'https://instagram.com/#'
		),
		array(
			'id'      => 'youtube',
			'type'    => 'text',
			'title'   => esc_html__( 'Youtube link', 'koalogger' ),
			'dependency' => array( 'enable_social', '==', 'true' ),
			'desc'    => esc_html__( 'For example:', 'koalogger' ) . 'https://youtube.com/#'
		),
		array(
			'id'      => 'dribbble',
			'type'    => 'text',
			'title'   => esc_html__( 'Dribbble link', 'koalogger' ),
			'dependency' => array( 'enable_social', '==', 'true' ),
			'desc'    => esc_html__( 'For example:', 'koalogger' ) . ' https://dribbble.com/#'
		),
		array(
			'id'      => 'pinterest',
			'type'    => 'text',
			'title'   => esc_html__( 'Pinterest link', 'koalogger' ),
			'dependency' => array( 'enable_social', '==', 'true' ),
			'desc'    => esc_html__( 'For example:', 'koalogger' ) . ' https://www.pinterest.com/#'
		),
	)
);





// ------------------------------
// backup					   -
// ------------------------------
$options[]   = array(
  'name'	 => 'backup_section',
  'title'	=> esc_html__( 'Backup', 'koalogger' ),
  'icon'	 => 'fa fa-shield',
  'fields'   => array(

	array(
	  'type'	=> 'notice',
	  'class'   => 'warning',
	  'content' => 'You can save your current options. Download a Backup and Import.',
	),

	array(
	  'type'	=> 'backup',
	),

  )
);


CSFramework::instance( $settings, $options );