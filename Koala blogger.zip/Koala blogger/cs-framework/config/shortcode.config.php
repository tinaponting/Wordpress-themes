<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// SHORTCODE GENERATOR OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options       = array();

//$shortcodes       = array();
// -----------------------------------------
// Advanced Shortcode                      -
// -----------------------------------------

$options[]     = array(
  'title'      => esc_html__( 'Shortcodes', 'koalogger' ),
  'shortcodes' => array(

    // begin: shortcode
      array(
        'name'      => 'cs_wide_block',
        'title'     => 'Insert wide block with link',
        'fields'    => array(
            array(
              'id'         => 'cs_wide_block_title',
              'type'       => 'text',
              'title'      => esc_html__( 'Title', 'koalogger' ),
            ),

            array(
              'id'         => 'cs_wide_block_image',
              'type'       => 'image',
              'title'      => esc_html__( 'Image', 'koalogger' ),
            ),

            array(
              'id'         => 'cs_wide_block_content',
              'type'       => 'textarea',
              'title'      => esc_html__( 'Text', 'koalogger' ),
            ),

            array(
              'id'         => 'cs_wide_block_link',
              'type'       => 'text',
              'title'      => esc_html__( 'Link', 'koalogger' ),
            ),
        )

      ),

      array(
          'name'      => 'cs_button',
          'title'     => 'Insert button',
          'fields'    => array(
              array(
                'id'         => 'cs_button_title',
                'type'       => 'text',
                'title'      => esc_html__( 'Title', 'koalogger' ),
              ),

              array(
                'id'         => 'cs_button_link',
                'type'       => 'text',
                'title'      => esc_html__( 'Link', 'koalogger' ),
              ),

              array(
                'id'      => 'cs_button_color',
                'type'    => 'color_picker',
                'title'   => esc_html__( 'Background color', 'koalogger' ),
                'default' => '#f9f837',
              ),

              array(
                'id'      => 'cs_button_color_hover',
                'type'    => 'color_picker',
                'title'   => esc_html__( 'Text color', 'koalogger' ),
                'default' => '#000',
              ),
          )

      ),

      array(
        'name'           => 'cs_faq',
        'title'          => esc_html__( 'FAQ Shortcode', 'koalogger' ),
        'view'           => 'clone_duplicate',
        'clone_title'    => esc_html__( 'Add New row', 'koalogger' ),
        'clone_fields'   => array(

          array(
            'id'         => 'title',
            'type'       => 'text',
            'title'      => esc_html__( 'Question', 'koalogger' ),
          ),

          array(
            'id'         => 'content',
            'type'       => 'textarea',
            'title'      => esc_html__( 'Answer', 'koalogger' ),
          ),

        )
      ),

      array(
          'name'      => 'cs_circle_bar',
          'title'     => 'Insert circular progress bar',
          'fields'    => array(
              array(
                'id'         => 'cs_circle_title',
                'type'       => 'text',
                'title'      => esc_html__( 'Title', 'koalogger' ),
              ),

              array(
                'id'         => 'cs_circle_num',
                'type'       => 'number',
                'title'      => esc_html__( 'percent (min = 0, max = 100)', 'koalogger' ),
                'attributes'    => array(
                  'max'   => 100,
                  'min' => 0,
                ),
              ),
              array(
                'id'      => 'cs_circle_color',
                'type'    => 'color_picker',
                'title'   => esc_html__( 'Progress bar color', 'koalogger' ),
                'default' => '#f9f837',
              ),
          )
      ),

    ),
    // end: shortcode

);

CSFramework_Shortcode_Manager::instance( $options );
