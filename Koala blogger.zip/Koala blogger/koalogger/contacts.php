<?php
/*
Template Name: Contacts
*/
get_header(); ?>
	<div class="article-content">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<?php
				if ( function_exists( 'cs_get_option' ) ){
					$contact_array = get_post_meta( get_the_ID(), '_contact_page_options', true );
					$location = $contact_array['location'];
					if ( $location['address'] != '' ){
						echo '<div id="map"></div>';
					}
				}
			?>
			<?php
				// Start the Loop.
				while ( have_posts() ) : the_post(); ?>
					<div class="post-content">
                        <div class="title">
                            <h1><?php the_title(); ?></h1>
                        </div>
					    <?php get_template_part( 'template-parts/content' ); ?>
					    <?php
					    	$extend = '';
							if ( function_exists( 'cs_get_option' ) ){
								$contact_array = get_post_meta( get_the_ID(), '_contact_page_options', true );
								if ( !empty( $contact_array['cont_attributes'] ) ) {
									echo '<div class="contact-info">';
									foreach ( $contact_array['cont_attributes'] as $cont_value ) {
										echo '<div>';
										echo '<strong>' . esc_html( $cont_value['cont_attribute_label'] ) . '</strong> ';
										echo esc_html( $cont_value['cont_attribute_value'] );
										echo '</div>';
									}
									echo '</div>';
								} else {
									$extend = 'extend';
								}

								$contact_shortcode = $contact_array['contact_form_shortcode'];
								if ( $contact_shortcode != '' ){
									echo '<div class="contact-form ' . esc_attr( $extend ) . '">';
									echo do_shortcode( $contact_shortcode );
									echo '</div>';
								}
							}
						?>
                    </div>
					
                    <?php
					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
				endwhile;
			?>
		</article>
	</div>
<?php get_footer(); ?>