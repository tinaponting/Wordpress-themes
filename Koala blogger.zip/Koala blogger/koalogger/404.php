<?php
/**
 * The template for displaying 404 pages (not found)
 */

get_header(); ?>
	<div class="wrap narrow">
		<div class="wrap-left">
			<div class="cat-title title">
				<h1><?php echo esc_html__( 'Page not found', 'koalogger' ); ?></h1>
			</div>
			<div class="wrap-404">
				<img src="<?php echo get_template_directory_uri(); ?>/images/404.gif" alt="<?php echo esc_html__( 'Page not found', 'koalogger' ); ?>">
				<div class="text-404">
					<?php echo esc_html__( 'Space invaders stole the page.', 'koalogger' ) . '<br>'. esc_html__( 'Try to find another :)', 'koalogger' ); ?>
					<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
						<input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'koalogger' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
						<button type="submit" class="search-submit"><span class="screen-reader-text"><?php echo _x( 'Search', 'submit button', 'koalogger' ); ?></span></button>
					</form>
				</div>
			</div>
		</div>
		<div class="wrap-right">
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>