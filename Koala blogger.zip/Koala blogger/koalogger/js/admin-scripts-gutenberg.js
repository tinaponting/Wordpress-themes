jQuery.noConflict();
(function( $ ) {
 	$(function() {
 		"use strict";
 		$(window).load(function () {
			var checkedFormat = $( '.editor-post-format select' ).val();
			$( '#video_box, #audio_box, #gallery_box, #quote_box, #link_box' ).css( 'display', 'none' );
			$( '#' + checkedFormat + '_box' ).css( 'display', 'block' );

			$( '#_contact_page_options' ).css( 'display', 'none' );
			var templateSelected = $( ".editor-page-attributes__template select" ).val();
			if ( templateSelected == 'contacts.php' ){
				$( '#_contact_page_options' ).css( 'display', 'block' );
			}
		});

 		
 		$( 'div.block-editor' ).on( 'change', '.editor-post-format select', function(){
 			var box = $( this ).val();
 			$( '#video_box, #audio_box, #gallery_box, #quote_box, #link_box' ).css( 'display', 'none' );
 			$( '#' + box + '_box' ).css( 'display', 'block' );
 		} );

		$( 'div.block-editor' ).on( 'change', '.editor-page-attributes__template select', function(){
			var templateSelected = $( this ).val();
			if ( templateSelected == 'contacts.php' ){
				$( '#_contact_page_options' ).css( 'display', 'block' );
			} else {
				$( '#_contact_page_options' ).css( 'display', 'none' );
			}
		} );
         


	});
})(jQuery);