jQuery.noConflict();
(function( $ ) {
 	$(function() {

		var $allVideos = $(".video-wrap iframe"),
		$fluidEl = $(".video-wrap");
		$allVideos.each(function() {
			$(this).attr('data-aspectRatio', this.height / this.width).removeAttr('height').removeAttr('width');
		});
		$(window).resize(function() {
			var newWidth = $fluidEl.width();
			$allVideos.each(function() {
				var $el = $(this);
				$el.width(newWidth).height(newWidth * $el.attr('data-aspectRatio')/1.5);
			});
		}).resize();
	});
})(jQuery);