jQuery.noConflict();
( function( $ ) {
    $( function() {
        'use strict';

        /* Post thumbnail */
        $( window ).load( function () {
            $( '.thumbnail-line-1' ).css( 'max-height', '100%' );
            $( '.thumbnail-line-2' ).css( 'max-height', '100%' );
            $( '.thumbnail-line-3' ).css( 'max-height', '100%' );
            var pageWidth = $( window ).width();
            if( $( '.img-thumb img' ).width() >= pageWidth ){
                setTimeout( function () {
                    $( '.img-thumb img' ).clone().css( 'width', pageWidth+20 ).appendTo( '.clone-1' );
                    $( '.img-thumb img' ).clone().css( 'width', pageWidth+20 ).appendTo( '.clone-2' );
                    $( '.img-thumb img' ).clone().css( 'width', pageWidth+20 ).appendTo( '.clone-3' );
                    $( '.img-thumb img' ).clone().css( 'width', pageWidth+20 ).appendTo( '.clone-4' );
                    $( '.clone-1, .clone-2, .clone-3, .clone-4' ).css( 'max-height', '100%' );
                }, 1000);
            } else {
                $('.thumbnail-line').hide();
            }
        });
        $( window ).resize(function() {
            var pageWidth = $(window).width();
            $( '.clone-1 img' ).css( 'width', pageWidth+20 );
            $( '.clone-2 img' ).css( 'width', pageWidth+20 );
            $( '.clone-3 img' ).css( 'width', pageWidth+20 );
            $( '.clone-4 img' ).css( 'width', pageWidth+20 );
        });

    });
})(jQuery);