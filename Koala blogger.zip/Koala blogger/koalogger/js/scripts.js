jQuery.noConflict();
( function( $ ) {
 	$( function() {
		'use strict';

		/* Masonry */
		$(window).load(function(){
			var hasCatList = $( '.item-list' ).length;
			if ( hasCatList > 0 ) {
				$( '.item-list' ).masonry({
					itemSelector: '.item-list article'
				});
			}
		});

        /* Footer to bottom */
        var footerH = $( '.site-footer' ).height();
        $( '.site-footer' ).css( 'margin-top', - footerH );
        $( '.main-wrap' ).css( 'padding-bottom', footerH );
        $( window ).resize(function() {
        	setTimeout( function(){
		        var footerH = $( '.site-footer' ).height();
		        $( '.site-footer' ).css( 'margin-top', - footerH );
		        $( '.main-wrap' ).css( 'padding-bottom', footerH );
		    },100);
	    });

        /* Menu */
        var navH = $( '.nav>div>ul' ).height();
        var windowH = $( window ).height();
        var heightDiff = windowH - navH;
        $('.nav>div>ul').css( 'margin', heightDiff/2 + 'px 0 0 0' );
        $('.nav>div>ul>li>ul').css( 'min-height', navH );
        $('.nav>div>ul>li>ul').each( function(){
        	var submenuH = $( this ).height();
        	$( this ).css( 'margin', - submenuH/2 + 'px 0 0 0' );
        });
        $( window ).resize(function() {
            var navH = $( '.nav .menu' ).height();
	        var windowH = $( window ).height();
	        var heightDiff = windowH - navH;
	        $('.nav>div>ul').css( 'margin', heightDiff/2 + 'px 0 0 0' );
	        $('.nav>div>ul>li>ul').each( function(){
	        	var submenuH = $( this ).height();
	        	$( this ).css( 'margin', - submenuH/2 + 'px 0 0 0' );
	        });
        });

        $( '.nav>div>ul>li>a' ).each( function(){
        	var navLiText = $( this ).text();
        	$( this ).attr( 'data-title', navLiText );
        });


		$('.nav>div>ul>li').hover( function(){
			$('.nav>div>ul>li ul').removeClass( 'opacity-show' ).addClass( 'opacity-hide' );
			$(this).find('ul').removeClass( 'opacity-hide' ).addClass( 'opacity-show' );
		}, function(){
			$('.nav>div>ul>li ul').removeClass( 'opacity-hide opacity-show' );
		});

		/* Burger menu for mobile */
		$( '.burger-menu' ).click( function(){
			$( '.nav' ).toggleClass( 'active' );
			$( this ).toggleClass('active');
		});

		/* Gallery */
		$( '.gallery .gallery-item a' ).each( function(){
			var dir = $( this ).attr( 'href' );
			if( dir.indexOf('upload') + 1 ) {
				  $( this ).addClass( 'colorbox' );
				$( this ).colorbox( {rel:'gal', height:"85%"} );
			}
		});		

		/* Shortcodes */       
        if ( $( '.wide-block' ).length > 0 ){
            var pageWidth = $( window ).width();
            var contentWidth = $( '.post-content' ).width();
            var widthDiff = pageWidth - contentWidth;
            $( '.wide-block').css( 'margin', '0px -' + widthDiff/2 + 'px' );
            $( window ).resize(function() {
	            var pageWidth = $( window ).width();
	            var contentWidth = $( '.post-content' ).width();
	            var widthDiff = pageWidth - contentWidth;
	            $( '.wide-block').css( 'margin', '0px -' + widthDiff/2 + 'px' );
	        });
        }
        if ( $( '.shortcode-button' ).length > 0 ){
        	$( '.shortcode-button' ).each( function(){
        		var background = $( this ).attr( 'data-color' );
        		var color = $( this ).attr( 'data-hover' );
        		$( this ).css( 'color', color ).css( 'background', background ).css( 'border-color', background );
        	});
        }
        $( '.site-content' ).on( 'click', '.faq-question.notopen', function(){
			$( '.faq-answer' ).hide();
			$( '.faq-question' ).addClass( 'notopen' ).removeClass( 'open' );
			$( this ).next( '.faq-answer' ).show();
			$( this ).removeClass( 'notopen' );
			$( this ).addClass( 'open' );
		});
		$( '.site-content' ).on( 'click', '.faq-question.open', function(){
			$( '.faq-answer' ).hide();
			$( '.faq-question' ).removeClass( 'open' ).addClass( 'notopen' );
			$( this ).removeClass( 'open' ).addClass( 'notopen' );
		});
		// Pregress bar
		if ( $( '.ko-progress-circle' ).length > 0 ){
			window.randomize = function() {
				$( '.ko-progress-circle' ).each(function(){
					var dataProgress = $(this).attr( 'data-progress-finish' );
					var dataColor = $(this).attr( 'data-color' );
					$( this ).attr( 'data-progress', dataProgress);
					$( this ).find( '.ko-progress-circle__fill' ).css( 'background', dataColor );
					$( this ).find( '.ko-progress-border' ).css( 'border-color', dataColor );
				});

			}
			$( '.ko-progress-circle' ).each(function(){
				var progressTop = $( this ).offset().top;
				if ( progressTop > windowH ){
					$(window).scroll(function () {
					    var scroll = $(window).scrollTop();
					    
					    if ( scroll > progressTop-800 ) {
					       	setTimeout(window.randomize, 200);
					    }
					});
				} else {
					setTimeout(window.randomize, 200);
				}
			});
		}

		/* Preloader */
		$( window ).load( function(){
			$( '.preloader' ).css( 'opacity', 0 );
			setTimeout( function(){
				$( '.preloader' ).hide();
			}, 200)
		});

		/* Video popup */
		$( '.video-wrap' ).on( 'click', function(){
			var videoURL = $( this ).find('.hover-play').attr( 'data-video' );
			$( '.video-popup, .mask' ).show();
			var videoW = $( '.video-popup' ).width();
			var videoH = $( '.video-popup' ).height();
			$( '.video-popup iframe' ).attr( 'src', videoURL ).height( videoH ).width( videoW );
		});
		$( '.mask, .close' ).on( 'click', function(){
			$( '.video-popup, .mask' ).hide();
			$( '.video-popup iframe' ).attr( 'src', '' ).height( 0 ).width( 0 );
		});

		/* AJAX loadmore */
		var ajaxurl = $( '.load-more' ).data( 'ajaxutl' );
		var load_posts = $( '.load-more' ).data( 'qvars' );
		var current_page = $( '.load-more' ).data( 'current' );
		var max_pages = $( '.load-more' ).data( 'max' );

		$( '#load-more' ).click( function(){
			$( this ).addClass( 'load' );
			var data = {
				'action': 'loadmore',
				'query': load_posts,
				'page' : current_page
			};
			$.ajax({
				url: ajaxurl,
				data: data,
				type: 'POST',
				success: function( data ){
					if( data ) { 
						$( '#load-more' ).removeClass( 'load' );
						$( '.item-list' ).append( data );
						$( '.item-list' ).masonry( 'destroy' );
						setTimeout(function(){
							$( '.item-list' ).masonry();
						}, 50);
						current_page++; // increase page number
						if ( current_page == max_pages ) $( '#load-more' ).remove(); // if last page
					} else {
						$( '#load-more' ).remove(); // if last page
					}
				}
			});

		});

	});
})(jQuery);
