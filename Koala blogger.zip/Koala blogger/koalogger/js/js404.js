jQuery.noConflict();
( function( $ ) {
 	$( function() {
		'use strict';
		var background404 = $( '.wrap-404' ).attr( 'data-bg' );
		$( '.error404' ).css( 'background-image', 'url(' + background404 + ')' );
	});
})(jQuery);
