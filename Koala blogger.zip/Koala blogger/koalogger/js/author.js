jQuery.noConflict();
( function( $ ) {
 	$( function() {
		'use strict';
		/* author's background */
		var userBackground = $( '.author-bio' ).attr( 'data-user' );
		$( '.author-bio' ).css( 'background-image', 'url(' + userBackground + ')' );
	});
})(jQuery);
