jQuery.noConflict();
(function( $ ) {
 	$(function() {
 		"use strict";
 		var checkedFormat = $( '#formatdiv #post-formats-select input:checked' ).val();
         
 		$( '#video_box, #audio_box, #gallery_box, #quote_box, #link_box' ).css( 'display', 'none' );
 		$( '#' + checkedFormat + '_box' ).css( 'display', 'block' );
 		
 		$( '#formatdiv #post-formats-select input' ).click( function(){
 			var box = $( this ).val();
 			$( '#video_box, #audio_box, #gallery_box, #quote_box, #link_box' ).css( 'display', 'none' );
 			$( '#' + box + '_box' ).css( 'display', 'block' );
 		} );
         
 		$( '#_custom_page_options' ).css( 'display', 'none' );
 		var templateSelected = $( "#page_template" ).val();
 		if ( templateSelected == 'contacts.php' ){
 			$( '#_custom_page_options' ).css( 'display', 'block' );
 		}
 		$( '#page_template' ).change( function() {
 			var templateSelected = $( "#page_template" ).val();
 			if ( templateSelected == 'contacts.php' ){
 				$( '#_custom_page_options' ).css( 'display', 'block' );
 			} else {
 				$( '#_custom_page_options' ).css( 'display', 'none' );
 			}
 		} );

        /* default */
        var templateSelected = $( "#page_template" ).val();
        if ( templateSelected == 'contacts.php' ){
            $( '#_contact_page_options' ).css( 'display', 'block' );
        } else {
            $( '#_contact_page_options' ).css( 'display', 'none' );
        }
        /* after change */
        $( '#page_template' ).change( function() {
            var templateSelected = $( "#page_template" ).val();
            if ( templateSelected == 'contacts.php' ){
                $( '#_contact_page_options' ).css( 'display', 'block' );
            } else {
                $( '#_contact_page_options' ).css( 'display', 'none' );
            }
        } );
	});
})(jQuery);