<?php
/**
 * The main template file
*/

get_header(); ?>
<?php 
	if ( function_exists( 'cs_get_option' ) ){
		$columns = cs_get_option( 'layout' );
		if( $columns == 'three' ){
			$layout = '';
			$wrap_class = '';
		} elseif ( $columns == 'two' ) {
			$layout = 'two-col';
			$wrap_class = '';
		} else {
			$layout = 'one-col';
			$wrap_class = 'narrow';
		}
	} else {
		$layout = '';
		$wrap_class = '';
	}
?>
	<div class="wrap <?php echo esc_attr( $wrap_class ); ?>">
		<div class="wrap-left">
			<?php if ( have_posts() ) : ?>
				<div class="video-popup">
					<div class="close"></div>
					<iframe width="640" height="480" allowFullScreen></iframe>
				</div>
				<div class="item-list <?php echo esc_attr( $layout ); ?>">
		            <?php 
		            	while ( have_posts() ) {
		            		the_post(); 

							get_template_part( 'loop' ); // include post murkup template
					
						}
					?>
				</div>
					<?php
						$args = array(
							'show_all'     => true,
							'end_size'     => 1,
							'mid_size'     => 1,
							'prev_next'    => true,
							'prev_text'    => '',
							'next_text'    => '',
							'add_args'     => false,
							'add_fragment' => '',
							'screen_reader_text' => '',
						);
						if ( function_exists( 'cs_get_option' ) ){
							/* if Ajax load post enabled */
							$ajax_load = cs_get_option( 'ajax_load' );
							if ( $ajax_load == 1 ) {
								$ajaxurl = site_url() . '/wp-admin/admin-ajax.php';
								$qvars = serialize( $wp_query->query_vars );
								$current_page = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
								$max_pages = $wp_query->max_num_pages;
								if (  $wp_query->max_num_pages > 1 ) { ?>
									<div data-ajaxutl="<?php echo esc_url( $ajaxurl ); ?>" data-qvars='<?php echo esc_attr( $qvars ); ?>' data-current="<?php echo esc_attr( $current_page ); ?>"  data-max="<?php echo esc_attr( $max_pages ); ?>" class="load-more" id="load-more">
										<?php echo esc_html( 'Load more', 'koalogger' ); ?>
										<img src="<?php echo esc_attr ( get_template_directory_uri() ); ?>/images/ajax.svg" alt="<?php echo esc_html( 'Load more', 'koalogger' ); ?>">
									</div>
								<?php }
							} else {
								the_posts_pagination( $args );
							}
						} else {
							the_posts_pagination( $args );
						}
					?>
				

			<?php endif; ?>
		</div>
		<div class="wrap-right">
			<?php get_sidebar(); ?>
		</div>
	</div>

<?php get_footer(); ?>