<?php 
    if ( function_exists( 'cs_get_option' ) ){
        $columns = cs_get_option( 'layout' );
        if( $columns == 'one' ){
            $post_thumb = get_the_post_thumbnail( get_the_ID(), 'koalogger_big' );
        } else {
            $post_thumb = get_the_post_thumbnail( get_the_ID(), 'koalogger_thumb' );
        }
    } else {
        $post_thumb = get_the_post_thumbnail( get_the_ID(), 'koalogger_thumb' );
    }
	$allowed_html_img = array(
		'img' => array(
			'width'  => true,
			'height' => true,
			'src' => true,
			'class' => true,
			'alt' => true,
			'srcset' => true,
			'sizes' => true,
		)
	);
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if( is_sticky() ){ ?>
        <div class="sticky-block">
        	<svg version="1.1" class="stick-post-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 53.867 53.867" style="enable-background:new 0 0 53.867 53.867;" xml:space="preserve">
            	<polygon style="fill:#000;" points="26.934,1.318 35.256,18.182 53.867,20.887 40.4,34.013 43.579,52.549 26.934,43.798 10.288,52.549 13.467,34.013 0,20.887 18.611,18.182 "/>
			</svg>
    	</div>
    <?php } ?>
    <?php 
        $post_format = get_post_format();
        if ( $post_format == 'video' ){ ?>
            <?php
                /* Video from Youtube or Vimeo */
                $video_data = get_post_meta( get_the_ID(), 'video_box', true );
                if ( !empty( $video_data ) ){
                    echo '<div class="video-wrap">';
                    $video_src = $video_data['video_link'];
                    if ( $video_data['video_service'] == 'youtube' ){
                        $video_ID = explode( '=', $video_src );
                        if ( has_post_thumbnail() ) {
                        	echo wp_kses( $post_thumb, $allowed_html_img );
                        	$has_thumb = 'has-thumb';
			            } else {
			            	$has_thumb = 'no-thumb';
			            }
                        echo '<svg class="default-play ' . esc_attr( $has_thumb ) . '" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 294.843 294.843" style="enable-background:new 0 0 294.843 294.843;" xml:space="preserve">
							<g>
								<path d="M278.527,79.946c-10.324-20.023-25.38-37.704-43.538-51.132c-2.665-1.97-6.421-1.407-8.392,1.257s-1.407,6.421,1.257,8.392
									c16.687,12.34,30.521,28.586,40.008,46.983c9.94,19.277,14.98,40.128,14.98,61.976c0,74.671-60.75,135.421-135.421,135.421
									S12,222.093,12,147.421S72.75,12,147.421,12c3.313,0,6-2.687,6-6s-2.687-6-6-6C66.133,0,0,66.133,0,147.421
									s66.133,147.421,147.421,147.421s147.421-66.133,147.421-147.421C294.842,123.977,289.201,100.645,278.527,79.946z"/>
								<path d="M109.699,78.969c-1.876,1.067-3.035,3.059-3.035,5.216v131.674c0,3.314,2.687,6,6,6s6-2.686,6-6V94.74l88.833,52.883
									l-65.324,42.087c-2.785,1.795-3.589,5.508-1.794,8.293c1.796,2.786,5.508,3.59,8.294,1.794l73.465-47.333
									c1.746-1.125,2.786-3.073,2.749-5.15c-0.037-2.077-1.145-3.987-2.93-5.05L115.733,79.029
									C113.877,77.926,111.575,77.902,109.699,78.969z"/>
							</g>
							</svg>';
						echo '<svg class="hover-play" data-video="https://www.youtube.com/embed/'. esc_attr( $video_ID[1] ) .'?autoplay=1" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 294.843 294.843" style="enable-background:new 0 0 294.843 294.843;" xml:space="preserve">
							<g>
								<path d="M278.527,79.946c-10.324-20.023-25.38-37.704-43.538-51.132c-2.665-1.97-6.421-1.407-8.392,1.257s-1.407,6.421,1.257,8.392
									c16.687,12.34,30.521,28.586,40.008,46.983c9.94,19.277,14.98,40.128,14.98,61.976c0,74.671-60.75,135.421-135.421,135.421
									S12,222.093,12,147.421S72.75,12,147.421,12c3.313,0,6-2.687,6-6s-2.687-6-6-6C66.133,0,0,66.133,0,147.421
									s66.133,147.421,147.421,147.421s147.421-66.133,147.421-147.421C294.842,123.977,289.201,100.645,278.527,79.946z"/>
								<path d="M109.699,78.969c-1.876,1.067-3.035,3.059-3.035,5.216v131.674c0,3.314,2.687,6,6,6s6-2.686,6-6V94.74l88.833,52.883
									l-65.324,42.087c-2.785,1.795-3.589,5.508-1.794,8.293c1.796,2.786,5.508,3.59,8.294,1.794l73.465-47.333
									c1.746-1.125,2.786-3.073,2.749-5.15c-0.037-2.077-1.145-3.987-2.93-5.05L115.733,79.029
									C113.877,77.926,111.575,77.902,109.699,78.969z"/>
							</g>
							</svg>';
                    } elseif ( $video_data['video_service'] == 'vimeo' ){
                        $video_ID = explode( '/', $video_src );
                        if ( has_post_thumbnail() ) {
	                        echo wp_kses( $post_thumb, $allowed_html_img );
                        	$has_thumb = 'has-thumb';
			            } else {
			            	$has_thumb = 'no-thumb';
			            }
                        echo '<svg class="default-play ' . esc_attr( $has_thumb )  . '" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 294.843 294.843" style="enable-background:new 0 0 294.843 294.843;" xml:space="preserve">
							<g>
								<path d="M278.527,79.946c-10.324-20.023-25.38-37.704-43.538-51.132c-2.665-1.97-6.421-1.407-8.392,1.257s-1.407,6.421,1.257,8.392
									c16.687,12.34,30.521,28.586,40.008,46.983c9.94,19.277,14.98,40.128,14.98,61.976c0,74.671-60.75,135.421-135.421,135.421
									S12,222.093,12,147.421S72.75,12,147.421,12c3.313,0,6-2.687,6-6s-2.687-6-6-6C66.133,0,0,66.133,0,147.421
									s66.133,147.421,147.421,147.421s147.421-66.133,147.421-147.421C294.842,123.977,289.201,100.645,278.527,79.946z"/>
								<path d="M109.699,78.969c-1.876,1.067-3.035,3.059-3.035,5.216v131.674c0,3.314,2.687,6,6,6s6-2.686,6-6V94.74l88.833,52.883
									l-65.324,42.087c-2.785,1.795-3.589,5.508-1.794,8.293c1.796,2.786,5.508,3.59,8.294,1.794l73.465-47.333
									c1.746-1.125,2.786-3.073,2.749-5.15c-0.037-2.077-1.145-3.987-2.93-5.05L115.733,79.029
									C113.877,77.926,111.575,77.902,109.699,78.969z"/>
							</g>
							</svg>';
						echo '<svg class="hover-play" data-video="https://player.vimeo.com/video/'. esc_attr( $video_ID[3] ) .'?autoplay=1" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 294.843 294.843" style="enable-background:new 0 0 294.843 294.843;" xml:space="preserve">
							<g>
								<path d="M278.527,79.946c-10.324-20.023-25.38-37.704-43.538-51.132c-2.665-1.97-6.421-1.407-8.392,1.257s-1.407,6.421,1.257,8.392
									c16.687,12.34,30.521,28.586,40.008,46.983c9.94,19.277,14.98,40.128,14.98,61.976c0,74.671-60.75,135.421-135.421,135.421
									S12,222.093,12,147.421S72.75,12,147.421,12c3.313,0,6-2.687,6-6s-2.687-6-6-6C66.133,0,0,66.133,0,147.421
									s66.133,147.421,147.421,147.421s147.421-66.133,147.421-147.421C294.842,123.977,289.201,100.645,278.527,79.946z"/>
								<path d="M109.699,78.969c-1.876,1.067-3.035,3.059-3.035,5.216v131.674c0,3.314,2.687,6,6,6s6-2.686,6-6V94.74l88.833,52.883
									l-65.324,42.087c-2.785,1.795-3.589,5.508-1.794,8.293c1.796,2.786,5.508,3.59,8.294,1.794l73.465-47.333
									c1.746-1.125,2.786-3.073,2.749-5.15c-0.037-2.077-1.145-3.987-2.93-5.05L115.733,79.029
									C113.877,77.926,111.575,77.902,109.699,78.969z"/>
							</g>
							</svg>';
                    }
                    echo '</div>';
                } else {
                	echo '<a href="' . get_permalink() . '" class="video-thumb">';
	                echo wp_kses( $post_thumb, $allowed_html_img );
                	echo '</a>';
                }
            ?>
            <h2>
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
            <div class="post-meta">
                <span class="post-date"><?php the_time(' F d,Y'); ?></span>
                    <span class="sep"><?php echo esc_html( '|', 'koalogger' ); ?></span>
                <span>
                    <img class="post-icon-eye" src="<?php echo get_template_directory_uri(); ?>/images/eye.svg" alt="post-views"><?php echo esc_attr( koalogger_get_post_views( get_the_ID() ) ); ?>
                </span>
                <span>
                    <img class="post-icon-comments" src="<?php echo get_template_directory_uri(); ?>/images/comments.svg" alt="post-comments"><?php comments_number( '0', '1', '%' ); ?>
                </span>
            </div>
            <?php the_excerpt(); ?>
        <?php } elseif ( $post_format == 'gallery' ) { ?>
        	<?php
        		$gal = get_post_gallery_images();
                if ( !empty( $gal ) ){
        			$img1 = $gal[0];
        			$img2 = $gal[1];
        			$img3 = $gal[2];
        			echo '<a class="gal-wrap" href="' . get_the_permalink() . '">';
        			if ( isset($img1) ){
        				echo '<img class="gal-img-1" src="' . esc_url( $img1 ) . '" alt="' . get_the_title() . '">';
        			}
        			if ( isset($img2) ){
        				echo '<img class="gal-img-2" src="' . esc_url( $img2 ) . '" alt="' . get_the_title() . '">';
        			}
        			if ( isset($img3) ){
        				echo '<img class="gal-img-3" src="' . esc_url( $img3 ) . '" alt="' . get_the_title() . '">';
        			}
        			echo '</a>';
        		} else { ?>
                    <a class="thumb-link" href="<?php the_permalink(); ?>">
                        <?php echo wp_kses( $post_thumb, $allowed_html_img ); ?>
                    </a>
                <?php }
        	?>
            <h2>
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
            <div class="post-meta">
                <span class="post-date"><?php the_time(' F d,Y'); ?></span>
                    <span class="sep"><?php echo esc_html( '|', 'koalogger' ); ?></span>
                <span>
                    <img class="post-icon-eye" src="<?php echo get_template_directory_uri(); ?>/images/eye.svg" alt="post-views"><?php echo esc_attr( koalogger_get_post_views( get_the_ID() ) ); ?>
                </span>
                <span>
                    <img class="post-icon-comments" src="<?php echo get_template_directory_uri(); ?>/images/comments.svg" alt="post-comments"><?php comments_number( '0', '1', '%' ); ?>
                </span>
            </div>
            <?php the_excerpt(); ?>
        <?php } elseif ( $post_format == 'audio') { ?>
            <div class="audio-inner">
                <?php
                    /* Audio from SoundCloud */
                    $audio_data = get_post_meta( get_the_ID(), 'audio_box', true );
                    if ( !empty( $audio_data ) ){
                        $audio_src = $audio_data['audio_link'];
                        global $wp_embed;
                        $iframe = $wp_embed->run_shortcode("[embed width='100%' height='100%']".$audio_src."[/embed]");
                        $iframe_parts_1 = explode('src="', $iframe);
                        $iframe_parts_2 = explode('">', $iframe_parts_1[1]);
                        echo '<iframe src="' . esc_url( $iframe_parts_2[0] ) . '"></iframe>';        
                    } else { ?>
                        <a class="thumb-link" href="<?php the_permalink(); ?>">
                            <?php echo wp_kses( $post_thumb, $allowed_html_img ); ?>
                        </a>
                    <?php }
                ?>
            </div>
            <h2>
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
            <div class="post-meta">
                <span class="post-date"><?php the_time(' F d,Y'); ?></span>
                    <span class="sep"><?php echo esc_html( '|', 'koalogger' ); ?></span>
                <span>
                    <img class="post-icon-eye" src="<?php echo get_template_directory_uri(); ?>/images/eye.svg" alt="post-views"><?php echo esc_attr( koalogger_get_post_views( get_the_ID() ) ); ?>
                </span>
                <span>
                    <img class="post-icon-comments" src="<?php echo get_template_directory_uri(); ?>/images/comments.svg" alt="post-comments"><?php comments_number( '0', '1', '%' ); ?>
                </span>
            </div>
        <?php } elseif ( $post_format == 'quote' ) { ?>
            <?php
                /* Quote */
                $qoute_data = get_post_meta( get_the_ID(), 'quote_box', true );
                if ( !empty( $qoute_data ) && $qoute_data['quote_text'] != '' ){
                    echo '<blockquote>';
                    echo '<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 191.029 191.029" style="enable-background:new 0 0 191.029 191.029;" xml:space="preserve">
                        <path d="M44.33,88.474v15.377h38.417v82.745H0v-82.745h0.002V88.474c0-31.225,8.984-54.411,26.704-68.918
                            C38.964,9.521,54.48,4.433,72.824,4.433v44.326C62.866,48.759,44.33,48.759,44.33,88.474z M181.107,48.759V4.433
                            c-18.343,0-33.859,5.088-46.117,15.123c-17.72,14.507-26.705,37.694-26.705,68.918v15.377h0v82.745h82.744v-82.745h-38.417V88.474
                            C152.613,48.759,171.149,48.759,181.107,48.759z"/>
                        </svg>' ;
                    echo '<div class="qoute-text">'. esc_html( $qoute_data['quote_text'] ) . '</div>';
                    if ( $qoute_data['quote_author'] != '' ){
                        echo '<h3 class="qoute-author"><a href="' . get_the_permalink() . '">' . esc_html( $qoute_data['quote_author'] ) . '</a></h3>';
                    } else {
                        echo '<h3 class="qoute-author"><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></h3>';
                    }
                    echo '</blockquote>';
                } else { ?>
                    <a class="thumb-link" href="<?php the_permalink(); ?>">
                        <?php echo wp_kses( $post_thumb, $allowed_html_img ); ?>
                    </a>
                    <h2>
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h2>
                    <div class="post-meta">
                        <span class="post-date"><?php the_time(' F d,Y'); ?></span>
                            <span class="sep"><?php echo esc_html( '|', 'koalogger' ); ?></span>
                        <span>
                            <img class="post-icon-eye" src="<?php echo get_template_directory_uri(); ?>/images/eye.svg" alt="post-views"><?php echo esc_attr( koalogger_get_post_views( get_the_ID() ) ); ?>
                        </span>
                        <span>
                            <img class="post-icon-comments" src="<?php echo get_template_directory_uri(); ?>/images/comments.svg" alt="post-comments"><?php comments_number( '0', '1', '%' ); ?>
                        </span>
                    </div>
                    <?php the_excerpt(); ?>
                <?php }
            ?>
        <?php } elseif ( $post_format == 'link' ) { ?>
            <a class="link-inner" href="<?php the_permalink(); ?>">
            	<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 54.971 54.971" style="enable-background:new 0 0 54.971 54.971;" xml:space="preserve">
					<g>
						<path d="M51.173,3.801c-5.068-5.068-13.315-5.066-18.384,0l-9.192,9.192c-0.781,0.781-0.781,2.047,0,2.828
							c0.781,0.781,2.047,0.781,2.828,0l9.192-9.192c1.691-1.69,3.951-2.622,6.363-2.622c2.413,0,4.673,0.932,6.364,2.623
							s2.623,3.951,2.623,6.364c0,2.412-0.932,4.672-2.623,6.363L36.325,31.379c-3.51,3.508-9.219,3.508-12.729,0
							c-0.781-0.781-2.047-0.781-2.828,0s-0.781,2.048,0,2.828c2.534,2.534,5.863,3.801,9.192,3.801s6.658-1.267,9.192-3.801
							l12.021-12.021c2.447-2.446,3.795-5.711,3.795-9.192C54.968,9.512,53.62,6.248,51.173,3.801z"/>
						<path d="M27.132,40.57l-7.778,7.778c-1.691,1.691-3.951,2.623-6.364,2.623c-2.412,0-4.673-0.932-6.364-2.623
							c-3.509-3.509-3.509-9.219,0-12.728L17.94,24.306c1.691-1.69,3.951-2.622,6.364-2.622c2.412,0,4.672,0.932,6.363,2.622
							c0.781,0.781,2.047,0.781,2.828,0s0.781-2.047,0-2.828c-5.067-5.067-13.314-5.068-18.384,0L3.797,32.793
							c-2.446,2.446-3.794,5.711-3.794,9.192c0,3.48,1.348,6.745,3.795,9.191c2.446,2.447,5.711,3.795,9.191,3.795
							c3.481,0,6.746-1.348,9.192-3.795l7.778-7.778c0.781-0.781,0.781-2.047,0-2.828S27.913,39.789,27.132,40.57z"/>
					</g>
				</svg>
                <h3><?php the_title(); ?></h3>
            </a>
        <?php } else { ?>
            <a class="thumb-link" href="<?php the_permalink(); ?>">
                <?php echo wp_kses( $post_thumb, $allowed_html_img ); ?>
            </a>
            <h2>
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
            <div class="post-meta">
                <span class="post-date"><?php the_time(' F d,Y'); ?></span>
                    <span class="sep"><?php echo esc_html( '|', 'koalogger' ); ?></span>
                <span>
                    <img class="post-icon-eye" src="<?php echo get_template_directory_uri(); ?>/images/eye.svg" alt="post-views"><?php echo esc_attr( koalogger_get_post_views( get_the_ID() ) ); ?>
                </span>
                <span>
                    <img class="post-icon-comments" src="<?php echo get_template_directory_uri(); ?>/images/comments.svg" alt="post-comments"><?php comments_number( '0', '1', '%' ); ?>
                </span>
            </div>
            <?php the_excerpt(); ?>
        <?php }
    ?>
</article>