<?php
/**
 * The template for displaying comments
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">
    <div class="comments-title">
		<?php
		$comments_count = get_comments_number();
		if ( $comments_count != 0 ){
			$comments_number = $comments_count;
		} else {
			$comments_number = '0';
		}
		echo esc_html__( 'Comments', 'koalogger' ) . ' (' . esc_attr( $comments_number ) . ')';
		?>
    </div>
	<?php if ( have_comments() ) { ?>
        <ol class="comment-list">
			<?php wp_list_comments('avatar_size=86&type=all&callback=koalogger_comment'); ?>
        </ol><!-- .comment-list -->

		<?php
			$args_comments = array(
				'next_text' => esc_html( '<span>&larr;</span> ', 'koalogger') . esc_html__( 'Newer comments', 'koalogger' ),
				'prev_text' => esc_html__( 'Older comments', 'koalogger' ) . esc_html(' <span>&rarr;</span>', 'koalogger' ),
				'screen_reader_text' => '',
			);
			the_comments_navigation( $args_comments );
			$comments_pagination_args = array(
				'next_text' => '',
				'prev_text' => '',
			);
			the_comments_pagination( $comments_pagination_args );
		?>

	<?php } // Check for have_comments(). ?>

	<?php
	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) {
		?>
        <p class="no-comments"><?php esc_html__( 'Comments are closed.', 'koalogger' ); ?></p>
	<?php } ?>

	<?php
	$req      = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );
	$html_req = ( $req ? " required='required'" : '' );
	comment_form( array(
		'title_reply_before' => '<div id="reply-title" class="comment-reply-title">',
		'title_reply_after'  => '</div>',
		'cancel_reply_link'    => esc_html__( 'Cancel reply', 'koalogger' ),
		'label_submit'         => esc_html__( 'Add comment', 'koalogger' ),
		'fields'               => array(
			'author' => '<div class="comment-field-wrap">
								<p class="comment-field comment-form-author">
								<input placeholder="' . esc_html__('Your name', 'koalogger') . '" id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" ' . $aria_req . $html_req . ' />
								</p>',
			'email'  => '<p class="comment-field comment-form-email">
								<input placeholder="' . esc_html__('Your e-mail', 'koalogger') . '" id="email" name="email" type="email" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" aria-describedby="email-notes"' . $aria_req . $html_req  . ' />
								</p>',
			'url'    => '<p class="comment-field comment-form-url">
								<input placeholder="' . esc_html__('Your website', 'koalogger') . '" id="url" name="url" type="url" value="' . esc_attr( $commenter['comment_author_url'] ) . '" />
								</p>
								</div>',
		),
		'comment_field' => '<p class="comment-form-comment">
									<textarea placeholder="' . esc_html__('Your comment', 'koalogger') . '" id="comment" name="comment" aria-required="true"></textarea>
									</p>',
	) );
	?>



</div><!-- .comments-area -->
