<?php
	$post_tags = get_the_tag_list();
	if ( $post_tags != '' ) {
		echo '<div class="post-tags">';
		echo wp_kses( $post_tags, 'default' );
		echo '</div>';
	}