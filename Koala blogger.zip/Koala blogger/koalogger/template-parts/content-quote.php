<?php
	/* Quote */
	$qoute_data = get_post_meta( get_the_ID(), 'quote_box', true );
	if ( !empty( $qoute_data ) && $qoute_data['quote_text'] != '' ){
		echo '<blockquote>';
		echo '<div class="qoute-text">'. esc_attr( $qoute_data['quote_text'] ) . '</div>';
		echo '<div class="qoute-author">'. esc_attr( $qoute_data['quote_author'] ) . '</div>';
		echo '</blockquote>';
	}
?>
<?php
	/* Main text */
	the_content();
?>