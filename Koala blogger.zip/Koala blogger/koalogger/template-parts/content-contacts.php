<div class="post-content">
	<?php
		$contact_shortcode_array = get_post_meta( get_the_ID(), '_custom_page_options', true );
		$contact_shortcode = $contact_shortcode_array['contact_form_shortcode'];
		$contact_extend = '';
		if ( $contact_shortcode == '' ){
			$contact_extend = 'extend';
		}
	?>
	<div class="contact-text <?php echo esc_attr( $contact_extend ); ?>">
		<?php
			/* Main text */
			the_content();
		?>
	</div>
	<?php if ( $contact_shortcode != '' ){ ?>
		<div class="contact-form">
			<?php
				echo do_shortcode( $contact_shortcode );
			?>
		</div>
	<?php } ?>
</div>