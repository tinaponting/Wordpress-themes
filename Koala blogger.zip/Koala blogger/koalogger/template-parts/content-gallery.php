<?php
	/* Main text */
	the_content();
?>