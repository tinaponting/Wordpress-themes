<?php
	/* Video from Youtube or Vimeo */
	$video_data = get_post_meta( get_the_ID(), 'video_box', true );
	if ( !empty( $video_data ) ){
		echo "<div class='video-wrap'>";
		$video_src = $video_data['video_link'];
		if ( $video_data['video_service'] == 'youtube' ){
			$video_ID = explode( '=', $video_src );
			echo '<iframe width="640" height="480" src="https://www.youtube.com/embed/'. esc_attr( $video_ID[1] ) .'" allowFullScreen></iframe>';
		} elseif ( $video_data['video_service'] == 'vimeo' ){
			$video_ID = explode( '/', $video_src );
			echo '<iframe width="640" height="480" src="https://player.vimeo.com/video/'. esc_attr( $video_ID[3] ) .'" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
		}
		echo "</div>";
	} else {
		the_post_thumbnail('post_me_featured');
	}
?>
<?php
	/* Main text */
	the_content();
?>