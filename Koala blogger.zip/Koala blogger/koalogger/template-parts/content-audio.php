<?php
	$allowed_html_audio = array(
		'iframe' => array(
			'src' => true
		)
	);
	/* Audio from SoundCloud */
	$audio_data = get_post_meta( get_the_ID(), 'audio_box', true );
	if ( !empty( $audio_data ) ){
		$audio_src = $audio_data['audio_link'];
		if ($audio_src != '' ){
			global $wp_embed;
			echo wp_kses( $wp_embed->run_shortcode("[embed]".$audio_src."[/embed]"), $allowed_html_audio );
		}
	} else {
		the_post_thumbnail('post_me_featured');
	}

	/* Main text */
	the_content();
