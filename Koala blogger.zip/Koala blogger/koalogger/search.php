<?php
/**
 * The template for displaying search results pages
 */

get_header(); ?>
	<div class="wrap narrow">
		<div class="wrap-left">
			<div class="cat-title title">
				<h1><?php echo esc_html__( 'Search Results for: ', 'koalogger' ). esc_html( get_search_query() ); ?></h1>
			</div>
			<?php if ( have_posts() ) { ?>
				<div class="video-popup">
					<div class="close"></div>
					<iframe width="640" height="480" allowFullScreen></iframe>
				</div>
				<div class="item-list one-col">
		            <?php 
		            	while ( have_posts() ) {
		            		the_post(); 

							get_template_part( 'loop' ); // include post murkup template
					
						}
					?>
				</div>
					<?php
						$args = array(
							'show_all'     => true,
							'end_size'     => 1,
							'mid_size'     => 1,
							'prev_next'    => true,
							'prev_text'    => '',
							'next_text'    => '',
							'add_args'     => false,
							'add_fragment' => '',
							'screen_reader_text' => '',
						);
						the_posts_pagination( $args );
					?>
				

			<?php } else { ?>
				<div class="wrap-404">
					<img src="<?php echo get_template_directory_uri(); ?>/images/404.gif" alt="<?php echo esc_html__( 'Nothing found', 'koalogger' ); ?>">
					<div class="text-404">
						<?php echo esc_html__( 'Nothing found', 'koalogger' ); ?>
						<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
							<input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'koalogger' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
							<button type="submit" class="search-submit"><span class="screen-reader-text"><?php echo _x( 'Search', 'submit button', 'koalogger' ); ?></span></button>
						</form>
					</div>
				</div>
			<?php } ?>
		</div>
		<div class="wrap-right">
			<?php get_sidebar(); ?>
		</div>
	</div>

<?php get_footer(); ?>