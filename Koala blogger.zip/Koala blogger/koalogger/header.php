<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="index, follow">
	<meta name="googlebot" content="index, follow">
    <meta name="google-site-verification" content="kLvhKyIJkezrG1NpwHl_-J3umvc7DkNA9bt06y0S3Xo" />
     <meta name="author" content="Kristina Ponting">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php
		if (function_exists( 'cs_get_option' ) ){
			$primary_color = cs_get_option( 'primary_color' );
		} else {
			$primary_color = '#fbed2c';
		}
	?>
	<meta name="msapplication-TileColor" content="<?php echo esc_attr( $primary_color ); ?>">
	<meta name="theme-color" content="<?php echo esc_attr( $primary_color ); ?>">
	<?php wp_head(); ?>
</head>
<!-- TrustBox script -->
<script type="text/javascript" src="//widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js"async></script>
<!-- End TrustBox script -->
<body <?php body_class(); ?>>
<script src="./fuckdevtools.js"></script>		
<div class="preloader"></div>
<div class="main-wrap">
	<div class="mask"></div>
	<div class="main">
		<header class="site-header">
			<?php
				if( has_custom_logo() ){
					$header_logo_id = get_theme_mod( 'custom_logo' );
					$header_logo_src = wp_get_attachment_image_src( $header_logo_id, 'koalogger_logo' );
					if ( $header_logo_id != '' ){
						$logo_src = $header_logo_src[0];
					} else {
						$logo_src = get_template_directory_uri()."/images/logo.svg";
					}
				} else {
					$logo_src = get_template_directory_uri()."/images/logo.svg";
				}

				$sitename = get_bloginfo('name');
			?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo">
					<img src="<?php echo esc_url( $logo_src ); ?>" alt="<?php echo esc_attr( $sitename ); ?>">
				</a>
			<div class="burger-menu"></div>
			<nav class="nav">
				<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
			</nav>

		</header><!-- .site-header -->
		<div class="site-content">
		<?php
			if ( function_exists( 'cs_get_option' ) && is_front_page() ){
			 	$show_slider = cs_get_option( 'banner_enable' );
			 	$slider = cs_get_option( 'slider' );
			 	$sitename = get_bloginfo('name');
				if ( $show_slider == '1' && !empty( $slider ) ){ ?>
					<div class="banner-wrap">
						<div class="owl-carousel main-slider">
							<?php
							foreach ( $slider as $slide ) {
								$slide_img_id = $slide['slide_img'];
								$slide_img = wp_get_attachment_image_src( $slide_img_id, 'koalogger_big' );
								$slide_text = $slide['slide_text'];
								$slide_color = $slide['slide_color'];						
							?>
								<div class="item">
									<img class="main-slider__bg" src="<?php echo esc_attr( $slide_img[0] ); ?>" alt="<?php echo esc_attr( $sitename ); ?>" title="<?php echo esc_attr( $sitename ); ?>">
									<div class="main-slider__description" data-slidecolor="<?php echo esc_attr( $slide_color ); ?>">
										<?php if( $slide_text != '' ){ 
							    			echo '<pre>';
							    			echo esc_attr( $slide_text );
							    			echo '</pre>';
										} ?>
							    	</div>
								</div>
							<?php } ?>
						</div>
						<canvas id="wave"></canvas>
					</div>
				<?php
				} else {
					if ( is_front_page() ){
						echo '<div class="space"></div>';
					}
				}
			} else {
				if ( is_front_page() ){
					echo '<div class="space"></div>';
				}
			}
		?>