<?php
/**
 * The template for displaying image attachments
*/

get_header(); ?>

	<div class="article-content">

			<?php
				// Start the loop.
				while ( have_posts() ) { the_post();
			?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

					<div class="no-thumbnail-wrap"></div>      
					<div class="post-content">
							<div class="title">
	                            <h1><?php the_title(); ?></h1>
	                        </div>
							<?php
								/**
								 * Filter the default post-me image attachment size.
								 *
								 */
								$image_size = apply_filters( 'post-me_attachment_size', 'large' );

								echo wp_get_attachment_image( get_the_ID(), $image_size );
							?>

							<?php the_excerpt( 'entry-caption' ); ?>

							<?php
								// If comments are open or we have at least one comment, load up the comment template.
								if ( comments_open() || get_comments_number() ) {
									comments_template();
								}
							?>
					</div>


				</article>

				<?php
				}
			?>

	</div>
<?php get_footer(); ?>