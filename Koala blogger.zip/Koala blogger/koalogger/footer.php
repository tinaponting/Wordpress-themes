<?php
/**
 * The template for displaying the footer
 */
?>
		</div><!-- .site-content -->
	</div><!-- .main -->
</div><!-- .wrap -->
<div class="site-footer">
	<?php if ( function_exists( 'cs_get_option' ) ){
		$show_instagram = cs_get_option( 'show-instagram' );
		$instagram_token = cs_get_option( 'instagram-token' );
		$instagram_id = cs_get_option( 'instagram-id' );
		$instagram_name = cs_get_option( 'instagram-name' );
		if ( $show_instagram == '1' && $instagram_token !='' && $instagram_id != '' ) { ?>
            <div class="insta-wrap">
				<?php if ( $instagram_name !='' ) { ?>
                    <div class="insta-wrap__title"><?php echo esc_html( $instagram_name ); ?></div>
				<?php } ?>
				<?php koalogger_instagram( $instagram_token, $instagram_id ); ?>
            </div>
		<?php }
	} ?>
    <div class="footer-columns">
        <div class="footer-col">
	        <?php dynamic_sidebar( 'footer-1' ); ?>
        </div>
        <div class="footer-col">
		    <?php dynamic_sidebar( 'footer-2' ); ?>
        </div>
        <div class="footer-col">
		    <?php dynamic_sidebar( 'footer-3' ); ?>
        </div>
        <div class="footer-col footer-col-last">
		    <?php dynamic_sidebar( 'footer-4' ); ?>
		    <?php 
		    	if ( function_exists( 'cs_get_option' ) ){
						$show_social = cs_get_option( 'enable_social' );
						if ( $show_social == '1' ) {
							$facebook = cs_get_option( 'facebook' );
							$twitter = cs_get_option( 'twitter' );
							$instagram = cs_get_option( 'instagram' );
							$youtube = cs_get_option( 'youtube' );
							$dribbble = cs_get_option( 'dribbble' );
							$pinterest = cs_get_option( 'pinterest' ); ?>
							<div class="widget">
								<div class="networks">
									<?php if ( $facebook != '' ){ ?>
										<a href="<?php echo esc_url( $facebook ); ?>" class="networks__facebook" rel="follow" target="_blank"></a>
									<?php } ?>
									<?php if ( $twitter != '' ){ ?>
										<a href="<?php echo esc_url( $twitter ); ?>" class="networks__twitter" rel="follow" target="_blank"></a>
									<?php } ?>
									<?php if ( $instagram != '' ){ ?>
										<a href="<?php echo esc_url( $instagram ); ?>" class="networks__instagram" rel="follow" target="_blank"></a>
									<?php } ?>
									<?php if ( $youtube != '' ){ ?>
										<a href="<?php echo esc_url( $youtube ); ?>" class="networks__youtube" rel="follow" target="_blank"></a>
									<?php } ?>
									<?php if ( $dribbble != '' ){ ?>
										<a href="<?php echo esc_url( $dribbble ); ?>" class="networks__dribbble" rel="follow" target="_blank"></a>
									<?php } ?>
									<?php if ( $pinterest != '' ){ ?>
										<a href="<?php echo esc_url( $pinterest ); ?>" class="networks__pinterest" rel="follow" target="_blank"></a>
									<?php } ?>
								</div>
							</div>
				<?php } 
				}
			?>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>