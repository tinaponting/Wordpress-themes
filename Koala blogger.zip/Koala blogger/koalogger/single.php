<?php
/**
 * The template for displaying all single posts and attachments
 */

get_header(); ?>
	<div class="article-content">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<?php
				// Start the Loop.
				while ( have_posts() ) { the_post();
					koalogger_set_post_views( get_the_ID() ); // view counter
					$post_format = get_post_format(); ?>
                    <?php if ( has_post_thumbnail()) { ?>
                        <div class="thumbnail-wrap">
                                <span class="thumbnail-line thumbnail-line-1"></span>
                                <span class="thumbnail-line thumbnail-line-2"></span>
                                <span class="thumbnail-line thumbnail-line-3"></span>
                                <div class="img-thumb">
                                    <?php the_post_thumbnail('koalogger_big'); ?>
                                </div>
                                <div class="clone clone-1"></div>
                                <div class="clone clone-2"></div>
                                <div class="clone clone-3"></div>
                                <div class="clone clone-4"></div>
                        </div>
                    <?php } else { ?>
                        <div class="no-thumbnail-wrap"></div>                 
                    <?php } ?>                        
                    <div class="post-content">
                        <div class="post-meta">
                            <?php
                                $cats = get_the_category();
                                foreach ( $cats as $cat ) {
                                    echo '<a class="post-cat" href="' . get_category_link( $cat->term_id ) . '">' . esc_html( $cat->name ) . '</a>';
                                }
                            ?>
                            <div class="single-post-meta">
                                <span class="post-date"><?php the_time(' F d,Y'); ?></span>
                                <span class="sep"><?php echo esc_html( '|', 'koalogger' ); ?></span>
                                <span class="post-meta-span">
                                    <img class="post-icon-eye" src="<?php echo get_template_directory_uri(); ?>/images/eye.svg" alt="post-views"><?php echo esc_attr( koalogger_get_post_views( get_the_ID() ) ); ?>
                                </span>
                                <span class="post-meta-span">
                                    <img class="post-icon-comments" src="<?php echo get_template_directory_uri(); ?>/images/comments.svg" alt="post-comments"><?php comments_number( '0', '1', '%' ); ?>
                                </span>
                            </div>
                        </div>
                        <div class="title">
                            <h1><?php the_title(); ?></h1>
                        </div>
                        <?php if ( $post_format == '' ){
                                get_template_part( 'template-parts/content' );
                            } else {
                                get_template_part( 'template-parts/content', get_post_format() );
                            } 
                        ?>
                            <div class="clearfix"></div>
                        <?php
                            wp_link_pages( array(
                                'before' => '<div class="content-pagination">' . '<span>' . esc_html( 'Pages:', 'koalogger' ) . '</span>',
                                'after'  => '</div>',
                            ) );
                            get_template_part( 'template-parts/content', 'footer' );
                        ?>
                        <div class="post-nav">
                            <?php
                                if( get_previous_post_link() ) {
                                    echo '<div class="prev-post">';
	                                previous_post_link('%link', '<span>'.esc_html('Previous post', 'koalogger').'</span>%title', true);
                                    echo '</div>';
                                }
	                            if( get_next_post_link() ) {
		                            echo '<div class="next-post">';
		                            next_post_link('%link', '<span>'.esc_html('Next post', 'koalogger').'</span>%title', true);
		                            echo '</div>';
	                            }
                            ?>
                        </div>
                        <?php
                            // If comments are open or we have at least one comment, load up the comment template.
                            if ( comments_open() || get_comments_number() ) {
                                comments_template();
                            }
                        ?>
                    </div>
            <?php } ?>

		</article>
	</div>
<?php get_footer(); ?>