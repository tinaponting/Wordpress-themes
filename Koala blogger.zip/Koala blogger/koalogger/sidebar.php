<?php
/**
 * The template for the sidebar containing the main widget area
 */
?>
<aside class="sidebar widget-area">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- .sidebar .widget-area -->