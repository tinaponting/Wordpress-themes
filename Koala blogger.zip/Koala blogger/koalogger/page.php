<?php
/**
 * The template for displaying pages
 */
get_header(); ?>
	<div class="article-content">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<?php // Start the Loop.
				while ( have_posts() ) : the_post(); ?>
					<?php if ( has_post_thumbnail()) { ?>
                        <div class="thumbnail-wrap">
                                <span class="thumbnail-line thumbnail-line-1"></span>
                                <span class="thumbnail-line thumbnail-line-2"></span>
                                <span class="thumbnail-line thumbnail-line-3"></span>
                                <div class="img-thumb">
                                    <?php the_post_thumbnail('koalogger_big'); ?>
                                </div>
                                <div class="clone clone-1"></div>
                                <div class="clone clone-2"></div>
                                <div class="clone clone-3"></div>
                                <div class="clone clone-4"></div>
                        </div>
                    <?php } else { ?>
                        <div class="no-thumbnail-wrap"></div>                 
                    <?php } ?>  
                    <div class="post-content">
                        <div class="title">
                            <h1><?php the_title(); ?></h1>
                        </div>
		    			<?php
                            get_template_part( 'template-parts/content' );
                            wp_link_pages( array(
                                'before' => '<div class="content-pagination">' . '<span>' . esc_html( 'Pages:', 'koalogger' ) . '</span>',
                                'after'  => '</div>',
                            ) );
                        ?>

                    <?php // If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					} ?>
                    </div>
				<?php endwhile;
			?>
		</article>
	</div>
<?php get_footer(); ?>