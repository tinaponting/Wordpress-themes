<?php
/* Customize theme support */
function koalogger_setup() {
	/* title tag */
	add_theme_support( 'title-tag' );

	/* logo */
	add_theme_support( 'custom-logo' );

	/* add rss support */
	add_theme_support( 'automatic-feed-links' );

	/* body background */
	$defaults = array(
		'default-color'          => '#fff',
		'default-image'          => '',
		'wp-head-callback'       => '_custom_background_cb',
		'admin-head-callback'    => '',
		'admin-preview-callback' => ''
	);
	add_theme_support( 'custom-background', $defaults );

	if ( ! isset( $content_width ) ) {
		$content_width = 600;
	}
	/* add thumbnail support for post */
	add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );
	add_image_size( 'koalogger_logo', 265, 100, false );
	add_image_size( 'koalogger_big', 2000, 800, true );
	add_image_size( 'koalogger_thumb', 453, 9999, false );

	/* Add post formats */
	add_theme_support( 'post-formats', array( 'video', 'audio', 'gallery', 'quote', 'link' ) );

	/* Add editor CSS */
	function koalogger_add_editor_styles() {
		add_editor_style( 'css/editor_styles.css' );
	}
	add_action( 'current_screen', 'koalogger_add_editor_styles' );

	/* Add translate */
	load_theme_textdomain( 'koalogger', get_template_directory() . '/languages' );

	/* Register menu */
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary Menu', 'koalogger' ),
	) );
}
add_action( 'after_setup_theme', 'koalogger_setup' );

/* Register widgets */
function koalogger_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'koalogger' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'koalogger' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widget-title">',
		'after_title'   => '</div>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer column 1', 'koalogger' ),
		'id'            => 'footer-1',
		'description'   => esc_html__( 'Add widgets here to appear in your footer on 1st column.', 'koalogger' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widget-area__title">',
		'after_title'   => '</div>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer column 2', 'koalogger' ),
		'id'            => 'footer-2',
		'description'   => esc_html__( 'Add widgets here to appear in your footer on 2nd column.', 'koalogger' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widget-area__title">',
		'after_title'   => '</div>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer column 3', 'koalogger' ),
		'id'            => 'footer-3',
		'description'   => esc_html__( 'Add widgets here to appear in your footer on 3rd column.', 'koalogger' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widget-area__title">',
		'after_title'   => '</div>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer column 4', 'koalogger' ),
		'id'            => 'footer-4',
		'description'   => esc_html__( 'Add widgets here to appear in your footer on 4th column.', 'koalogger' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widget-area__title">',
		'after_title'   => '</div>',
	) );
}
add_action( 'widgets_init', 'koalogger_widgets_init' );

/* Include JS in admin area */
function koalogger_admin_scripts() {
	if( get_current_screen()->is_block_editor() == 1 ){
		wp_register_script( 'koalogger-admin-scripts', get_template_directory_uri() . '/js/admin-scripts-gutenberg.js', array( 'jquery' ), '1.0', true );
	} else {
		wp_register_script( 'koalogger-admin-scripts', get_template_directory_uri() . '/js/admin-scripts.js', array( 'jquery' ), '1.0', true );
	}
	wp_enqueue_script( 'koalogger-admin-scripts' );
}
add_action( 'admin_enqueue_scripts', 'koalogger_admin_scripts' );

/* Include CSS and JS */
function koalogger_load_resources() {
	$theme_uri = get_template_directory_uri(); // theme URL
	$post_format = get_post_format();

	/* JS */
	wp_enqueue_script('jquery-masonry');
	if ( function_exists( 'cs_get_option' ) ){
		if ( is_page_template( 'contacts.php' ) ){
			$contact_array = get_post_meta( get_the_ID(), '_contact_page_options', true );
			$location = $contact_array['location'];
			$api_key = $contact_array['api_key'];
			if ( $api_key != '' ){
				$api = $api_key;
			} else {
				$api = '';
			}
			if ( $location['address'] != '' ){
				wp_register_script( 'google-map', '//maps.googleapis.com/maps/api/js?key=' . esc_attr( $api ) . '&callback=initMap', array('jquery'), '1.0', $in_footer = true );
				wp_enqueue_script( 'google-map' );
			}
		}
	}

	wp_register_script( 'koalogger-colorbox', $theme_uri.'/js/jquery.colorbox-min.js', array('jquery'), '1.0', $in_footer = true );
	wp_enqueue_script( 'koalogger-colorbox' );
	if ( !is_page_template('contacts.php') ) {
		wp_register_script( 'koalogger-scripts', $theme_uri . '/js/scripts.js', array( 'jquery' ), '1.0', $in_footer = true );
		wp_enqueue_script( 'koalogger-scripts' );
	}
 	if ( is_front_page() ){
	 	wp_register_script( 'koalogger-owl', $theme_uri.'/js/owl.carousel.min.js', array('jquery'), '1.0', $in_footer = true );
	 	wp_enqueue_script( 'koalogger-owl' );
	 	if ( is_rtl() ){
		 	wp_register_script( 'koalogger-mainpage', $theme_uri.'/js/mainpage-rtl.js', array('jquery'), '1.0', $in_footer = true );
		 	wp_enqueue_script( 'koalogger-mainpage' );
		} else {
			wp_register_script( 'koalogger-mainpage', $theme_uri.'/js/mainpage.js', array('jquery'), '1.0', $in_footer = true );
		 	wp_enqueue_script( 'koalogger-mainpage' );
		}
	}
	if ( is_single() || is_page() ){
		wp_register_script( 'koalogger-post', $theme_uri.'/js/post.js', array('jquery'), '1.0', $in_footer = true );
		wp_enqueue_script( 'koalogger-post' );
	}
	if ( is_single() && $post_format == 'video' ){
		wp_register_script( 'koalogger-video', $theme_uri.'/js/video.js', array('jquery'), '1.0', $in_footer = true );
	 	wp_enqueue_script( 'koalogger-video' );
	}

	/* CSS */
	if ( is_front_page() && function_exists( 'cs_get_option' ) ){
		wp_register_style( 'koalogger-owl-style', $theme_uri.'/css/owl.carousel.css', false, '1.0' );
		wp_enqueue_style( 'koalogger-owl-style' );
	}
	if ( !function_exists( 'cs_get_option' ) ){
		wp_register_style( 'koalogger-style', $theme_uri.'/style.css', false, '1.0' );
		wp_enqueue_style( 'koalogger-style' );
	}

	if ( is_single() || is_page() ){
		wp_register_style( 'koalogger-colorbox', $theme_uri.'/css/colorbox.min.css', false, '1.0' );
		wp_enqueue_style( 'koalogger-colorbox' );
	}
}
add_action( 'wp_enqueue_scripts', 'koalogger_load_resources' );
/* inline styles from CS Framework*/

if ( function_exists( 'cs_get_option' ) ){
	function koalogger_cs_styles() {
		wp_enqueue_style('koalogger_style', get_template_directory_uri() . '/style.css');
		$primary_color = cs_get_option( 'primary_color' );
		$hide_meta = cs_get_option( 'meta_hide' );
		if( $hide_meta == 1 ){
			$hide_meta_css = '.item-list .post-meta span { display: none; } .item-list .post-meta .post-date { display: inline-block; }';
		} else {
			$hide_meta_css = '';
		}
		$csstyle = esc_attr( "
			{$hide_meta_css}
			input[type=submit]:hover,
			.nav,
			.comment-form .form-submit input:hover,
			.burger-menu {
				background-color: {$primary_color};
			}
			svg.hover-play {
				fill: {$primary_color};
			}
			.sticky-block {
			    border-left-color: {$primary_color};
			    border-top-color: {$primary_color};
			}
			a.post-cat,
			.thumbnail-wrap,
			.close:hover:before,
			.close:hover:after {
				background: {$primary_color};
			}
			@media (max-width: 1024px){
				svg.hover-play {
				    fill: {$primary_color};
				}
				.site-header,
				.logged-in .site-header,
				.home header.site-header {
				    background: {$primary_color};
				}
			}
		" );
		wp_add_inline_style( 'koalogger_style', $csstyle );
	}
	add_action( 'wp_enqueue_scripts', 'koalogger_cs_styles' );
}

function koalogger_fonts_url() {
	$fonts_url = '';

	$rozha = _x( 'on', 'Lora font: on or off', 'koalogger' );
	$open_sans = _x( 'on', 'Open Sans font: on or off', 'koalogger' );
	 
	if ( 'off' !== $rozha || 'off' !== $open_sans ) {
		$font_families = array();
		if ( 'off' !== $rozha ) {
			$font_families[] = 'Rozha One';
		}
		if ( 'off' !== $open_sans ) {
			$font_families[] = 'Open Sans:400,600,700';
		}
		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);
		$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}
	return esc_url_raw( $fonts_url );
}

function koalogger_scripts_styles() {
	wp_enqueue_style( 'google-fonts', koalogger_fonts_url(), array(), null );
}
add_action( 'wp_enqueue_scripts', 'koalogger_scripts_styles' );

if ( function_exists( 'cs_get_option' ) ){
	add_action('wp_enqueue_scripts', function(){
		if ( is_page_template('contacts.php') ){
			$contact_array = get_post_meta( get_the_ID(), '_contact_page_options', true );
			$location = $contact_array['location'];
			if ( $location['address'] != '' ){
				wp_enqueue_script( 'koalogger-scripts', get_template_directory_uri().'/js/scripts.js' );

				$address = $location['address'];
				$lat = $location['lat'];
				$lot = $location['lon'];

				$mapScript = "
				function initMap() {
			        var myLatLng = {lat: " . esc_attr( $lat ) . ", lng: " . esc_attr( $lot ) . "};
			        var styles =[{'featureType':'water','elementType':'geometry','stylers':[{'visibility':'on'},{'color':'#aee2e0'}]},{'featureType':'landscape','elementType':'geometry.fill','stylers':[{'color':'#abce83'}]},{'featureType':'poi','elementType':'geometry.fill','stylers':[{'color':'#769E72'}]},{'featureType':'poi','elementType':'labels.text.fill','stylers':[{'color':'#7B8758'}]},{'featureType':'poi','elementType':'labels.text.stroke','stylers':[{'color':'#EBF4A4'}]},{'featureType':'poi.park','elementType':'geometry','stylers':[{'visibility':'simplified'},{'color':'#8dab68'}]},{'featureType':'road','elementType':'geometry.fill','stylers':[{'visibility':'simplified'}]},{'featureType':'road','elementType':'labels.text.fill','stylers':[{'color':'#5B5B3F'}]},{'featureType':'road','elementType':'labels.text.stroke','stylers':[{'color':'#ABCE83'}]},{'featureType':'road','elementType':'labels.icon','stylers':[{'visibility':'off'}]},{'featureType':'road.local','elementType':'geometry','stylers':[{'color':'#A4C67D'}]},{'featureType':'road.arterial','elementType':'geometry','stylers':[{'color':'#9BBF72'}]},{'featureType':'road.highway','elementType':'geometry','stylers':[{'color':'#EBF4A4'}]},{'featureType':'transit','stylers':[{'visibility':'off'}]},{'featureType':'administrative','elementType':'geometry.stroke','stylers':[{'visibility':'on'},{'color':'#87ae79'}]},{'featureType':'administrative','elementType':'geometry.fill','stylers':[{'color':'#7f2200'},{'visibility':'off'}]},{'featureType':'administrative','elementType':'labels.text.stroke','stylers':[{'color':'#ffffff'},{'visibility':'on'},{'weight':4.1}]},{'featureType':'administrative','elementType':'labels.text.fill','stylers':[{'color':'#495421'}]},{'featureType':'administrative.neighborhood','elementType':'labels','stylers':[{'visibility':'off'}]}];
			        
			        // Create a map object and specify the DOM element for display.
			        var map = new google.maps.Map(document.getElementById('map'), {
			          center: myLatLng,
			          scrollwheel: false,
			          zoom: 13,
			          styles: styles
			        });

			        // Create a marker and set its position.
			        var marker = new google.maps.Marker({
			          map: map,
			          position: myLatLng,
			          title: '" . esc_attr( $address ) . "'
			        });
			      }
				";
				wp_add_inline_script( 'koalogger-scripts', $mapScript );
			} else {
				wp_register_script( 'koalogger-scripts', get_template_directory_uri().'/js/scripts.js', array('jquery'), '1.0', $in_footer = true );
				wp_enqueue_script( 'koalogger-scripts' );
			}
		}
	});
}

/* Comments reply */
function koalogger_comments_reply() {
	if( is_singular() && comments_open() && ( get_option( 'thread_comments' ) == 1) ) {
		wp_enqueue_script( 'comment-reply', 'wp-includes/js/comment-reply', array(), false, true );
	}
}
add_action(  'wp_enqueue_scripts', 'koalogger_comments_reply' );

/* Excerpt */
function koalogger_excerpt_length( $length ) {
	return 40;
}
add_filter( 'excerpt_length', 'koalogger_excerpt_length' );

add_filter( 'excerpt_more', function( $more ) {
	return '...';
});

/* Comments template */
function koalogger_comment( $comment, $args, $depth ){
	$GLOBALS['comment'] = $comment;
	global $wpdb;
	?>
<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
	<?php
		$avatar = get_avatar( $comment, 86, '', '' );
		echo get_avatar( $comment, 86, '', '' );
		if ( $avatar !== false ){
			$no_avatar = '';
		} else {
			$no_avatar = 'no_avatar';
		}
	?>
	<div class="comment-wrap <?php echo esc_attr( $no_avatar ); ?>" id="comment-<?php comment_ID(); ?>">
		<div class="comment-author vcard">
			<cite class="fn"><?php echo get_comment_author_link() ?></cite>
			<span class="comment-time"><?php printf( '%1$s,  %2$s', get_comment_date(),  get_comment_time() ); ?></span>
		</div>

		<?php esc_attr( comment_text() ); ?>

		<div class="reply">
			<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
		</div>
	</div>
	<?php
}

 /* Codestar Framework */
require_once get_template_directory() . '/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'koalogger_require_plugins' );
function koalogger_require_plugins() {
    $plugins = array(
    	array(
	        'name'               => esc_html__( 'Codestar Framework', 'koalogger' ),
	        'slug'               => 'cs-framework',
	        'source'             => get_template_directory() . '/lib/cs-framework/cs-framework.zip',
	        'required'           => true,
	        'force_activation'   => false,
	        'version'            => '1.0.2',
	    ),
	    array(
	        'name'               => esc_html__( 'Koalogger addons', 'koalogger' ),
	        'slug'               => 'koalogger-addons',
	        'source'             => get_template_directory() . '/lib/koalogger-addons/koalogger-addons.zip',
	        'required'           => true,
	        'force_activation'   => false,
	        'version'            => '1.0',
	    ),
    );

    $config = array(
	    'id'           => 'koalogger-addons-tgmpa',
	    'has_notices'  => true,
	    'dismissable'  => false,
	    'dismiss_msg'  => esc_html__( 'I really, really need you to install these plugins, okay?', 'koalogger' ),
	    'is_automatic' => true
	);
    tgmpa( $plugins, $config );
}

define( 'CS_ACTIVE_FRAMEWORK',  true  ); // default true
define( 'CS_ACTIVE_METABOX',    true ); // default true
define( 'CS_ACTIVE_TAXONOMY',   false ); // default true
define( 'CS_ACTIVE_SHORTCODE',  true ); // default true
define( 'CS_ACTIVE_CUSTOMIZE',  false ); // default true


/* Post counter */
function koalogger_get_post_views( $postID ){
    $count_key = 'post_views_count';
    $count = get_post_meta( $postID, $count_key, true );
    if( $count=='' ){
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
        return "0";
    }
    return $count;
}
function koalogger_set_post_views( $postID ) {
    $count_key = 'post_views_count';
    $count = get_post_meta( $postID, $count_key, true );
    if( $count=='' ){
        $count = 0;
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
    } else {
        $count++;
        update_post_meta( $postID, $count_key, $count );
    }
}

/* Change comments fields order */
add_filter( 'comment_form_fields', 'koalogger_reorder_comment_fields' );
function koalogger_reorder_comment_fields( $fields ){
	$new_fields = array();

	$myorder = array('author','email','url','comment');

	foreach( $myorder as $key ){
		$new_fields[ $key ] = $fields[ $key ];
		unset( $fields[ $key ] );
	}
	if( $fields )
		foreach( $fields as $key => $val )
			$new_fields[$key] = $val;

	return $new_fields;
}

/* change pagination template */
add_filter('navigation_markup_template', 'koalogger_navigation_template', 10, 2 );
function koalogger_navigation_template( $template, $class ){
	return '
	<nav class="navigation %1$s">
		<div class="nav-links">%3$s</div>
	</nav>    
	';
}

/* Portfolio ajax load */
function koalogger_ajax_load(){
	$sticky = get_option( 'sticky_posts' );
	$args = unserialize( stripslashes( $_POST['query'] ) );
	$args['paged'] = $_POST['page'] + 1;
	$args['post_status'] = 'publish';
	if ( is_front_page() ){
		$args['ignore_sticky_posts'] = 1;
		$args['post__not_in'] = $sticky;
	}
	$q = new WP_Query( $args );
	if( $q->have_posts() ){
		while( $q->have_posts() ){
			$q->the_post();
			get_template_part( 'loop' );
		}
	}
	wp_reset_postdata();
	die();
}
add_action( 'wp_ajax_loadmore', 'koalogger_ajax_load' );
add_action( 'wp_ajax_nopriv_loadmore', 'koalogger_ajax_load' );