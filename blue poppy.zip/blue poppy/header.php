<?php
/**
 * The header for the theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blue_Poppy
 */

?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
<?php if (is_customize_preview() ) { ?>
	<style type="text/css">	
		body {background: #FFF !important;}
	</style>
<?php } ?>
	 
</head>


<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php if(is_front_page()) { ?>
<?php } ?>

<div class="top-bar" style="background-color:<?php echo get_theme_mod('top-bar-color', '#c3d3e0'); ?>">
<div class="top-wrapper">
                <div class="top-search"><?php get_search_form(); ?></div>
<div class="top-social">
                 <?php my_social_media_icons(); ?>
                 </div>
                 </div>
</div>


<div id="page" class="site">


<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'blue-poppy' ); ?></a>
<header id="masthead" class="site-header <?php echo get_theme_mod('sticky-header', 'sticky'); ?>">
    <div class="container">

<?php if (wp_nav_menu( array( 'theme_location' => 'main-menu', 'echo' => false )) !== false) { ?>
        <input class="menu-btn" type="checkbox" id="menu-btn" />
        <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>

        <div class="mobile-menu">
            <?php
				wp_nav_menu(array(
    			'theme_location' => 'main-menu',
   				'menu_id' => 'primary-menu',
				));
			?>

                <?php my_social_media_icons(); ?>

        </div>
       <nav id="site-navigation" class="main-navigation-divided">

        <?php if (get_theme_mod('divider-options', 'nothing') == 'logo'): ?>
                           
     	<?php
			if ( defined( 'JETPACK__VERSION' ) ) {
   				 $divider_html = '<a href="' . get_site_url() . '">' . get_custom_logo() . '</a>';
   				 wp_nav_menu(array(
        			'theme_location' => 'main-menu',
        			'menu_id' => 'primary-menu',
        			'divider_html' => $divider_html,
    				));
			
				} else { 

            	
                $custom_logo_id = get_theme_mod( 'custom_logo' );
				$logo_image = wp_get_attachment_image_src( $custom_logo_id , 'medium_large' );
   				 $divider_html = '<a class="custom-logo-link" href="' . get_site_url() . '"><img class="custom-logo" src="'. $logo_image[0] .'" alt="custom-logo"></a>';
   				 wp_nav_menu(array(
        			'theme_location' => 'main-menu',
        			'menu_id' => 'primary-menu',
        			'divider_html' => $divider_html,
    				));
			} ?>
                    <?php elseif (get_theme_mod('divider-options', 'nothing') == 'site-title'): ?>
                    
                        <?php
   						 $divider_html = '<a class="title" href="' . get_site_url() . '"><h1 class="site-title">' . get_bloginfo('name') . '</h1></a>';
   						 wp_nav_menu(array(
        					'theme_location' => 'main-menu',
        					'menu_id' => 'primary-menu',
        					'divider_html' => $divider_html,
    							));
						?>
						
					
					<?php else: ?>

  				<?php
   				 $divider_html = '<a class="working" href="' . get_site_url() . '"><img class="custom-logo" src="' . get_site_url() . '/wp-content/themes/blue-poppy/images/blue-poppy-logo.png"></a>';
   				 wp_nav_menu(array(
        			'theme_location' => 'main-menu',
        			'menu_id' => 'primary-menu',
        			'divider_html' => $divider_html,
    				));
				?>
						
                    <?php endif; ?>

        </nav>

    
<?php } ?>
    </div>
    <!-- #site-navigation -->
</header>
<!-- #masthead -->