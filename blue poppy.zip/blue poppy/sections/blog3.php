<?php 
/**
/** Blog Posts Section 3 Template
 **/
 
 $category = get_theme_mod( 'blog3-cat', '' );
 $offset = get_theme_mod( 'blog3-offset', '' );
 $catid = get_cat_ID($category);
 $number = get_theme_mod( 'blog3-number', '6' );
 $topsection = get_theme_mod( 'padding-off-blog3', false); 
 
 ?>


<a name="skills"></a>

<section class="blog-posts-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>">

<h2 class="blog-headline"><?php echo get_theme_mod( 'blog3-headline', esc_html__('Art & Fashion', 'blue-poppy') ) ?></h2>


<div class="blog-posts-wrapper-3-column">

<?php
 
$args = array(
   'posts_per_page' => $number,
   'post_type' => 'post',
   'suppress_filters' => 0,
   'cat' => $catid,
   'offset' => $offset,

);
 
// Custom query.
$query = new WP_Query( $args );
 
// Check that we have query results.
if ( $query->have_posts() ) {
 
    // Start looping over the query results.
    while ( $query->have_posts() ) {
 
        $query->the_post(); { ?>  
	
	<div class="blog-blocks">
	<a class="post-thumbnail" href="<?php echo get_permalink(); ?>"><?php has_post_thumbnail(); the_post_thumbnail('medium', array('class' => 'lazyload', 'alt' => esc_html ( get_the_title() ) ) ); ?></a>
		<h4 class="blog-box-title"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h4>
	</div>
<?php
 
		} 
	}
}	wp_reset_postdata(); ?> 
	
</div>	
     
</section>