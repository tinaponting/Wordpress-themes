<?php
/**
/** About Section Template
 **/
 
$image = get_theme_mod( 'about-image', get_template_directory_uri() . '/images/about-demo.jpg' );

if ( ! wp_attachment_is_image( $image ) ){

    $img_url = esc_url_raw($image);

		} else {

    $img_url = wp_get_attachment_image_url($image, 'medium_large');
						
		} 
							
$topsection = get_theme_mod( 'padding-off-about', false); ?>


<section class="about-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>"  style="background-color:<?php echo get_theme_mod('about-color-hex', ''); ?>;">
	
<div class="about-wrapper">
		<div class="image-wrapper">
       	 	<img class="lazyload" data-src="<?php echo $img_url; ?>" alt="<?php echo get_theme_mod( 'about-headline', esc_html__('Hey, there!', 'blue-poppy') ) ?>" />
         </div>
    <div class="about-content">     
	<h2 class="about-headline"><?php echo get_theme_mod( 'about-headline', esc_html__('Hey, there!', 'blue-poppy') ) ?></h2>
 	<p><?php echo get_theme_mod( 'about-text', esc_html__('After a while, finding that nothing more happened, she decided on going into the garden at once; but, alas for poor Alice! when she got to the door, she found she had forgotten the little golden key, and when she went back to the table for it, she found she could not possibly reach it.', 'blue-poppy') ) ?></p>
 		<?php my_social_media_icons(); ?>

	</div>

</div>	
</section>