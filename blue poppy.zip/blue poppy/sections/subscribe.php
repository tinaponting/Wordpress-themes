<?php
/**
/** Subscribe Section Template
 **/
 
 $topsection = get_theme_mod( 'padding-off-subscribe', false); 
 $subscribe_text = get_theme_mod ('subscribe-text', esc_html__('Join over 10,000 fans and get our newsletter in your inbox every week!', 'blue-poppy'));

 ?>


<section class="subscribe-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>"  style="background-color:<?php echo get_theme_mod('subscribe-color-hex', '#c0fbe5'); ?>;">
 	<div class="subscribe-wrapper">
 	 <?php if ( true == get_theme_mod( 'remove-subscribe-button', false ) ) : ?>
 	<h3 style="flex-basis: 100%;"><?php echo do_shortcode( $subscribe_text); ?></h3>
<?php else : ?>
 	<h3><?php echo do_shortcode( $subscribe_text); ?></h3>
 	 <div class="subscribe-button"><a href="<?php echo get_theme_mod( 'subscribe-url', 'https://littlethemeshop.com' ) ?>"><?php echo get_theme_mod( 'subscribe-button', esc_html__('Sign Up', 'blue-poppy') ) ?></a></div>
<?php endif; ?>
 	</div>
</section>