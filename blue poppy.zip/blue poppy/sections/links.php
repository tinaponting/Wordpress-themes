<?php
/**
/** Link Section Template
 **/

$linkdefaults = [
  [
    	'link_name'    => esc_html__( 'Blog', 'blue-poppy' ),
		'link_url'    => 'https://littlethemeshop.com',
	],
	[
		'link_name'    => esc_html__( 'Shop', 'blue-poppy' ),
		'link_url'    => 'https://littlethemeshop.com',

	],
		[
		'link_name'    => esc_html__( 'Goodies', 'blue-poppy' ),
		'link_url'    => 'https://littlethemeshop.com',

	],
	[
		'link_name'    => esc_html__( 'Contact', 'blue-poppy' ),
		'link_url'    => 'https://littlethemeshop.com',

	],
];

$links = get_theme_mod( 'link_repeater', $linkdefaults ); 
$topsection = get_theme_mod( 'padding-off-links', false); 

?>


<section class="link-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>">


		<div class="link-wrapper">
		
			<ul>
			
			<?php foreach( $links as $link ) : ?>
			
				<li><h3>
			
				 <a href="<?php if(isset($link['link_url'])) { echo $link['link_url']; } ?>">
				 
 					
    					<?php if(isset($link['link_name'])) { echo $link['link_name']; } ?>
					
				</a></h3>
				</li>

     		<?php endforeach; ?>
     	</ul>
		</div>
		
</section>