<?php
/**
 Template Name: Homepage Sections
 */
 
get_header();
?>

<a id="content"></a>

<div id="primary-home">
    <main id="main-home" class="home-sections">
      			
					<?php
// Get the parts.
$template_parts = get_theme_mod( 'homepage_layout', array( 'slider', 'links', 'blog1', 'subscribe', 'blog2', 'buythebook', 'blog3', 'about', 'mission'));

// Loop parts.
foreach ( $template_parts as $template_part ) {
	get_template_part( 'sections/' . $template_part );
} ?>

</main>
</div>



<?php get_footer();