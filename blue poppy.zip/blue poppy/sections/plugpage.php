<?php
/**
/** Page Section Template
 **/
 
$bluepoppypage = get_theme_mod( 'bluepoppypage-dropdown', '42' );
$topsection = get_theme_mod( 'padding-off', false); 

?>

<a name="bluepoppypage"></a>

<section class="page-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>" style="background-color:<?php echo get_theme_mod('page-color-hex', '#fff'); ?>;">

	<h2 style="color:<?php echo get_theme_mod('page-color-hex2', '#222'); ?>;"> 
	
		<?php echo get_theme_mod( 'bluepoppypage-headline', esc_html__('Page Section', 'blue-poppy') ) ?>
		
	</h2>

		<div class="page-content-container">
		
			<?php $page_id = $bluepoppypage;
				$page_object = get_page( $page_id );
					if ( !empty( $page_object ) ) :
					echo do_shortcode( $page_object->post_content );
					endif;
			 ?>
			 
        </div>

     
 </section>