<?php
/**
/** Quote Section Template
 **/
 
$topsection = get_theme_mod( 'padding-off-mission', false); 

 ?>


<section class="mission-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?> <?php echo get_theme_mod('pattern-options', 'background-stripes'); ?>"  style="background-color:<?php echo get_theme_mod('mission-color-hex', '#e8e4e1'); ?>;">
	<h2 class="mission-headline"><?php echo get_theme_mod( 'mission-headline', esc_html__('"Always remember to work hard, have fun, and eat tacos"', 'blue-poppy') ) ?></h2>
 	<p><?php echo get_theme_mod( 'mission-text', esc_html__('Larissa McPhelan', 'blue-poppy') ) ?></p>
</section>