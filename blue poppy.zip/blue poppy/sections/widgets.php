<?php
/**
/** Widgets Section Template
 **/
 ?>


<section class="widgets-section">
	
	
	 <?php if ( is_active_sidebar( 'bluepoppy-homepage-widgets' ) ) : ?>
            <?php dynamic_sidebar( 'bluepoppy-homepage-widgets' ); ?>
	
	            <?php else : ?>

<h3 style="text-align: center;"><?php _e('This is empty because you have not added any widgets yet! To add widgets, drag them into the "bluepoppy Homepage" widget area in Appearance < Widgets.', 'blue-poppy'); ?></h3>

            <?php endif; ?>

	
</section>