<?php 
/**
/** Skills Section Template
 **/
 
$category = get_theme_mod( 'blog1-cat', '' );
$offset = get_theme_mod( 'blog1-offset', '' );
$catid = get_cat_ID($category);
$topsection = get_theme_mod( 'padding-off-blog1', false); ?>

<a name="skills"></a>

<section class="blog-posts-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>">

<h2 class="blog-headline"><?php echo get_theme_mod( 'blog1-headline', esc_html__('What&#39;s New', 'blue-poppy') ) ?></h2>

<div class="blog-posts-wrapper">

<?php
 
$args = array(
   'posts_per_page' => 5,
   'post_type' => 'post',
   'suppress_filters' => 0,
   'cat' => $catid,
   'offset' => $offset,
);

$index = 0;
 
// Custom query.
$query = new WP_Query( $args );
 
// Check that we have query results.
if ( $query->have_posts() ) {
 
    // Start looping over the query results.
    while ( $query->have_posts() ) {
 
        $query->the_post(); $index++;
    
	if ( $index == 1 ) { ?>  
	
	<div class="big-blog-box">
		<?php blue_poppy_post_thumbnail(); ?>
		<div class="big-meta">
		<a href="<?php echo get_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
            <?php the_excerpt(); ?>
            <a class="slider-more" href="<?php echo get_permalink(); ?>"><?php echo get_theme_mod( 'read-more-text', esc_html__('Read More', 'blue-poppy') ); ?></a>
        </div>
    </div>
    
	<?php } elseif ( $index > 1 ) { ?>  
    
    <div class="blog-box">        
	<a href="<?php echo get_permalink(); ?>" class="post-thumbnail"><?php has_post_thumbnail(); the_post_thumbnail('medium', array('class' => 'lazyload', 'alt' => esc_html ( get_the_title() ) ) ); ?></a>
		<h4 class="blog-box-title"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h4>
	</div>
  
  <?php } else { ?>
	
		<?php	}    
       }
 
	} wp_reset_postdata(); ?> 
	
</div>	
     
</section>