<?php
/**
/** Buythebook Section Template
 **/
 
$image = get_theme_mod( 'buythebook-image', get_template_directory_uri() . '/images/featured-demo.jpg' ); 

if ( ! wp_attachment_is_image( $image ) ){

   $img_url = esc_url_raw($image);

		} else {

   $img_url = wp_get_attachment_image_url($image, 'medium_large');
						
		} 
						
$topsection = get_theme_mod( 'padding-off-buythebook', false); 

$featured_text = get_theme_mod ('buythebook-text', esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Purus gravida quis blandit turpis cursus in. Magna sit amet purus gravida. Vel elit scelerisque mauris pellentesque pulvinar pellentesque. Porttitor massa id neque aliquam vestibulum morbi blandit cursus risus.', 'blue-poppy'));

?>


<section class="buythebook-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>"  style="background-color:<?php echo get_theme_mod('buythebook-color-hex', ''); ?>;">
	
<div class="buythebook-wrapper">
		<div class="image-wrapper">
			<img class="lazyload" data-src="<?php echo $img_url; ?>" alt="<?php echo get_theme_mod( 'buythebook-headline', esc_html__('Welcome to My Site', 'blue-poppy') ) ?>" />
         </div>
    <div class="buythebook-content">     
	<h2 class="buythebook-headline"><?php echo get_theme_mod( 'buythebook-headline', esc_html__('Welcome to My Site', 'blue-poppy') ) ?></h2>
 	
 	<p><?php echo do_shortcode( $featured_text); ?></p>
 	
 	<a class="buythebook-link" href="<?php echo get_theme_mod( 'buythebook-link', 'https://littlethemeshop.com' ) ?>"><?php echo get_theme_mod( 'buythebook-link-text', esc_html__('Learn More', 'blue-poppy') ) ?></a>
	</div>
</div>	
</section>