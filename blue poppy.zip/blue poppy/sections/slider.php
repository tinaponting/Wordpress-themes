<?php
/**
/** Content Slider Section Template
 **/
 
$category = get_theme_mod( 'slider-cat', '' );
$catid = get_cat_ID($category);
$topsection = get_theme_mod( 'padding-off-slider', true); 

?>

<section class="slider-section <?php echo ( $topsection ) ? 'padding-off' : 'padding-on'; ?>">

<div class="sheetSlider sh-default sh-auto">

   <input id="s1" type="radio" name="slide1" checked/> 
   <input id="s2" type="radio" name="slide1"/> 
   <input id="s3" type="radio" name="slide1"/> 
   <input id="s4" type="radio" name="slide1"/> 
   <input id="s5" type="radio" name="slide1"/> 
   <div class="sh__content">

<?php
 
$args = array(
   'posts_per_page' => 5,
   'post_type' => 'post',
   'suppress_filters' => 0,
   'cat' => $catid,
);
 
// Custom query.
$query = new WP_Query( $args );
 
// Check that we have query results.
if ( $query->have_posts() ) {
 
    // Start looping over the query results.
    while ( $query->have_posts() ) {
 
        $query->the_post(); ?>
    
<!--Sheet Slider-->
   

         <!-- Slider Item -->
      <div class="sh__item <?php echo get_theme_mod('pattern-options', 'background-stripes'); ?>">
      	<div class="image-wrapper">
       	<?php blue_poppy_post_thumbnail(); ?>
         </div>
         <!-- Item Info -->
         <div class="sh__meta">
          <span class="home-meta"><?php $category = get_the_category(); 
									echo '<a href="'.esc_url( get_category_link($category[0]->cat_ID) ).'"> '.$category[0]->cat_name.' </a>'; ?></span>
            <a href="<?php echo get_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
            <a class="slider-more" href="<?php echo get_permalink(); ?>"><?php echo get_theme_mod( 'read-more-text', esc_html__('Continue Reading', 'blue-poppy') ); ?></a>
         </div>
      </div>
      
<?php    }
 
	} wp_reset_postdata(); ?> 

   </div><!-- .sh__content -->

   <!--flechas-->
   <div class="sh__arrows">
      <label for="s1"></label>
      <label for="s2"></label>
      <label for="s3"></label>
      <label for="s4"></label>
      <label for="s5"></label>
   </div><!-- .sh__arrows -->
   
</div><!-- .sheetSlider -->        
     
 </section>
 
 