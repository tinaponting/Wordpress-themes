<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blue_Poppy
 */

?>

</div> <!-- #content -->

<footer id="colophon" class="site-footer">

<div class="footer-wrapper">
<div class="logo-container">
	<?php if( get_theme_mod( 'footer-logo-ask', 'nothing' ) == 'footer-logo-on' ) : ?>
			
			<?php if (get_theme_mod('footer-logo') !='') {
    		$footer_img = get_theme_mod('footer-logo');
		} ?>
			<img class="lazyload footer-image" src="<?php echo $footer_img ?>" alt="<?php esc_html_e( 'Footer Logo', 'blue-poppy' ) ?>">
		
	
	<?php elseif( get_theme_mod( 'footer-logo-ask', 'nothing' ) == 'footer-logo-off' ) : ?>
	
			<h4><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h4>


		<?php else : ?>

			<img class="footer-image" src="<?php get_site_url(); ?>/wp-content/themes/blue-poppy/images/blue-poppy-logo-white.png">
		
		<?php endif; ?>

 <?php my_social_media_icons(); ?>

</div>

	<div class="footer-menu">
	

			<?php
			wp_nav_menu( array(
				'theme_location' => 'footer-menu',
				'menu_id'        => 'footer-menu',
				'reverse'        => TRUE,
			) );
			?>
			

	<div class="bottom-search"><?php get_search_form(); ?></div>
	
	</div>
</div>	

	<div class="site-info">
		<?php echo get_theme_mod('copyright', esc_html__( 'Copyright', 'blue-poppy')); ?> &#169; <?php echo date("Y"); ?> | <?php esc_html_e('All Rights Reserved', 'blue-poppy'); ?> | <a href="<?php echo get_theme_mod('footer-url', 'https://example.com') ?>" target="_blank"><?php echo get_theme_mod( 'footer-text', esc_html__( 'Designed by Little Theme Shop', 'blue-poppy') ); ?></a>
	</div>
	
</footer>

</div>

<?php wp_footer(); ?>
  


</body>


</html>

