<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Blue_Poppy
 */

get_header();
?>

   	<a id="content"></a>

    <div id="primary" class="content-area">
        <main id="main" class="site-main">
           
				

                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>


                            <div class="entry-content">

                                <header class="entry-page-header">
                               
                                    <h1 class="entry-title"><?php echo get_theme_mod( '404-page-title', esc_html__('Oops! Page Not Found.', 'blue-poppy') ) ?></h1>
                             
                                </header>
                                <!-- .entry-header -->
                                
                                    <?php blue_poppy_post_thumbnail('medium_large'); ?>


                                <p style="text-align:center;">
                                    <?php echo get_theme_mod( '404-page-message', esc_html__('Sorry, the page you are looking for is not here.', 'blue-poppy') ) ?>
                                </p>
                                
                                <?php get_search_form(); ?>
                                

                            </div>
                            <!-- .entry-content -->

                    </article>
                    <!-- #post -->
              
        </main>
        <!-- #content -->
    </div>
    <!-- #primary -->

    <?php get_footer();