<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Blue_Poppy
 */

?>


<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php blue_poppy_post_thumbnail(); ?>

		<h2 class="grid-title">
	
			<a href="<?php echo esc_url( get_permalink() );?>"><?php the_title(); ?></a>
		</h2>
		

</article><!-- #post-<?php the_ID(); ?> -->
