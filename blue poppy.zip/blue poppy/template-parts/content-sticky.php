<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Blue_Poppy
 */

?>

    <article id="post-<?php the_ID(); ?>" <?php post_class("top-post"); ?>>
  <header class="sticky-header <?php echo get_theme_mod('pattern-options', 'background-stripes'); ?>">
        <?php blue_poppy_post_thumbnail(); ?>

     <div class="sticky-content">
          
               <a href="<?php echo get_permalink(); ?>" rel="bookmark"><?php the_title( '<h2 class="sticky-title">', '</h2>' ); ?></a>
                        
            <!-- .entry-header -->
        		  
		  <a class="slider-more" href="<?php echo get_permalink(); ?>"><?php echo get_theme_mod( 'read-more-text', esc_html__('Continue Reading', 'blue-poppy') ); ?></a>
		  </div>
    </header>
    </article>
    <!-- #post-<?php the_ID(); ?> -->