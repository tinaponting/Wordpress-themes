<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Blue_Poppy
 */

?>


    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>


            <header class="entry-page-header <?php echo get_theme_mod('pattern-options', 'background-stripes'); ?>">
                    
              <?php if ( false == get_theme_mod( 'featured-pages', false ) ) : ?>
              
                <?php blue_poppy_post_thumbnail(); ?>
                
                <?php endif; ?>

                    <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                            
             </header>
                
               <div class="entry-content">
                             
                    <?php the_content(); ?>

              </div> <!-- .entry-content -->

     </article> <!-- #post -->
     
