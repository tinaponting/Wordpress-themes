<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package blue_poppy
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <!--<div class="article-inner-wrapper">-->
        <header class="entry-header">
                 
                 <div class="entry-meta">
			<?php blue_poppy_posted_on(); ?> / <?php comments_popup_link( esc_html__('Leave a comment', 'blue-poppy'), esc_html__('1 comment', 'blue-poppy'),esc_html__('% comments', 'blue-poppy') ); ?>
			</div>
			
            <a href="<?php echo get_permalink(); ?>"><?php the_title('<h1 class="entry-title">', '</h1>'); ?></a>
          
               
        </header><!-- .entry-header -->
        <div class="col-lg-9">
        <?php blue_poppy_post_thumbnail(); ?>

        <div class="entry-content">
            <?php the_excerpt() ?>
        <div class="blog-entry-footer">
        	<a class="read-more" href="<?php echo get_permalink(); ?>"><?php echo get_theme_mod( 'read-more-text', esc_html__('Read More', 'blue-poppy') ); ?></a>
        	<?php blue_poppy_social_buttons(); ?>
        </div>	
        </div><!-- .entry-content -->

        </div><!-- .col-md-9 -->
    <!-- .article-inner-wrapper -->
</article><!-- #post-<?php the_ID(); ?> -->
