<?php
/**
 * bluepoppy Theme Customizer
 *
 * @package Blue_Poppy
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
 
function blue_poppy_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'blue_poppy_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'blue_poppy_customize_partial_blogdescription',
		) );
	}
}
add_action( 'customize_register', 'blue_poppy_customize_register' );

function my_customizer_social_media_array() {
 	
	$social_sites = array('twitter', 'facebook', 'google-plus', 'flickr', 'pinterest', 'youtube', 'tiktok', 'tumblr', 'behance', 'dribbble', 'bloglovin', 'rss', 'linkedin', 'instagram', 'snapchat', 'etsy', 'email',);
 
	return $social_sites;
}


/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function blue_poppy_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function blue_poppy_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function blue_poppy_customize_preview_js() {
	wp_enqueue_script( 'blue-poppy-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'blue_poppy_customize_preview_js' );


function bluepoppy_customizer_settings( $wp_customize ) {

 $wp_customize->remove_control('header_image');

 $wp_customize->add_section( 'bluepoppy-settings' , array(
      'title'      => __( 'Blue Poppy General Theme Options', 'blue-poppy'),
      'priority' => 10,
      'panel' => 'poppy_panel', 


  ) );
  
   $wp_customize->add_section( 'bluepoppy-shop-settings' , array(
      'title'      => __( 'Blue Poppy Shop Page Options', 'blue-poppy'),
      'priority' => 11,
      'panel' => 'poppy_panel', 


  ) );
  
     //radio box sanitization function
        function bluepoppy_sanitize_radio( $input, $setting ){
          
            //input must be a slug: lowercase alphanumeric characters, dashes and underscores are allowed only
            $input = sanitize_key($input);
  
            //get the list of possible radio box options 
            $choices = $setting->manager->get_control( $setting->id )->choices;
                              
            //return input if valid or return default option
            return ( array_key_exists( $input, $choices ) ? $input : $setting->default );                
              
        }
        
    //image input sanitization function  
        function bluepoppy_sanitize_file( $file, $setting ) {
          
            //allowed file types
            $mimes = array(
                'jpg|jpeg|jpe' => 'image/jpeg',
                'gif'          => 'image/gif',
                'png'          => 'image/png'
            );
              
            //check file type from file name
            $file_ext = wp_check_filetype( $file, $mimes );
              
            //if file has a valid mime type return it, otherwise return default
            return ( $file_ext['ext'] ? $file : $setting->default );
        }
        

$wp_customize->add_setting( 'primary-color' , array(
    'default' 	=> '#f4dde5',
    'transport'   => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color'
  ) );

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'primary-color', array(
	'label'        => __('Primary Color', 'blue-poppy'),
	'section'    => 'bluepoppy-settings',
	'settings'   => 'primary-color',
) 
) );
$wp_customize->add_setting( 'accent-color' , array(
    'default' 	=> '#c3d3e0',
    'transport'   => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color'
  ) );

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'accent-color', array(
	'label'        => __('Accent Color', 'blue-poppy'),
	'section'    => 'bluepoppy-settings',
	'settings'   => 'accent-color',
) 
) );

  $wp_customize->add_setting( 'top-bar-color' , array(
    'default'     => '#c3d3e0',
    'transport'   => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color'
  ) );

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'top-bar-color', array(
	'label'       => __('Top Bar Color', 'blue-poppy'),
	'section'    => 'bluepoppy-settings',
	'settings'   => 'top-bar-color',
) ) );

$wp_customize->add_setting( 'pattern-options' , array(
      'default'     => 'background-stripes',
      'transport'   => 'refresh',
      'sanitize_callback' => 'bluepoppy_sanitize_radio'

  ) );

  $wp_customize->add_control( 'pattern-options', array(
  'label' => 'Patterns',
  'section' => 'bluepoppy-settings',
  'settings' => 'pattern-options',
  'type' => 'radio',
  'choices' => array(
    'background-stripes' => __('Stripes (default)', 'blue-poppy'),
    'background-dots' => __('Polka Dots', 'blue-poppy'),
    'background-triangles' => __('Triangles', 'blue-poppy'),
    'background-wavy' => __('Wavy Lines', 'blue-poppy'),
    'background-none' => __('None', 'blue-poppy'),

  ),
) );

  $wp_customize->add_setting( 'sticky-header' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'bluepoppy_sanitize_radio'

      
  ) );

  $wp_customize->add_control( 'sticky-header', array(
  'label' => __('Sticky Header', 'blue-poppy'),
  'section' => 'bluepoppy-settings',
  'settings' => 'sticky-header',
  'type' => 'radio',
  'choices' => array(
    'sticky' => __('On', 'blue-poppy'),
    'nosticky' => __('Off', 'blue-poppy'),
  ),
) );


$wp_customize->add_setting( 'divider-options' , array(
      'default'     => false,
      'transport'   => 'refresh',
      'sanitize_callback' => 'bluepoppy_sanitize_radio'

  ) );

  $wp_customize->add_control( 'divider-options', array(
  'label' => __('Display the logo or your site title?', 'blue-poppy'),
  'description' =>__('To upload a logo or edit your site title, the options for that are located in Customizer > Site Identity. To change the footer logo, scroll all the way down on this to page to locate the footer logo options.', 'blue-poppy'),
  'section' => 'bluepoppy-settings',
  'settings' => 'divider-options',
  'type' => 'radio',
  'choices' => array(
    'logo' => __('Logo', 'blue-poppy'),
    'site-title' => __('Site Title', 'blue-poppy'),
  ),
) );



$wp_customize->add_setting( 'sidebar-options' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'bluepoppy_sanitize_radio'

  ) );

  $wp_customize->add_control( 'sidebar-options', array(
  'label' => 'Sidebars',
  'section' => 'bluepoppy-settings',
  'settings' => 'sidebar-options',
  'type' => 'radio',
  'choices' => array(
    'sidebar-on' => __('On', 'blue-poppy'),
    'sidebar-off' => __('Off', 'blue-poppy'),
  ),
) );

$wp_customize->add_setting( 'featured-pages' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'featured-pages', array(
  'label' => __('Turn off featured images on pages?', 'blue-poppy'),
  'section' => 'bluepoppy-settings',
  'settings' => 'featured-pages',
  'type' => 'checkbox',

) );


$wp_customize->add_setting( 'author-siggy' , array(
      'default'     => __('XOXO, Sara', 'blue-poppy'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'

  ) );

  $wp_customize->add_control( 'author-siggy', array(
  'label' => __('Author Signature', 'blue-poppy'),
  'section' => 'bluepoppy-settings',
  'settings' => 'author-siggy',
  'type' => 'text',
) );

$wp_customize->add_setting( 'custom-search-text' , array(
      'default'     => __('I&#39;m looking for... ', 'blue-poppy'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( 'custom-search-text', array(
   'label' => __('Custom search text:', 'blue-poppy'),
   'section'	=> 'bluepoppy-settings',
   'type'	 => 'text',
   

) );

$wp_customize->add_setting( 'read-more-text' , array(
      'default'     => __('Read More', 'blue-poppy'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( 'read-more-text', array(
   'label' => __('Custom "read more" text:', 'blue-poppy'),
   'section'	=> 'bluepoppy-settings',
   'type'	 => 'text',
   

) );

$wp_customize->add_setting( '404-page-title' , array(
      'default'     => __('Oops! Page Not Found', 'blue-poppy'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( '404-page-title', array(
   'label' => __('Custom title for 404 pages', 'blue-poppy'),
   'section'	=> 'bluepoppy-settings',
   'type'	 => 'text',
   

) );

$wp_customize->add_setting( '404-page-message' , array(
      'default'     => __('Sorry, the page you are looking for is not here.', 'blue-poppy'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( '404-page-message', array(
   'label' => __('Custom message for 404 pages', 'blue-poppy'),
   'section'	=> 'bluepoppy-settings',
   'type'	 => 'textarea',

) );

$wp_customize->add_setting( 'privacy-policy' , array(
      'default'     => '#',
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_attr'
  ) );

  $wp_customize->add_control( 'privacy-policy', array(
   'label' => __('Your privacy policy URL. This will display on the contact form.', 'bubble-tea'),
   'section'	=> 'bluepoppy-settings',
   'type'	 => 'text',

) );

$wp_customize->add_setting( 'footer-logo-ask' , array(
      'default'     => false,
      'transport'   => 'refresh',
      'sanitize_callback' => 'bluepoppy_sanitize_radio'

  ) );

  $wp_customize->add_control( 'footer-logo-ask', array(
  'label' => __('Display a logo in the footer:', 'blue-poppy'),
  'section' => 'bluepoppy-settings',
  'settings' => 'footer-logo-ask',
  'type' => 'radio',
  'choices' => array(
    'footer-logo-on' => __('On', 'blue-poppy'),
    'footer-logo-off' => __('Off', 'blue-poppy'),
  ),
) );

 $wp_customize->add_setting('footer-logo', array(
      'default'     => "",
      'transport'   => 'refresh',
      'sanitize_callback' => 'bluepoppy_sanitize_file'
    ));
    
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'footer-logo', array(
        'label' => __('Upload logo:', 'blue-poppy'),
        'description' => __('The logo must be white (or bright) if you want it to show up. If the image is huge and massive (over 500kb), please size it down before uploading or risk slowing down your page.', 'blue-poppy'),
        'settings'  => 'footer-logo',
        'section'   => 'bluepoppy-settings',
    )));
    
  $wp_customize->add_setting( 'copyright' , array(
      'default'     => __('Copyright', 'blue-poppy'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( 'copyright', array(
   'label' => __('Custom Copyright Text (add the name of your site here (optional).', 'blue-poppy'),
   'section'	=> 'bluepoppy-settings',
   'type'	 => 'text',

) );  

$wp_customize->add_setting( 'lazy-option' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'lazy-option', array(
  'label' => __('Disable lazy loading images?', 'blue-poppy'),
  'description' => __('Check this if you are already running an optimization plugin. If you are unsure, just leave this alone.', 'blue-poppy'),
  'section' => 'bluepoppy-settings',
  'settings' => 'lazy-option',
  'type' => 'checkbox',

) );
$wp_customize->add_setting( 'widget-block-option' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'widget-block-option', array(
  'label' => __('Turn on Gutenberg widget screen?', 'blue-poppy'),
  'description' => __('Check this if you want to turn on the new Gutenberg widget screen. For 5.8 and above.)', 'blue-poppy'),
  'section' => 'bluepoppy-settings',
  'settings' => 'widget-block-option',
  'type' => 'checkbox',

) );
	
}	

/**
 * Customizer settings for social links that appear in the menu/footer
 */
	
function my_add_social_sites_customizer($wp_customize) {

 
	$wp_customize->add_section( 'my_social_settings', array(
			'title'    => __('Social Media Icons', 'blue-poppy'),
			'priority' => 35,
			'panel' => 'bluepoppy_homepage_panel',
	) );
 
	$social_sites = my_customizer_social_media_array();
	$priority = 5;
 
	foreach($social_sites as $social_site) {
 
		$wp_customize->add_setting( "$social_site", array(
				'type'              => 'theme_mod',
				'capability'        => 'edit_theme_options',
				'sanitize_callback' => 'esc_attr'
		) );
 
		$wp_customize->add_control( $social_site, array(
				'label'    => __( "$social_site url:", 'blue-poppy' ),
				'section'  => 'my_social_settings',
				'type'     => 'text',
				'priority' => $priority,
		) );
 
		$priority = $priority + 5;
	}
}

/* takes user input from the customizer and outputs linked social media icons */
function my_social_media_icons() {
 
    $social_sites = my_customizer_social_media_array();
 
    /* any inputs that aren't empty are stored in $active_sites array */
    foreach($social_sites as $social_site) {
        if( strlen( get_theme_mod( $social_site ) ) > 0 ) {
            $active_sites[] = $social_site;
        }
    }
 
    /* for each active social site, add it as a list item */
        if ( ! empty( $active_sites ) ) {
 
            echo "<ul class='social-media-icons'>";
 
            foreach ( $active_sites as $active_site ) {
 
	            /* setup the class */
		        $class = 'fa fa-' . $active_site;
 
                if ( $active_site == 'email' ) {
                    ?>
                    <li>
                        <a class="email" target="_blank" href="mailto:<?php echo antispambot( is_email( get_theme_mod( $active_site ) ) ); ?>">
                            <i class="fa fa-envelope" title="<?php _e('email icon', 'blue-poppy'); ?>"></i>
                        </a>
                    </li>
                    
                <?php } elseif ( $active_site == 'bloglovin' ) { ?>
                
                  <li>
                        <a class="blogloving" target="_blank" href="<?php echo esc_url( get_theme_mod( $active_site) ); ?>">
                            <i class="fa fa-heart" title="<?php printf( __('%s icon', 'blue-poppy'), $active_site ); ?>"></i>
                        </a>
                    </li>

                <?php } else { ?>
                    <li>
                        <a class="<?php echo $active_site; ?>" target="_blank" href="<?php echo esc_url( get_theme_mod( $active_site) ); ?>">
                            <i class="<?php echo esc_attr( $class ); ?>" title="<?php printf( __('%s icon', 'blue-poppy'), $active_site ); ?>"></i>
                        </a>
                    </li>
                <?php
                }
            }
            echo "</ul>";
        }
        
      else {
        echo "<ul class='social-media-icons'><li><a class='twitter' href='#'><i class='fa fa-twitter' title='twitter icon'></i></a></li><li><a class='facebook' href='#'><i class='fa fa-facebook' title='facebook icon'></i></a></li><li><a class='pinterest' href='#'><i class='fa fa-pinterest' title='pinterest icon'></i></a></li><li><a class='instagram' href='#'><i class='fa fa-instagram' title='instagram icon'></i></a></li></ul>";
	}
}	

add_action( 'customize_register', 'bluepoppy_customizer_settings' );

add_action( 'customize_register', 'my_add_social_sites_customizer' );
