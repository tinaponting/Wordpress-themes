<?php
/**
 /* Admin page that gives instruction to the user.
*/


function bluepoppy_admin_page(){
$welcome_img = get_template_directory_uri() . '/images/poppy-header.jpg';
$welcome_url = 'https://littlethemeshop.com/documentation/blue-poppy';
$manual_url = 'https://littlethemeshop.com/documentation/simple-quick-setup/#manual';
	?>
	<div class="welcome-wrap">
		<img src="<?php echo $welcome_img; ?>">
		<h1><?php esc_html_e('Getting Started', 'blue-poppy'); ?></h1>
		<p><?php esc_html_e('Hey, there! Thanks for downloading Blue Poppy. Ready to build your cute website? Here&#39;s how to set up your new theme in seconds.', 'blue-poppy'); ?></p>
 		<iframe width="560" height="315" style="margin:0 auto;display:block;" src="https://www.youtube.com/embed/CezNAiEeW98" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
 		<p><strong><?php esc_html_e('Step 1:', 'blue-poppy'); ?></strong>
            <?php printf( esc_html__( 'Check Your Homepage! The drag-and-drop homepage, main menu, and page templates were generated during activation. Take a look and make sure they were all generated correctly. If you see any issues, here&#39;s how to %1$s', 'blue-poppy'),
   				 sprintf(
					'<a href="%s">%s</a>',
        			$manual_url,
        			esc_html__( 'set the homepage up manually.', 'blue-poppy' )
       				 )
   				 ); ?>
        </p>
         <p><strong><?php esc_html_e('Step 2:', 'blue-poppy'); ?></strong>
            <?php esc_html_e( 'Import Demo Content. If your site is brand new and has zero content, import demo content by going to Tools > Import and uploading the .XML file provided for you. Make sure to select "Download and import file attachments."', 'blue-poppy'); ?>
                </p>
                <p><strong><?php _e('Step 3:', 'blue-poppy'); ?></strong>
                    <?php esc_html_e( 'Start Customizing. Once your homepage is looking good, click "Customize" in your admin bar to start customizing your site. See, we told you it would be easy!', 'blue-poppy'); ?>
                </p>
                
           <p><?php printf(
   				 esc_html__( 'If you have any other questions, make sure to read the %1$s.', 'blue-poppy' ),
   				 sprintf(
					'<a href="%s">%s</a>',
        			$welcome_url,
        			esc_html__( 'documentation/instructions', 'blue-poppy' )
       				 )
   				 ); ?>
	</div>
	<?php
}

