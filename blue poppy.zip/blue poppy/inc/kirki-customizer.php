<?php
/**
 * All the Kirki controls
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Do not proceed if Kirki does not exist.
if ( ! class_exists( 'Kirki' ) ) {
	return;
}

/**
 * First of all, add the config.
 *
 * @link https://kirki.org/docs/getting-started/config.html
 */
Kirki::add_config(
	'blue_poppy',
	array(
		'capability'  => 'edit_theme_options',
		'option_type' => 'theme_mod',
	)
);

/**
 * Add a panel.
 *
 * @link https://kirki.org/docs/getting-started/panels.html
 */
 
 Kirki::add_panel(
	'poppy_panel',
	array(
		'priority'    => 10,
		'title'       => esc_html__( 'Blue Poppy Options', 'blue-poppy' ),
		'description' => esc_html__( 'All the functions for the theme', 'blue-poppy' ),
	)
);


Kirki::add_panel(
	'bluepoppy_homepage_panel',
	array(
		'priority'    => 11,
		'title'       => esc_html__( 'Blue Poppy Homepage Sections', 'blue-poppy' ),
		'description' => esc_html__( 'All the functions for the homepage sections.', 'blue-poppy' ),
		'panel' => 'poppy_panel', 

	)
);

/**
 * Add Sections.
 *
 * We'll be doing things a bit differently here, just to demonstrate an example.
 * We're going to define 1 section per control-type just to keep things clean and separate.
 *
 * @link https://kirki.org/docs/getting-started/sections.html
 */
$sections = array(
	'fonts'			=> array( esc_html__('Fonts', 'blue-poppy'), ''),
	'layout'        => array( esc_html__( 'Layout', 'blue-poppy' ), '' ),
	'slider'        => array( esc_html__( 'Content Slider', 'blue-poppy' ), '' ),
	'links'           => array( esc_html__( 'Links', 'blue-poppy' ), '' ),
	'blog1'       => array( esc_html__( 'Featured Posts', 'blue-poppy' ), '' ),
	'subscribe'           => array( esc_html__( 'Subscribe', 'blue-poppy' ), '' ),
	'blog2'           => array( esc_html__( 'Blog Posts 2 Columns', 'blue-poppy' ), '' ),
	'buythebook'           => array( esc_html__( 'Featured Section', 'blue-poppy' ), '' ),
	'blog3'           => array( esc_html__( 'Blog Posts 3 Columns', 'blue-poppy' ), '' ),
	'about'           => array( esc_html__( 'About Me', 'blue-poppy' ), '' ),
	'mission'          => array( esc_html__( 'Quote', 'blue-poppy' ), '' ),
	'widgets'           => array( esc_html__( 'Widgets Area', 'blue-poppy' ), '' ),
	'page'            => array( esc_html__( 'Page', 'blue-poppy' ), esc_html__( 'Display a Wordpress page in a section. Use this if, for example, you wanted to use a shortcode from a third-party plugin.', 'blue-poppy' ) ),
);
foreach ( $sections as $section_id => $section ) {
	$section_args = array(
		'title'       => $section[0],
		'description' => $section[1],
		'panel'       => 'bluepoppy_homepage_panel',
	);
	if ( isset( $section[2] ) ) {
		$section_args['type'] = $section[2];
	}
	Kirki::add_section( str_replace( '-', '_', $section_id ) . '_section', $section_args );
}


/**
 * A proxy function. Automatically passes-on the config-id.
 *
 * @param array $args The field arguments.
 */
function bluepoppy_config_kirki_add_field( $args ) {
	Kirki::add_field( 'blue_poppy', $args );
}


/**
 * Page Control.
 */
 
 bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'bluepoppypage-headline',
		'label'       => esc_html__( 'Section Title', 'blue-poppy' ),
		'section'     => 'page_section',
		'default'     => __( 'Page Section', 'blue-poppy'),

	)
);


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'dropdown-pages',
		'settings'    => 'bluepoppypage-dropdown',
		'label'       => esc_html__( 'Pages', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a page below.', 'blue-poppy' ),
		'section'     => 'page_section',
		'default'     => array(
			'width'  => '100px',
			'height' => '100px',
		),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'color',
		'settings'    => 'page-color-hex',
		'label'       => __( 'Color Control', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a color for the background (optional).', 'blue-poppy' ),
		'section'     => 'page_section',
		'default'     => '#d6cadb',
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'color',
		'settings'    => 'page-color-hex2',
		'label'       => __( 'Color Control', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a color for the title.', 'blue-poppy' ),
		'section'     => 'page_section',
		'default'     => '#FDFDBF',
	)
);

/**
 * Slider Control.
 */ 
 

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'slider-cat',
		'label'       => esc_html__( 'Enter a category name. By default, the slider shows only five of your most recent posts. Leave blank if you want it to show all categories.', 'blue-poppy' ),
		'section'     => 'slider_section',
		'default'     => '',

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-slider',
		'label'       => esc_html__( 'Is this section on the top of your homepage? If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'slider_section',
		'default'     => true,

	)
);



/**
 * About Control.
 */
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'image',
		'settings'    => 'about-image',
		'label'       => esc_html__( 'Image Upload', 'blue-poppy' ),
		'description' => esc_html__( 'Upload a profile pic here.', 'blue-poppy' ),
		'section'     => 'about_section',
		'default'     => get_template_directory_uri() . '/images/about-demo.jpg',
		'choices' => array(
			'save_as' => 'id',
		)
	)
);


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'about-headline',
		'label'       => esc_html__( 'Section Title', 'blue-poppy' ),
		'section'     => 'about_section',
		'default'     => __( 'Hey, there!', 'blue-poppy'),

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'typography',
		'settings'    => 'about-font',
		'label'       => esc_html__( 'Font (optional)', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a font for the text if you do not want to use the default script. Use em units for font size and line height (example: 1.5em).', 'blue-poppy' ),
		'section'     => 'about_section',
		'priority'    => 10,
		'transport'   => 'auto',
		'default'     => array(
			'font-family' => 'Westhouse',
			'variant'     => '400',
			'font-size'   => '',
			'line-height' => '',
		),
		'choices'     => array(
			'fonts' => array(
				'google'   => array( 'popularity', 50 ),
				'standard'   => array( 'Amatic SC', 'Satisfy', 'Sacramento','Sofia','Rogue Script','Crimson Text', 'Playfair Display', 'Libre Baskerville', 'Old Standard TT', 'Kristi', 'Seaweed Script', 'Rochester', 'Petit Formal Script', 'Emilys Candy', 'Mr De Haviland', 'Alex Brush', 'Aguafina Script', 'Stalemate'),
				),
			),		
		'output'      => array(
			array(
				'element' => array( '.about-content h2' ),
			),
		),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'editor',
		'settings'    => 'about-text',
		'label'       => esc_html__( 'Text Editor', 'blue-poppy' ),
		'description' => esc_html__( 'Describe yourself! Add a short bio here.', 'blue-poppy' ),
		'section'     => 'about_section',
		'default'     => __('After a while, finding that nothing more happened, she decided on going into the garden at once; but, alas for poor Alice! when she got to the door, she found she had forgotten the little golden key, and when she went back to the table for it, she found she could not possibly reach it.', 'blue-poppy'),
	)
);


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'color',
		'settings'    => 'about-color-hex',
		'label'       => __( 'Color Control', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a color for the background.', 'blue-poppy' ),
		'section'     => 'about_section',
		'default'     => '',
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-about',
		'label'       => esc_html__( 'Is this section on the top of your homepage? If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'about_section',
		'default'     => false,

	)
);




/**
 * Blog Posts 1 Control.
 */
 
 
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog1-headline',
		'label'       => esc_html__( 'Section Title', 'blue-poppy' ),
		'section'     => 'blog1_section',
		'default'     => 'What&#39;s New',

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog1-cat',
		'label'       => esc_html__( 'Enter a category name. By default, this section only displays five posts. Leave blank to show all categories.', 'blue-poppy' ),
		'section'     => 'blog1_section',
		'default'     => '',

	)
);
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog1-offset',
		'label'		  => esc_html__('Offset Number', 'blue-poppy'),
		'description' => esc_html__( 'If you have more than one blog section displaying the most recent posts (and, thus, are seeing repeating posts) fix this by adding an offset number below. This number tells Wordpress how many posts to ignore/bypass. Example: Enter a "5" below if you want this blog section to display the 6th most recent post instead of the first.', 'blue-poppy' ),
		'section'     => 'blog1_section',
		'default'     => '',

	)
);
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-blog1',
		'label'       => esc_html__( 'Is this section on the top of your homepage?', 'blue-poppy' ),
		'description' => esc_html__( 'If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'blog1_section',
		'default'     => false,

	)
);



/**
 * Blog Posts 2 Control.
 */
 
 
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog2-headline',
		'label'       => esc_html__( 'Section Title', 'blue-poppy' ),
		'section'     => 'blog2_section',
		'default'     => 'Lifestyle',

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog2-cat',
		'label'       => esc_html__( 'Category Name', 'blue-poppy' ),
		'section'     => 'blog2_section',
		'default'     => '',

	)
);


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'number',
		'settings'    => 'blog2-number',
		'label'       => esc_html__( 'How Many Posts to Display?', 'blue-poppy' ),
		'section'     => 'blog2_section',
		'default'     => 4,

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog2-offset',
		'label'		  => esc_html__('Offset Number', 'blue-poppy'),
		'description' => esc_html__( 'If you have more than one blog section displaying the most recent posts (and, thus, are seeing repeating posts) fix this by adding an offset number below. This number tells Wordpress how many posts to ignore/bypass. Example: Enter a "5" below if you want this blog section to display the 6th most recent post instead of the first.', 'blue-poppy' ),
		'section'     => 'blog2_section',
		'default'     => '',

	)
);
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-blog2',
		'label'       => esc_html__( 'Is this section on the top of your homepage?', 'blue-poppy' ),
		'description' => esc_html__( 'If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'blog2_section',
		'default'     => false,

	)
);

/**
 * Blog Posts 3 Control.
 */
 
 
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog3-headline',
		'label'       => esc_html__( 'Section Title', 'blue-poppy' ),
		'section'     => 'blog3_section',
		'default'     => 'Art & Fashion',

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog3-cat',
		'label'       => esc_html__( 'Category Name', 'blue-poppy' ),
		'section'     => 'blog3_section',
		'default'     => '',

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'number',
		'settings'    => 'blog3-number',
		'label'       => esc_html__( 'How Many Posts to Display?', 'blue-poppy' ),
		'section'     => 'blog3_section',
		'default'     => 6,

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'blog3-offset',
		'label'		  => esc_html__('Offset Number', 'blue-poppy'),
		'description' => esc_html__( 'If you have more than one blog section displaying the most recent posts (and, thus, are seeing repeating posts) fix this by adding an offset number below. This number tells Wordpress how many posts to ignore/bypass. Example: Enter a "5" below if you want this blog section to display the 6th most recent post instead of the first.', 'blue-poppy' ),
		'section'     => 'blog3_section',
		'default'     => '',

	)
);
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-blog3',
		'label'       => esc_html__( 'Is this section on the top of your homepage?', 'blue-poppy' ),
		'description' => esc_html__( 'If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'blog3_section',
		'default'     => false,

	)
);



/**
 * Links Control.
 */
 
 
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'repeater',
		'settings'    => 'link_repeater',
		'label'       => esc_html__( 'Link', 'blue-poppy' ),
		'description' => esc_html__( 'To add a link, select "add new field." Links can be reordered, and you can add as many as you want.', 'blue-poppy' ),
		'section'     => 'links_section',
		'default'     => array(
			array(
				'link_name'    => esc_html__( 'Blog', 'blue-poppy' ),
				'link_url'	   => 'https://littlethemeshop.com',
			),
			array(
				'link_name'    => esc_html__( 'Shop', 'blue-poppy' ),
				'link_url'    => 'https://littlethemeshop.com',
			),
			array(
				'link_name'    => esc_html__( 'Goodies', 'blue-poppy' ),
				'link_url'    => 'https://littlethemeshop.com',
			),
			array(
				'link_name'    => esc_html__( 'Contact', 'blue-poppy' ),
				'link_url'    => 'https://littlethemeshop.com',
			),
		),
		'fields'      => array(
			    'link_name'   => array(
				'type'        => 'text',
				'label'       => esc_html__( 'The name of your link', 'blue-poppy' ),
				'default'     => '',
			),
				'link_url'   => array(
				'type'        => 'link',
				'label'       => esc_html__( 'The url', 'blue-poppy' ),
				'default'     => '',
			),
		),
	)
);


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-links',
		'label'       => esc_html__( 'Is this section on the top of your homepage? If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'links_section',
		'default'     => false,

	)
);

/**
 * Subscribe Control.
 */
 
 bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'editor',
		'settings'    => 'subscribe-text',
		'label'       => esc_html__( 'Subscribe Text', 'blue-poppy' ),
		'description' => esc_html__('To get the script accent to appear, bold the selected text.', 'blue-poppy'),
		'section'     => 'subscribe_section',
		'default'     => 'Join thousands of fans and get our weekly newsletter every week!',

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'remove-subscribe-button',
		'label'       => esc_html__( 'Remove Subscribe Button?', 'blue-poppy' ),
		'section'     => 'subscribe_section',
		'default'     => false,

	)
);

 
 bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'subscribe-button',
		'label'       => esc_html__( 'Subscribe Button', 'blue-poppy' ),
		'section'     => 'subscribe_section',
		'default'     => __( 'Sign Up', 'blue-poppy'),

	)
);

 bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'link',
		'settings'    => 'subscribe-url',
		'label'       => esc_html__( 'Subscribe URL', 'blue-poppy' ),
		'section'     => 'subscribe_section',
		'default'     => 'https://littlethemeshop.com/',

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'color',
		'settings'    => 'subscribe-color-hex',
		'label'       => __( 'Color Control', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a color for the background.', 'blue-poppy' ),
		'section'     => 'subscribe_section',
		'default'     => '#c3d3e0',
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-subscribe',
		'label'       => esc_html__( 'Is this section on the top of your homepage? If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'subscribe_section',
		'default'     => false,

	)
);

/**
 * Buy The Book Control.
 */
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'image',
		'settings'    => 'buythebook-image',
		'label'       => esc_html__( 'Image Upload', 'blue-poppy' ),
		'description' => esc_html__( 'Upload a pic here.', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'default'     => get_template_directory_uri() . '/images/featured-demo.jpg',
		'choices' => array(
			'save_as' => 'id',
		)
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'buythebook-headline',
		'label'       => esc_html__( 'Section Title', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'default'     => __( 'Welcome to My Site', 'blue-poppy'),

	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'typography',
		'settings'    => 'buythebook-setting',
		'label'       => esc_html__( 'Font (optional)', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a font for the title if you do not want to use the default script. Use em units for font size and line height (example: 1.5em).', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'priority'    => 10,
		'transport'   => 'auto',
		'default'     => array(
			'font-family' => 'Westhouse',
			'variant'     => '400',
			'font-size'   => '',
			'line-height' => '',
		),
		'choices'     => array(
			'fonts' => array(
				'google'   => array( 'popularity', 50 ),
				'standard'   => array( 'Amatic SC', 'Satisfy', 'Sacramento','Sofia','Rogue Script','Crimson Text', 'Playfair Display', 'Libre Baskerville', 'Old Standard TT', 'Kristi', 'Seaweed Script', 'Rochester', 'Petit Formal Script', 'Emilys Candy', 'Mr De Haviland', 'Alex Brush', 'Aguafina Script', 'Stalemate'),
				),
			),		
		'output'      => array(
			array(
				'element' => array( '.buythebook-content h2' ),
			),
		),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'editor',
		'settings'    => 'buythebook-text',
		'label'       => esc_html__( 'Text Editor', 'blue-poppy' ),
		'description' => esc_html__( 'Enter text here:', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'default'     => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Purus gravida quis blandit turpis cursus in. Magna sit amet purus gravida. Vel elit scelerisque mauris pellentesque pulvinar pellentesque. Porttitor massa id neque aliquam vestibulum morbi blandit cursus risus.', 'blue-poppy'),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'buythebook-link-text',
		'label'       => esc_html__( 'URL Text', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'default'     => __('Learn More', 'blue-poppy'),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'link',
		'settings'    => 'buythebook-link',
		'label'       => esc_html__( 'URL', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'default'     => 'https://littlethemeshop.com',
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'color',
		'settings'    => 'buythebook-color-hex',
		'label'       => __( 'Color Control', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a color for the background (optional).', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'default'     => '',
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'checkbox',
		'settings'    => 'padding-off-buythebook',
		'label'       => esc_html__( 'Is this section on the top of your homepage? If so, check the box to remove the excess white space on top.', 'blue-poppy' ),
		'section'     => 'buythebook_section',
		'default'     => false,

	)
);

/**
 * Mission Control
 */


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'textarea',
		'settings'    => 'mission-headline',
		'label'       => esc_html__( 'Quote', 'blue-poppy' ),
		'section'     => 'mission_section',
		'default'     => __( '"There is no moment in life that can&#39;t be improved with pizza."', 'blue-poppy'),

	)
);


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'typography',
		'settings'    => 'mission-font',
		'label'       => esc_html__( 'Font (optional)', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a font for the text if you do not want to use the default script. Use em units for font size and line height (example: 1.5em).', 'blue-poppy' ),
		'section'     => 'mission_section',
		'priority'    => 10,
		'transport'   => 'auto',
		'default'     => array(
			'font-family' => 'Westhouse',
			'variant'     => '400',
			'font-size'   => '',
			'line-height' => '',
		),
		'choices'     => array(
			'fonts' => array(
				'google'   => array( 'popularity', 50 ),
				'standard'   => array( 'Amatic SC', 'Satisfy', 'Sacramento','Sofia','Rogue Script','Crimson Text', 'Playfair Display', 'Libre Baskerville', 'Old Standard TT', 'Kristi', 'Seaweed Script', 'Rochester', 'Petit Formal Script', 'Emilys Candy', 'Mr De Haviland', 'Alex Brush', 'Aguafina Script', 'Stalemate'),
				),
			),		
		'output'      => array(
			array(
				'element' => array( '.mission-section h2' ),
			),
		),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'text',
		'settings'    => 'mission-text',
		'label'       => esc_html__( 'Caption', 'blue-poppy' ),
		'section'     => 'mission_section',
		'default'     => __('Daria Morgendorffer', 'blue-poppy'),
	)
);


bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'color',
		'settings'    => 'mission-color-hex',
		'label'       => __( 'Color Control', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a color for the background.', 'blue-poppy' ),
		'section'     => 'mission_section',
		'default'     => '#e8e4e1',
	)
);


/**
 * Links Control.
 */
 
 
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'repeater',
		'settings'    => 'product_repeater',
		'label'       => esc_html__( 'Shop Page', 'blue-poppy' ),
		'description' => esc_html__( 'To add a product, select "add new field." Products can be reordered, and you can add as many as you want.', 'blue-poppy' ),
		'section'     => 'bluepoppy-shop-settings',
		'default'     => array(
			array(
				'product_img'    => get_template_directory_uri() . '/images/demo-product1.jpg',
				'product_name'    => esc_html__( 'Desktop Cactus', 'blue-poppy' ),
				'product_url'	   => 'https://littlethemeshop.com',
			),
			array(
				'product_img'    => get_template_directory_uri() . '/images/demo-product2.jpg',
				'product_name'    => esc_html__( 'Small Potted Plants', 'blue-poppy' ),
				'product_url'    => 'https://littlethemeshop.com',
			),
			array(
				'product_img'    => get_template_directory_uri() . '/images/demo-product3.jpg',
				'product_name'    => esc_html__( 'Pink Flowers', 'blue-poppy' ),
				'product_url'    => 'https://littlethemeshop.com',
			),
		),
		'fields'      => array(
				'product_img'   => array(
				'type'        => 'image',
				'label'       => esc_html__( 'The image', 'blue-poppy' ),
				'default'     => '',
			),
			    'product_name'   => array(
				'type'        => 'text',
				'label'       => esc_html__( 'The name of your product', 'blue-poppy' ),
				'default'     => '',
			),
				'product_url'   => array(
				'type'        => 'link',
				'label'       => esc_html__( 'The url', 'blue-poppy' ),
				'default'     => '',
			),
		),
	)
);






/**
 * Layout control.
 */
bluepoppy_config_kirki_add_field(
	array(
		'type'     => 'sortable',
		'settings' => 'homepage_layout',
		'label'    => __( 'Drag and drop the sections below to change the layout order. You can turn sections on and off by clicking on them', 'blue-poppy' ),
		'section'  => 'layout_section',
		'default'  => array( 'slider', 'links', 'blog1', 'subscribe', 'blog2', 'mission', 'blog3', 'about', 'widgets' ),
		'choices'  => array(
			'slider' => esc_html__( 'Content Slider', 'blue-poppy' ),
			'mission' => esc_html__( 'Quote', 'blue-poppy' ),
			'blog1' => esc_html__( 'Featured Posts', 'blue-poppy' ),
			'subscribe' => esc_html__( 'Subscribe', 'blue-poppy' ),
			'blog2' => esc_html__( 'Blog Posts (2 Columns)', 'blue-poppy' ),
			'buythebook' => esc_html__( 'Featured Section', 'blue-poppy' ),
			'blog3' => esc_html__( 'Blog Posts (3 Columns)', 'blue-poppy' ),
			'about' => esc_html__( 'About Me', 'blue-poppy' ),
			'links' => esc_html__( 'Links', 'blue-poppy' ),
			'widgets' => esc_html__( 'Widgets', 'blue-poppy' ),
			'plugpage' => esc_html__( 'Page', 'blue-poppy' ),
		),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'typography',
		'settings'    => 'font_family_title_setting',
		'label'       => esc_html__( 'Site Title Font', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a font for the site title. Remember to have "site title" checked under "display logo or site title" under Customizer > Blue Poppy General Theme Options.', 'blue-poppy' ),
		'section'     => 'fonts_section',
		'priority'    => 10,
		'transport'   => 'auto',
		'default'     => array(
			'font-family' => 'Roboto Slab',
			'variant'     => '300',

		),
		'choices'     => array(
			'fonts' => array(
				'google'   => array( 'popularity', 50 ),
				),
			),		
		'output'      => array(
			array(
				'element' => array( '.container .site-title', '.footer-wrapper .logo-container h4' ),
			),
		),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'typography',
		'settings'    => 'font_family_setting',
		'label'       => esc_html__( 'Header Font', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a font for the headers.', 'blue-poppy' ),
		'section'     => 'fonts_section',
		'priority'    => 10,
		'transport'   => 'auto',
		'default'     => array(
			'font-family' => 'Montserrat',
			'variant'     => '500',

		),
		'choices'     => array(
			'fonts' => array(
				'google'   => array( 'popularity', 50 ),
				),
			),		
		'output'      => array(
			array(
				'element' => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', '.curved', '.big-first' ),
			),
		),
	)
);
bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'typography',
		'settings'    => 'font_family_body_setting',
		'label'       => esc_html__( 'Body Font', 'blue-poppy' ),
		'description' => esc_html__( 'Choose a font for the body.', 'blue-poppy' ),
		'section'     => 'fonts_section',
		'priority'    => 10,
		'transport'   => 'auto',
		'default'     => array(
			'font-family' => 'Raleway',
			'variant'     => '400',
		),
		'choices'     => array(
			'fonts' => array(
				'google'   => array( 'popularity', 50 ),
				),
			),		
		'output'      => array(
			array(
				'element' => array( 'body', 'p', 'em', 'strong', 'ul', 'ol', 'input' ),
			),
		),
	)
);

bluepoppy_config_kirki_add_field(
	array(
		'type'        => 'typography',
		'settings'    => 'script_font_family_setting',
		'label'       => esc_html__( 'Script Font (optional)', 'blue-poppy' ),
		'description' => esc_html__( 'Override the default script font here. You can change the script font for the Feaured Section, About Section, and Quote Section individually in their respective settings. ', 'blue-poppy' ),
		'section'     => 'fonts_section',
		'priority'    => 10,
		'transport'   => 'auto',
		'default'     => array(
			'font-family' => 'Westhouse',
			'variant'     => '400',

		),
		'choices'     => array(
			'fonts' => array(
				'google'   => array( 'popularity', 50 ),
				'standard'   => array( 'Amatic SC', 'Satisfy', 'Sacramento','Sofia','Rogue Script','Crimson Text', 'Playfair Display', 'Libre Baskerville', 'Old Standard TT', 'Kristi', 'Seaweed Script', 'Rochester', 'Petit Formal Script', 'Emilys Candy', 'Mr De Haviland', 'Alex Brush', 'Aguafina Script', 'Stalemate'),
				),
			),		
		'output'      => array(
			array(
				'element' => array( '.author-signature h5', '.page-title', '.entry-page-header .entry-title', '.about-widget-wrapper h3', '#reply-title', '.blog-headline', '.wp-block-pullquote p', '.subscribe-wrapper strong'),
			),
		),
	)
);

