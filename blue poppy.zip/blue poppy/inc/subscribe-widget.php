<?php
/**
 * Registers a "Subscribe" widget.
 *
 * @package Little Widgets
 */


function subscribe_widget() {
	register_widget( 'little_subscribe_widget' );
}
add_action( 'widgets_init', 'subscribe_widget' );


Class little_subscribe_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'little-subscribe-widget',
			__( 'Subscribe', 'little-widgets' ),
			array(
				'classname' => 'little-subscribe-widget',
				'description' => esc_html__( 'A widget to show off a subscribe item, product, or article.', 'little-widgets' ),
				'customize_selective_refresh' => true,
			)
		);
		add_action( 'load-widgets.php', array( $this, 'public_scripts' ) );

	}

	public function widget( $args, $instance ) {

		$name = empty( $instance['name'] ) ? '' : $instance['name'];
		$html = empty( $instance['html'] ) ? '' : $instance['html'];
		$bgcolor = empty( $instance['bgcolor'] ) ? '' : $instance['bgcolor'];

		echo $args['before_widget'];

		if ( ! empty( $title ) ) { echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; };

		do_action( 'wpiw_before_widget', $instance );?>

		<style type="text/css">
		.subscribe-widget-wrapper, .subscribe-widget-wrapper form {background-color: <?php echo $bgcolor; ?> !important;}
		</style>
		<div class="subscribe-widget-wrapper">
		<h3><?php echo wp_kses_post($name); ?></h3>
		<div class="raw-html"><?php echo $html; ?></div>
		
		</div>
		
		<?php do_action( 'wpiw_after_widget', $instance );

		echo $args['after_widget'];
	
	}
	

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' => __( 'subscribe', 'little-widgets' ),
			'name' => '',
			'html' => '',
			'bgcolor' => '#fff',

		) );
		$name = $instance['name'];
		$html = $instance['html'];
		$bgcolor = $instance['bgcolor'];
		?>

    
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>"><?php esc_html_e( 'Title', 'little-widgets' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'name' ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>" /></label></p>
		<p>
        <label for="<?= $this->get_field_id( 'html' ); ?>"><?php _e('Copy and paste your sign-up form code below. (If you use Mailchimp, for example, this code is provided for you.)', 'blue-poppy'); ?>
     
        <textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'html' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'html' ) ); ?>"><?php echo $html; ?></textarea></label></p>  


<label for="<?php echo $this->get_field_id( 'bgcolor' ); ?>" style="display:block;"><?php _e( 'Background Color:' ); ?></label> 
<input class="my-color-picker" id="<?php echo $this->get_field_id( 'bgcolor' ); ?>" name="<?php echo $this->get_field_name( 'bgcolor' ); ?>" type="text" value="<?php echo esc_attr( $bgcolor ); ?>" />

		<?php

	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['name'] = trim( strip_tags( $new_instance['name'] ) );
		$instance['html'] =  $new_instance['html'] ;
		$instance['bgcolor'] =  $new_instance['bgcolor'] ;


		return $instance;
	}
		

    function public_scripts() {

        // Register the script
        wp_enqueue_media();

        // Enqueue the script
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_script( 'subscribe-js', get_template_directory_uri() . '/js/widgets.js', array( 'jquery', 'wp-color-picker' ) );

    
    }
  }  






?>