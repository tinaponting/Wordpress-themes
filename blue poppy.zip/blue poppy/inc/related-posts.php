<?php 
/**
 * Function for "related posts."
 */

function related_posts() { ?>

<div class="relatedposts">
<?php
 
  global $post;
  $orig_post = $post;
  $tags = wp_get_post_tags($post->ID);
   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>4, // Number of related posts to display.
  'ignore_sticky_posts'=>1
  );
   $title = __('Related Posts', 'blue-poppy');
   $success = "<h3>{$title}</h3>";      
   
  $my_query = new wp_query( $args );
 
  if ( $my_query->have_posts() ) {
  echo $success; }

  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>
   
  <div class="relatedthumb"><div class="thumb-container">
     <a rel="external" href="<?php echo esc_url( get_permalink() );?>"><?php the_post_thumbnail('medium', array('class' => 'lazyload')); ?></div>
 		<?php the_title(); ?> 
 	 </a>
  </div>
  
   
  <?php }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>
</div>

<?php }