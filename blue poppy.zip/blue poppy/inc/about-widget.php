<?php
/**
 * Registers an About widget.
 *
 * @package Little Widgets
 */


function about_widget() {
	register_widget( 'little_about_widget' );
}
add_action( 'widgets_init', 'about_widget' );


Class little_about_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'little-about-widget',
			__( 'About Me', 'blue-poppy' ),
			array(
				'classname' => 'little-about-widget',
				'description' => esc_html__( 'An About Me Widget', 'blue-poppy' ),
				'customize_selective_refresh' => true,
			)
		);
		add_action( 'admin_enqueue_scripts', array( $this, 'public_scripts' ) );

	}

	public function widget( $args, $instance ) {

		$title = empty( $instance['title'] ) ? '' : apply_filters( 'widget_title', $instance['title'] );
		$name = empty( $instance['name'] ) ? '' : $instance['name'];
		$bio = empty( $instance['bio'] ) ? '' : $instance['bio'];
		$image = empty( $instance['image'] ) ? '' : $instance['image'];
		$linktext = empty( $instance['linktext'] ) ? '' : $instance['linktext'];
		$link = empty( $instance['link'] ) ? '' : $instance['link'];



		echo $args['before_widget'];

		if ( ! empty( $title ) ) { echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; };

		do_action( 'wpiw_before_widget', $instance );?>

		<div class="about-widget-wrapper">
		<img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_html($name); ?>">
		<h3><?php echo esc_html($name); ?></h3>
		<p><?php echo esc_html($bio); ?></p>
		<p><a href="<?php echo esc_url($link); ?>"><?php echo esc_html($linktext); ?></a></p>
		 		<?php my_social_media_icons(); ?>

		</div>
		
		<?php do_action( 'wpiw_after_widget', $instance );

		echo $args['after_widget'];
	
	}
	

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' => __( 'About', 'blue-poppy' ),
			'name' => '',
			'bio' => '',
			'image' => '',
			'link' => '',
			'linktext' => '',
		) );
		$title = $instance['title'];
		$name = $instance['name'];
		$bio = $instance['bio'];
		$image = $instance['image'];
		$link = $instance['link'];
		$linktext = $instance['linktext'];
		?>

    
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>"><?php esc_html_e( 'Name/Title', 'blue-poppy' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'name' ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>"><?php esc_html_e( 'Bio', 'blue-poppy' ); ?>: <textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'bio' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bio' ) ); ?>"><?php echo $bio; ?></textarea></label></p>

		
		<p>
        <label for="<?= $this->get_field_id( 'image' ); ?>">Image</label>
        <img class="<?= $this->id ?>_img" src="<?= (!empty($image)) ? $image : ''; ?>" style="margin:0;padding:0;max-width:100%;display:block"/>
        <input type="text" class="widefat <?= $this->id ?>_url the-image-src" name="<?= $this->get_field_name( 'image' ); ?>" value="<?= $image; ?>" style="margin-top:5px;" />
        <input type="button" id="<?= $this->id ?>" class="button button-primary js_custom_upload_media" value="Upload Image" style="margin-top:5px;" />
    </p>
        <p><label for="<?php echo esc_attr( $this->get_field_id( 'linktext' ) ); ?>"><?php esc_html_e( 'Link Text', 'blue-poppy' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linktext' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linktext' ) ); ?>" type="textarea" value="<?php echo esc_attr( $linktext ); ?>" /></label></p>
    	<p><label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Link URL', 'blue-poppy' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="textarea" value="<?php echo esc_attr( $link ); ?>" /></label></p>

		<?php

	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['name'] = trim( strip_tags( $new_instance['name'] ) );
		$instance['bio'] = trim( strip_tags( $new_instance['bio'] ) );
		$instance['image'] = strip_tags( $new_instance['image'] );
		$instance['link'] = strip_tags( $new_instance['link'] );
		$instance['linktext'] = strip_tags( $new_instance['linktext'] );
		return $instance;
	}
		

    function public_scripts() {

        // Register the script
        wp_enqueue_media();

        // Enqueue the script
        wp_enqueue_script('about-js', get_template_directory_uri() . '/js/widgets.js', array( 'jquery' ), NULL, true );

       
    
    }
  }  






?>