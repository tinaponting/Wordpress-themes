<?php
/**
 * Registers a widget to display Instagram hashtags.
 *
 * @package Little Widgets
 */


function bluepoppy_instagram_widget() {
	register_widget( 'bluepoppy_instagram_widget' );
}
add_action( 'widgets_init', 'bluepoppy_instagram_widget' );


Class bluepoppy_instagram_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'bluepoppy-instagram-feed',
			__( 'Instagram', 'blue-poppy' ),
			array(
				'classname' => 'bluepoppy-instagram-feed',
				'description' => esc_html__( 'Displays your latest Instagram photos', 'blue-poppy' ),
				'customize_selective_refresh' => true,
			)
		);
			// Public Scripts
		add_action( 'wp_enqueue_scripts', array( $this, 'public_scripts' ) );
		
		  if ( is_active_widget( false, $this->id, $this->id_base, true ) ) {
		add_action( 'wp_footer', array( $this, 'instagram_footer_script' ), 100 );
		}
	}

	public function widget( $args, $instance ) {
    	$this->is_active = true;  
		$title = empty( $instance['title'] ) ? '' : apply_filters( 'widget_title', $instance['title'] );
		$token = empty( $instance['token'] ) ? 'false' : $instance['token'];
		$newsize = empty( $instance['newsize'] ) ? '' : $instance['newsize'];
		$newitems = empty( $instance['newitems'] ) ? '' : $instance['newitems'];
		$wrap = empty( $instance['wrap'] ) ? false : $instance['wrap'];
		$items = empty( $instance['items'] ) ? 9 : $instance['items'];
		$size = empty( $instance['size'] ) ? '150' : $instance['size'];
		$username = empty( $instance['username'] ) ? '' : $instance['username'];
		$tag = empty( $instance['tag'] ) ? '' : $instance['tag'];
		$rows = empty( $instance['rows'] ) ? 2 : $instance['rows'];
		$profile = empty( $instance['profile'] ) ? 'false' : $instance['profile'];
		$bio = empty( $instance['bio'] ) ? 'false' : $instance['bio'];

		echo $args['before_widget'];

		if ( ! empty( $title ) ) { echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; };

		do_action( 'wpiw_before_widget', $instance );
		
		if ( ! empty( $instance['token'] ) ) echo '<div id="NewInstagramFeed" class="insta-'.$instance['newsize'].' '.($wrap ? ' instawrap' : false).'"></div>';
		else echo '<div id="instagramfeed1"></div>';
		
		do_action( 'wpiw_after_widget', $instance );

		echo $args['after_widget'];
		
		    // Localize the script with a new data
        wp_localize_script('instagram-js', 'instagramvars', array(
        'token' => $token,
        'newitems' => $newitems,
        'newsize' => $newsize,
        'wrap' => $wrap,
        'items' => $items,
        'size' => $size,
        'username' => $username,
        'tag' => $tag,
        'profile' => $profile,
        'bio' => $bio,
        'rows' => $rows,

        
        ));
	}
	

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' => __( 'Instagram', 'blue-poppy' ),
			'token' => '',
			'newitems' => 6,
			'newsize' => '',
			'wrap' => false,
			'items' => 6,
			'size' => '150',
			'username' => '',
			'tag' => '',
			'rows' => 2,
			'profile' => 'false',
			'bio' => 'false',
		) );
		$title = $instance['title'];
		$token = $instance['token'];
		$newitems = absint( $instance['newitems'] );
		$newsize = $instance['newsize'];
		$wrap = $instance['wrap'];
		$items = absint( $instance['items'] );
		$size = $instance['size'];
		$username = $instance['username'];
		$tag = $instance['tag'];
		$rows = absint( $instance['rows'] );
		$profile = $instance['profile'];
		$bio = $instance['bio'];
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'blue-poppy' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>
		

		<h3>Insta Settings</h3>
		<div id="new-settings">
		<p><a href="https://littlethemeshop.com/auth" target="_blank">Get Your Access Token Here</a><p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'token' ) ); ?>"><?php esc_html_e( 'Access Token', 'blue-poppy' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'token' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'token' ) ); ?>" type="text" value="<?php echo esc_attr( $token ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'newitems' ) ); ?>"><?php esc_html_e( 'Number of photos', 'blue-poppy' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'newitems' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'newitems' ) ); ?>" type="text" value="<?php echo esc_attr( $newitems ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'newsize' ) ); ?>"><?php esc_html_e( 'Photo size', 'blue-poppy' ); ?>:</label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'newsize' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'newsize' ) ); ?>" class="widefat">
				<option value="small" <?php selected( 'small', $newsize ); ?>><?php esc_html_e( 'small', 'blue-poppy' ); ?></option>
				<option value="medium" <?php selected( 'medium', $newsize ); ?>><?php esc_html_e( 'medium', 'blue-poppy' ); ?></option>
				<option value="large" <?php selected( 'large', $newsize ); ?>><?php esc_html_e( 'large', 'blue-poppy' ); ?></option>
			</select>
		</p>
		<p>
			<input class="checkbox" type="checkbox" value="1" <?php checked( $wrap, '1' ); ?> id="<?php echo $this->get_field_id( 'wrap' ); ?>" name="<?php echo $this->get_field_name( 'wrap' ); ?>" />
			<label for="<?php echo $this->get_field_id( 'wrap' ); ?>"><?php _e('Turn on image wrap? (Select this if you want multiple rows.)', 'blue-poppy' ); ?></label>
		</p>
		

		</div>

		<?php

	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['token'] = trim( strip_tags( $new_instance['token'] ) );
		$instance['newitems'] = absint( $new_instance['newitems'] );
		$instance['newsize'] = ( ( 'small' === $new_instance['newsize'] || 'medium' === $new_instance['newsize'] || 'large' === $new_instance['newsize'] ) ? $new_instance['newsize'] : 'false' );
		$instance['wrap'] = trim( strip_tags( $new_instance['wrap'] ) );
		$instance['items'] = ! absint( $new_instance['items'] ) ? 9 : $new_instance['items'];
		$instance['size'] = ( ( '150' === $new_instance['size'] || '240' === $new_instance['size'] || '320' === $new_instance['size'] || '480' === $new_instance['size'] || '640' === $new_instance['size'] ) ? $new_instance['size'] : '150' );
		$instance['username'] = trim( strip_tags( $new_instance['username'] ) );
		$instance['tag'] = trim( strip_tags( $new_instance['tag'] ) );
		$instance['rows'] = ! absint( $new_instance['rows'] ) ? 2 : $new_instance['rows'];
		$instance['profile'] = ( ( 'true' === $new_instance['profile'] || 'false' === $new_instance['profile'] ) ? $new_instance['profile'] : 'false' );
		$instance['bio'] = ( ( 'true' === $new_instance['bio'] || 'false' === $new_instance['bio'] ) ? $new_instance['bio'] : 'false' );
		return $instance;
	}
		

	function admin_setup() {

 		wp_enqueue_script( 'insta-admin-js', plugin_dir_url( __FILE__ ) . 'js/insta-admin.js', true );
   
	}
    function public_scripts() {

        $handle = 'instagram-js';

        // Register the script
        wp_register_script($handle, get_template_directory_uri() . '/js/instafeed.js', array( 'jquery' ), NULL, true );


        // Enqueue the script
        wp_enqueue_script($handle);
    }
    
    function instagram_footer_script() { ?>



<script type="text/javascript">
    var feed = new Instafeed({
      accessToken: instagramvars.token,
      limit: parseInt(instagramvars.newitems),
      target: 'NewInstagramFeed',
      template: '<a href="{{link}}"><img class="lazyload" title="{{caption}}" src="{{image}}"></a>'
    });
    feed.run();
</script>

    

<?php
}
  }







?>