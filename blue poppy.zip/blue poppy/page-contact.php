<?php
/**
Template Name: Contact Us Page Template
 */

  $response = "";

  //function to generate response
  function research_contact_form_generate_response($type, $message){

    global $response;

    if($type == "success") $response = "<div class='success'>{$message}</div>";
    else $response = "<div class='error'>{$message}</div>";

  }

  //response messages
  $not_human       = esc_html__('Human verification incorrect.', 'blue-poppy');
  $missing_content = esc_html__('Please enter all information.', 'blue-poppy');
  $email_invalid   = esc_html__('Email Address Invalid.', 'blue-poppy');
  $message_unsent  = esc_html__('Message was not sent. Try Again.', 'blue-poppy');
  $message_sent    = esc_html__('Thanks! Your message has been sent.', 'blue-poppy');

if(isset($_POST['submitted'])){

  //user posted variables
  $name = sanitize_text_field( $_POST['message_name'] );
  $email = sanitize_email( $_POST['message_email'] );
  $message = sanitize_text_field( $_POST['message_text'] );
  $human = sanitize_text_field( $_POST['message_human'] );


  //php mailer variables
  $to = get_option('admin_email');
  $subject = esc_html__('Someone sent a message from ', 'blue-poppy') .get_bloginfo('name');
  $headers = esc_html__('From: ', 'blue-poppy'). $email . "\r\n" .
    esc_html__('Reply-To: ', 'blue-poppy') . $email . "\r\n";

  if(!$human == 0){
    if($human != 6) research_contact_form_generate_response("error", $not_human); //not human!
    else {

      //validate email
      if(!filter_var($email, FILTER_VALIDATE_EMAIL))
        research_contact_form_generate_response("error", $email_invalid);
      else //email is valid
      {
        //validate presence of name and message
        if(empty($name) || empty($message)){
          research_contact_form_generate_response("error", $missing_content);
        }
        else 
        {
          $sent = wp_mail($to, $subject, $message, $headers);
          if($sent) research_contact_form_generate_response("success", $message_sent); 
          else research_contact_form_generate_response("error", $message_unsent); 
        }
      }
    }
  }
  else if ($_POST['submitted']) research_contact_form_generate_response("error", $missing_content);

}
?>

<?php get_header(); ?>



<div id="primary" class="content-area">
	
		<main id="main" class="site-main">
		
				<a id="content"></a>

     		 	<?php while ( have_posts() ) : the_post(); ?>


          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>


        <header class="entry-page-header <?php echo get_theme_mod('pattern-options', 'background-stripes'); ?>">
                    
              <?php if ( false == get_theme_mod( 'featured-pages', false ) ) : ?>
              
                <?php blue_poppy_post_thumbnail(); ?>
                
                <?php endif; ?>
                
                    <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                            
             </header>
                
               <div class="entry-content">

                    <?php the_content(); ?>


              <div id="contact-respond">
                <?php echo $response; ?>
                <form action="<?php echo esc_url( get_permalink() );?>" method="post">
                  <p><input type="text" placeholder="<?php esc_attr_e('YOUR NAME*', 'blue-poppy'); ?>" name="message_name" value="<?php if(isset($_POST['submitted'])) { echo esc_attr($_POST['message_name']); } ?>"></p>
                  <p><input type="text" placeholder="<?php esc_attr_e('YOUR EMAIL*', 'blue-poppy'); ?>" name="message_email" value="<?php if(isset($_POST['submitted'])) { echo esc_attr($_POST['message_email']); } ?>"></p>
                  <p><textarea type="text" placeholder="<?php esc_attr_e('YOUR MESSAGE*', 'blue-poppy'); ?>" name="message_text"><?php if(isset($_POST['submitted'])) { echo esc_textarea($_POST['message_text']); } ?></textarea></p>
                  <p><label for="message_human"><?php esc_html_e('Human Verification:', 'blue-poppy'); ?> <span>*</span> <br><input type="text" style="width: 60px;" name="message_human"> + 3 = 9</label></p>
                  <p><label><?php esc_html_e('By checking this, you are agreeing to our', 'blue-poppy'); ?> <a href="<?php echo get_theme_mod( 'privacy-policy', '#' ); ?>"><?php esc_html_e('privacy policy.', 'blue-poppy'); ?></a><input style="width:20px;" type="checkbox" name="" value="" required></label></p>
                  <input type="hidden" name="submitted" value="1">
                  <p><input type="submit" class="contact-submit" value="<?php esc_html_e('Submit Message', 'blue-poppy'); ?>"></p>
                </form>
              </div>


            </div><!-- .entry-content -->
            


          </article><!-- #post -->
        

      <?php endwhile; // end of the loop. ?>
      
     

    </main><!-- #content -->
  </div><!-- #primary -->

<?php get_footer();