<?php if( get_theme_mod( 'sidebar-options', 'sidebar-on' ) == 'sidebar-on' ) : ?>

<?php

if ( is_active_sidebar( 'sidebar-1' ) ) : ?>

	<aside id="secondary" class="widget-area">
	
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
		
	</aside><!-- #secondary -->
	
<?php endif; ?>

<?php else : ?>

<?php endif; 