<?php
/**
 * Blue Poppy functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Blue_Poppy
 */

if ( ! function_exists( 'blue_poppy_setup' ) ) :
	/**
	 * Sets up theme defaubluepoppy and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function blue_poppy_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Blue Poppy, use a find and replace
		 * to change 'blue-poppy' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'blue-poppy', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in two locations.
		register_nav_menus( array(
			'main-menu' => esc_html__( 'Primary', 'blue-poppy' ),
			'footer-menu' => esc_html__( 'footer', 'blue-poppy' ),

		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	
	
			// Add support for default block styles.
		add_theme_support( 'wp-block-styles' );

			// Add support for full and wide align images.
		add_theme_support( 'align-wide' );

		add_theme_support( 'responsive-embeds' );

	}
endif;
add_action( 'after_setup_theme', 'blue_poppy_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function blue_poppy_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'blue_poppy_content_width', 1400 );
}
add_action( 'after_setup_theme', 'blue_poppy_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function register_widget_areas() {

		register_sidebar( array(
			'name'          => esc_html__( 'Sidebar', 'blue-poppy' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'blue-poppy' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
	) );
		register_sidebar( array(
			'name'          => esc_html__( 'Blue Poppy Homepage', 'blue-poppy' ),
			'id'            => 'bluepoppy-homepage-widgets',
			'description'   => esc_html__( 'Add widgets here.', 'blue-poppy' ),
			'before_widget' => '<div class="%1$s widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
	) );
}
	
add_action( 'widgets_init', 'register_widget_areas' );    

/**
 * Enqueue scripts and styles.
 */
function blue_poppy_scripts() {
	wp_enqueue_style( 'blue-poppy-style', get_template_directory_uri() . '/style.min.css', array(), null );
	
	wp_style_add_data( 'blue-poppy-style', 'rtl', 'replace' ); 
	
	wp_enqueue_style( 'blue-poppy-fonts', get_template_directory_uri() . '/fonts/google-fonts.css', array(), null );

	wp_enqueue_style( 'blue-poppy-icons', get_template_directory_uri() . '/fonts/font-awesome.css', array(), null );
	
	wp_enqueue_script( 'blue-poppy-navigation', get_template_directory_uri() . '/js/navigation.js', array( 'jquery' ), NULL, true );
	
	wp_enqueue_script( 'blue-poppy-circletype', get_template_directory_uri() . '/js/jquery.arctext.js', array('jquery'), NULL, true );

	wp_enqueue_script( 'bluepoppy-lazyload', get_template_directory_uri() . '/js/lazyload.js', array( 'jquery' ), NULL, true );
	
	wp_enqueue_script( 'blue-poppy-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), NULL, true );

	if (!is_admin() ) {
	wp_deregister_script('jquery');
    wp_register_script( 'jquery', includes_url( '/js/jquery/jquery.min.js' ), false, NULL, true );
    wp_enqueue_script( 'jquery' );
	}
	  
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
	if (is_front_page() ) {
			wp_enqueue_style( 'blue-poppy-homepage', get_template_directory_uri() . '/inc/sheetslider.min.css', array(), NULL );
			wp_enqueue_script( 'blue-poppy-homepage', get_template_directory_uri() . '/js/sheetslider.min.js', array(), NULL );

		}	
}

add_action( 'wp_enqueue_scripts', 'blue_poppy_scripts' );



/**
* The custom color CSS from the Customizer.
*/

function bluepoppy_customizer_css() { ?>


     <style type="text/css">
			body {
			--primary-color: <?php echo get_theme_mod('primary-color', '#f4dde5'); ?>;
			--accent-color: <?php echo get_theme_mod('accent-color', '#c3d3e0'); ?>;
        }
	</style>		

<?php }

add_action( 'wp_head', 'bluepoppy_customizer_css');


add_filter( 'cancel_comment_reply_link', '__return_false' );
/**
* Creates pages upon activation
*/   

function bluepoppy_addpages(){
$title = 'Blue Poppy Homepage';
$title2 = 'Blog';
$title3 = 'Contact';
$title4 = 'Shop';
$title5 = 'About';
if (!get_page_by_title($title, OBJECT, 'page')) {

    $homepage = array(
        'post_title'=>$title,
        'post_content'=> esc_html__('Template for displaying homepage sections', 'blue-poppy'),
        'post_status'=>'publish',
        'post_type'=>'page',
        'post_author'=>1,
    );
        // Insert the post into the database
        $homepage_id =  wp_insert_post( $homepage );
        //set the page template 
        //assuming you have defined template on your-template-filename.php
        update_post_meta($homepage_id, '_wp_page_template', 'sections/homepage.php');
    }
 if (!get_page_by_title($title2, OBJECT, 'page')) {

    $blog = array(
        'post_title'=>$title2,
        'post_content'=> esc_html__('Page to hold your blog posts.', 'blue-poppy'),
        'post_status'=>'publish',
        'post_type'=>'page',
        'post_author'=>1,
    );
        // Insert the post into the database
        $blog_id =  wp_insert_post( $blog );
    }   
if (!get_page_by_title($title3, OBJECT, 'page')) {

    $contact = array(
        'post_title'=>$title3,
        'post_content'=> esc_html__('Have questions? Contact me by filling out the form below!', 'blue-poppy'),
        'post_status'=>'publish',
        'post_type'=>'page',
        'post_author'=>1,
    );
        // Insert the post into the database
        $contact_id =  wp_insert_post( $contact );
        //set the page template 
        //assuming you have defined template on your-template-filename.php
        update_post_meta($contact_id, '_wp_page_template', 'page-contact.php');
    }
    
if (!get_page_by_title($title4, OBJECT, 'page')) {
    
    $shop = array(
        'post_title'=>$title4,
        'post_content'=> esc_html__('Disclaimer: The following links are affiliate links. We might receive a profit if you click on them.', 'blue-poppy'),
        'post_status'=>'publish',
        'post_type'=>'page',
        'post_author'=>1,
    );
        // Insert the post into the database
        $shop_id =  wp_insert_post( $shop );
        //set the page template 
        //assuming you have defined template on your-template-filename.php
        update_post_meta($shop_id, '_wp_page_template', 'page-shop.php');
    }
    
if (!get_page_by_title($title5, OBJECT, 'page')) {
    
    $about = array(
        'post_title'=>$title5,
        'post_content'=> esc_html__('Start typing your awesome bio here.', 'blue-poppy'),
        'post_status'=>'publish',
        'post_type'=>'page',
        'post_author'=>1,
    );
        // Insert the post into the database
        $about_id =  wp_insert_post( $about );
        //set the page template 
        //assuming you have defined template on your-template-filename.php
        update_post_meta($about_id, '_wp_page_template', 'page.php');
    }
    
    
}

function bluepoppy_menu_setup() {

$menuname = 'Blue Poppy Main Menu';
$bluepoppymenulocation = 'main-menu';
// Does the menu exist already?
$menu_exists = wp_get_nav_menu_object( $menuname );

// If it doesn't exist, let's create it.
if( !$menu_exists){
    $menu_id = wp_create_nav_menu($menuname);

    // Set up default BuddyPress links and add them to the menu.
    wp_update_nav_menu_item($menu_id, 0, array(
        'menu-item-title' =>  __('About'),
        'menu-item-classes' => 'about',
        'menu-item-url' => home_url( '/about/' ), 
        'menu-item-status' => 'publish'));

    wp_update_nav_menu_item($menu_id, 0, array(
        'menu-item-title' =>  __('Blog'),
        'menu-item-classes' => 'blog',
        'menu-item-url' => home_url( '/blog/' ), 
        'menu-item-status' => 'publish'));

    wp_update_nav_menu_item($menu_id, 0, array(
        'menu-item-title' =>  __('Shop the Site'),
        'menu-item-classes' => 'shop',
        'menu-item-url' => home_url( '/shop/' ), 
        'menu-item-status' => 'publish'));

    wp_update_nav_menu_item($menu_id, 0, array(
        'menu-item-title' =>  __('Contact'),
        'menu-item-classes' => 'contact',
        'menu-item-url' => home_url( '/contact/' ), 
        'menu-item-status' => 'publish'));


    // Grab the theme locations and assign our newly-created menu
    // to the BuddyPress menu location.
        $locations = get_theme_mod('nav_menu_locations');
        $locations[$bluepoppymenulocation] = $menu_id;
        set_theme_mod( 'nav_menu_locations', $locations );
	}

}


function bluepoppy_homepage_setup() {

$homepage = get_page_by_title( 'Blue Poppy Homepage' );
$blog = get_page_by_title( 'Blog' );
	update_option( 'page_on_front', $homepage->ID );
    update_option( 'show_on_front', 'page' );
    update_option( 'page_for_posts', $blog->ID );

}

add_action( 'after_setup_theme', 'bluepoppy_menu_setup' );
add_action('after_switch_theme', 'bluepoppy_addpages');
add_action( 'after_switch_theme', 'bluepoppy_homepage_setup' );



/** Filter excerpt length to 35 words. */

function bubble_custom_excerpt_length( $length ) {
return 25;
}
add_filter( 'excerpt_length', 'bubble_custom_excerpt_length', 999 );

/** Aaaand let's remove those ugly brackets while we're at it. **/

function pretty_excerpt_more( $more ) {
    return '...';
}
add_filter('excerpt_more', 'pretty_excerpt_more');


// trim excerpt whitespace
if ( !function_exists( 'mp_trim_excerpt_whitespace' ) ) {
  function mp_trim_excerpt_whitespace( $excerpt ) {
    return trim( $excerpt );
  }
  add_filter( 'get_the_excerpt', 'mp_trim_excerpt_whitespace', 1 );
}


/** Fallback for posts with no featured images set. */

function fallback_featured() {
          global $post;
          if ( empty( $post->ID ) ) { 

}
else {
          $already_has_thumb = has_post_thumbnail($post->ID);
              if (!$already_has_thumb)  {
              $attached_image = get_children( "post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=1" );
                 end($attached_image); 
                          if ($attached_image) {
                                foreach ($attached_image as $attachment_id => $attachment) {
                                set_post_thumbnail($post->ID, $attachment_id);
                                }
                           }
                        }
      } }
      
add_action('the_post', 'fallback_featured');
add_action('save_post', 'fallback_featured');
add_action('draft_to_publish', 'fallback_featured');
add_action('new_to_publish', 'fallback_featured');
add_action('pending_to_publish', 'fallback_featured');
add_action('future_to_publish', 'fallback_featured');


/**
 * Add a "Blue Poppy" link in the admin menu.
 */
 
function bluepoppy_admin_menu() {
	add_menu_page( __('Blue Poppy Menu', 'blue-poppy'), esc_html__('Blue Poppy', 'blue-poppy'), 'manage_options', 'bluepoppy-welcome-page', 'bluepoppy_admin_page', 'dashicons-smiley', 4  );
}
add_action( 'admin_menu', 'bluepoppy_admin_menu' );


/**
 * The auto-updater.
 */

require get_template_directory() . '/update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://littlethemeshop.com/updater/plants.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'blue-poppy',
	48 // <-- hours
);

function wpforo_search_form( $html ) {

        $html = str_replace( 'placeholder="Search ', 'placeholder="' . get_theme_mod('custom-search-text', 'I&#39;m looking for... ') . '"', $html );

        return $html;
}
add_filter( 'get_search_form', 'wpforo_search_form' );


if (is_admin() && isset($_GET['activated'])){

    wp_redirect(admin_url("admin.php?page=bluepoppy-welcome-page"));
}


add_filter( 'wp_lazy_loading_enabled', '__return_false' );


/**
 * @snippet       Avoid Lazy Loading an Image - Jetpack
 * @how-to        Get CustomizeWoo.com FREE
 * @sourcecode    https://businessbloomer.com/?p=79958
 * @author        Rodolfo Melogli
 * @compatible    WooCommerce 3.4.5, Jetpack 6.5
 */
 
add_filter( 'jetpack_lazy_images_blocked_classes', 'bbloomer_exclude_custom_logo_class_from_lazy_load', 999, 1 );
             
function bbloomer_exclude_custom_logo_class_from_lazy_load( $classes ) {
   $classes[] = 'custom-logo';
   return $classes;
}
 
/**
 * The Welcome/Getting Started page in the admin menu.
 */
require_once get_template_directory() . '/inc/welcome.php';

/**
 * Custom template tags for this theme.
 */
require_once get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require_once get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer options
 */
require_once get_template_directory() . '/inc/customizer.php';

/* Include custom widgets
 */
require_once get_template_directory() . '/inc/instagram-widget.php';
require_once get_template_directory() . '/inc/about-widget.php';
require_once get_template_directory() . '/inc/featured-widget.php';
require_once get_template_directory() . '/inc/subscribe-widget.php';



/**
 * Add Kirki-infused customizer options.
 */
require_once get_template_directory() . '/kirki/kirki.php';
require_once get_template_directory() . '/inc/kirki-customizer.php';

/**
 * Implement the Custom Header feature.
 */
require_once get_template_directory() . '/inc/custom-header.php';

/**
 * Implement the Related Posts feature.
 */
require_once get_template_directory() . '/inc/related-posts.php';

/** Social Share Buttons
 */
require_once get_template_directory() . '/inc/social-share-buttons.php';


/* * Implement the Related Posts feature.
 */
require_once get_template_directory() . '/inc/divided-menu.php';


/**
 * Add class and convert images for lazy loading.
 */
 
if( get_theme_mod( 'lazy-option', false ) == true OR is_admin() ) {

// do nothing 

} else { require_once get_template_directory() . '/inc/lazy-load-converter.php'; }

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require_once get_template_directory() . '/inc/jetpack.php';
}

/**
 * Classic Widget screen set as default.
 */
 
function lts_theme_support() {
    remove_theme_support( 'widgets-block-editor' );
}

if( get_theme_mod( 'widget-block-option', false ) == true ) {

// do nothing 

} else {
add_action( 'widgets_init', 'lts_theme_support' );
}

/**
 * Proper ob_end_flush() for all levels
 *
 * This replaces the WordPress `wp_ob_end_flush_all()` function
 * with a replacement that doesn't cause PHP notices.
 */
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );
add_action( 'shutdown', function() {
   while ( @ob_end_flush() );
} );
