<?php
/**
/** Template Name: Shop Page
 **/

$productdefaults = [
  [
  		'product_img'    => get_template_directory_uri() . '/images/demo-product1.jpg',
    	'product_name'    => esc_html__( 'Desktop Cactus', 'blue-poppy' ),
		'product_url'    => 'https://littlethemeshop.com',
	],
	[
		'product_img'    => get_template_directory_uri() . '/images/demo-product2.jpg',
		'product_name'    => esc_html__( 'Small Potted Plants', 'blue-poppy' ),
		'product_url'    => 'https://littlethemeshop.com',

	],
		[
		'product_img'    => get_template_directory_uri() . '/images/demo-product3.jpg',
		'product_name'    => esc_html__( 'Rose Flowers', 'blue-poppy' ),
		'product_url'    => 'https://littlethemeshop.com',

	],
];

$products = get_theme_mod( 'product_repeater', $productdefaults ); 

?>

<?php get_header(); ?>


<div id="primary" class="content-area">
	
		<main id="main" class="site-main">
		
				<a id="content"></a>

<section class="product-section">
     		 	<?php while ( have_posts() ) : the_post(); ?>

		<article>
                 <header class="entry-page-header <?php echo get_theme_mod('pattern-options', 'background-stripes'); ?>">
                    
              <?php if ( false == get_theme_mod( 'featured-pages', false ) ) : ?>
              
                <?php blue_poppy_post_thumbnail(); ?>
                
                <?php endif; ?>
                
                    <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                            
             </header>
                
               <div class="entry-content">

                    <?php the_content(); ?>

				</div>
				
		<div class="product-wrapper">
		
			<?php foreach( $products as $product ) : ?>
						<div class="shop-item">

	<?php if ( ! wp_attachment_is_image( $product['product_img'] ) ){

    					$portimg_url = esc_url_raw($product['product_img']);

							} else {

    					$portimg_url = wp_get_attachment_image_url($product['product_img'], 'large');
						
						} ?>
							
											 <a href="<?php if(isset($product['product_url'])) { echo $product['product_url']; } ?>">
<img class="lazyload" data-src="<?php echo $portimg_url; ?>" alt="<?php if(isset($product['product_name'])) { echo $product['product_name']; } ?>"/></a>

				<h3>
			
				 <a href="<?php if(isset($product['product_url'])) { echo $product['product_url']; } ?>">
				 
 					
    					<?php if(isset($product['product_name'])) { echo $product['product_name']; } ?>
					
				</a></h3>

</div>
     		<?php endforeach; ?>
     	

		</div>
		</article>
		      <?php endwhile; // end of the loop. ?>

</section>
</main>
</div>

<?php get_footer();