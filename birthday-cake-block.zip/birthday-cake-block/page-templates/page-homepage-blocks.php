<?php
/**
 Template name: Homepage Blocks
 */

get_header();
?>




<a id="content"></a>
<div id="primary-home" class="widget-content-area">
    <main id="main-home" class="home-widgets">
        <div class="little-homepage-container">
					
					  <?php
			while ( have_posts() ) :
				the_post();

the_content();
			endwhile; // End of the loop.
			?>



        </div>
    </main>
</div>

<?php get_footer();