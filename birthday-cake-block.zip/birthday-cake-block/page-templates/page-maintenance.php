<?php
/**
 Template name: Maintenance Mode Page Template
 */

get_header();
?>
	<style type="text/css">
		.site-header, .site-footer {display:none !important;}
		#page {margin-top: 0px;}
	</style>
	
	
      <?php while ( have_posts() ) : the_post(); ?>

		<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
			echo '<div id="coming-soon-wrapper" style="background: url('. $url.')">'; ?>

		<div class="coming-soon-container">
		
			<div class="coming-soon-content">
			
				<?php the_title( '<h1>', '</h1>' ); ?>
				
					 <?php the_content(); ?>
					 
					 	<?php birthday_social_media_icons(); ?>

			</div>
			
        </div>
        
      </div>
        
 <?php endwhile; // end of the loop. ?>

<?php get_footer();

