<?php 
/**
 * The template for displaying all Woocommerce pages
 *
 * @link https://woocommerce.com
 *
 * @package Birthday_Cake
 */
 
 get_header(); ?>

<div id="primary" class="content-area woocommerce <?php echo get_theme_mod('sidebar-layout-options', 'sidebar-right'); ?>">
	
	<main id="main" class="site-main">
	
		<a id="content"></a>

		<article>
				
				<div class="entry-content">
				
					<?php if ( is_product() ) { ?>
		 	    
		 	    	<?php woocommerce_breadcrumb(); ?>
		  		
		  			<?php } ?>
		    
 			 		<?php woocommerce_content(); ?>

				</div>
 	 
 	 	</article>
  
  </main>

<?php get_sidebar( 'store' ); ?>

</div>

<?php get_footer();