<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Birthday_Cake
 */

get_header();
?>

   	<a id="content"></a>

    <div id="primary" class="content-area">
        <main id="main" class="site-main">
            <div class="little-homepage-container">

                <div class="page-layout">
				

                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                        <?php $error_img = get_template_directory_uri() . '/images/404demo.jpg';
							if (get_theme_mod('404-image') !='') {
    						$error_img = get_theme_mod('404-image');
						} ?>
						
							<img class="post-thumbnail" src="<?php echo $error_img ?>">


                            <div class="entry-content">

                                <header class="entry-page-header">
                                    <h1 class="entry-title"><?php echo get_theme_mod( '404-page-title', esc_html__('Oops! Page Not Found.', 'birthday-cake') ) ?></h1>
                                </header>
                                <!-- .entry-header -->

                                <p style="text-align:center;">
                                    <?php echo get_theme_mod( '404-page-message', esc_html__('Sorry, the page you are looking for is not here.', 'birthday-cake') ) ?>
                                </p>
                                <?php get_search_form(); ?>

                            </div>
                            <!-- .entry-content -->

                    </article>
                    <!-- #post -->
                </div>
            </div>
        </main>
        <!-- #content -->
    </div>
    <!-- #primary -->

    <?php get_footer();