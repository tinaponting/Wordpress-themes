<header id="masthead" class="site-header <?php echo get_theme_mod('sticky-header', 'sticky'); ?>">
    <div class="container">

<?php if (wp_nav_menu( array( 'theme_location' => 'main-menu', 'echo' => false )) !== false) { ?>
        <input class="menu-btn" type="checkbox" id="menu-btn" />
        <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>

        <div class="mobile-menu">
            <?php
				wp_nav_menu(array(
    			'theme_location' => 'main-menu',
   				'menu_id' => 'primary-menu',
				));
			?>

                <?php birthday_social_media_icons(); ?>

        </div>
        <nav id="site-navigation" class="main-navigation-divided">

            <?php if (get_theme_mod('divider-options', 'divider-logo') == 'divider-logo'): ?>
            
    	<?php
			if ( defined( 'JETPACK__VERSION' ) ) {
   				 $divider_html = '<a href="' . get_home_url() . '">' . get_custom_logo() . '</a>';
   				 wp_nav_menu(array(
        			'theme_location' => 'main-menu',
        			'menu_id' => 'primary-menu',
        			'divider_html' => $divider_html,
    				));
			
				} else { 

            	
                $custom_logo_id = get_theme_mod( 'custom_logo' );
				$logo_image = wp_get_attachment_image_src( $custom_logo_id , 'medium_large' );
   				 $divider_html = '<a class="custom-logo-link" href="' . get_home_url() . '"><img class="custom-logo" src="'. $logo_image[0] .'" alt="custom-logo"></a>';
   				 wp_nav_menu(array(
        			'theme_location' => 'main-menu',
        			'menu_id' => 'primary-menu',
        			'divider_html' => $divider_html,
    				));
			} ?>
				
                    <?php else: ?>
                    
                        <?php
   						 $divider_html = '<a href="' . get_home_url() . '"><h1 class="site-title">' . get_bloginfo('name') . '</h1></a>';
   						 wp_nav_menu(array(
        					'theme_location' => 'main-menu',
        					'menu_id' => 'primary-menu',
        					'divider_html' => $divider_html,
    							));
						?>
						
                    <?php endif; ?>

        </nav>

        <div class="social-icons-divided">
        
            <?php birthday_social_media_icons(); ?>
            
        </div>
<?php } ?>
    </div>
    <!-- #site-navigation -->
</header>
<!-- #masthead -->