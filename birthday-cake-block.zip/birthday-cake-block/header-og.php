<header id="masthead" class="site-header <?php echo get_theme_mod('sticky-header', 'sticky'); ?>">
	<?php if( get_theme_mod( 'header-layout', 'header-left' ) == 'header-centered' ) : ?>
	
	<div class="container-centered">
		<?php else : ?>
		
			<div class="container">
			
				<?php endif; ?>
	
				<div class="site-branding">
			
				<?php
                $custom_logo_id = get_theme_mod( 'custom_logo' );
				$logo_image = wp_get_attachment_image_src( $custom_logo_id , 'medium_large' );
   				?>
   				
				<?php if ($custom_logo_id) { ?>
   				<a class="custom-logo-link" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="custom-logo" src="<?php echo $logo_image[0]; ?>" alt="site-logo"></a>	
					<?php } ?>					
					<?php if ( is_front_page() && is_home() ) : ?>
				
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php else : ?>
				
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php endif; $birthday_cake_description = get_bloginfo( 'description', 'display' ); if ( $birthday_cake_description || is_customize_preview() ) : ?>
				
					<p class="site-description"><?php echo esc_html($birthday_cake_description); /* WPCS: xss ok. */ ?></p>
					
			<?php endif; ?>
			
				</div>
				
<!-- Mobile stuff -->
 
  <input class="menu-btn" type="checkbox" id="menu-btn" />
  <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
 
  		<div class="mobile-menu"><?php
			wp_nav_menu( array(
				'theme_location' => 'main-menu',
				'menu_id'        => 'primary-menu',
			) );
			?>
			
				<?php birthday_social_media_icons(); ?>
   		 </div>
				
	<?php if( get_theme_mod( 'header-layout', 'header-left' ) == 'header-centered' ) : ?>

		<nav id="site-navigation" class="main-navigation">	

		<?php
			wp_nav_menu( array(
				'theme_location' => 'main-menu',
				'menu_id'        => 'primary-menu',
				'reverse'        => TRUE,
			) );
			?>
		
                 <?php birthday_social_media_icons(); ?>

		</nav>
		
<?php else : ?>

	<nav id="site-navigation" class="main-navigation">

			<?php birthday_social_media_icons(); ?>

			<?php
			wp_nav_menu( array(
				'theme_location' => 'main-menu',
				'menu_id'        => 'primary-menu',
				'reverse'        => TRUE,
			) );
			?>
				
	</nav>	
	
<?php endif; ?>	
		
			</div><!-- #site-navigation -->
	</header><!-- #masthead -->