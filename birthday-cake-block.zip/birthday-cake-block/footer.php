<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Birthday_Cake
 */

?>

</div> <!-- #content -->

<footer id="colophon" class="site-footer">
	<div class="footer-menu">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'footer-menu',
				'menu_id'        => 'footer-menu',
				'reverse'        => TRUE,

			) );
			?>

	</div>

	<div class="footer-social-icons">
		<?php birthday_social_media_icons(); ?>

	</div>

	<div class="site-info">
		&#169; <?php echo date("Y"); ?> | <a href="<?php echo get_theme_mod('footer-url', 'https://littlethemeshop.com') ?>" target="_blank"><?php echo get_theme_mod( 'footer-text', esc_html__( 'Designed by Little Theme Shop', 'bubble-tea') ); ?></a>
	</div>
</footer>

</div>

<?php wp_footer(); ?>

</body>

</html>

