<?php if( get_theme_mod( 'sidebar-woocommerce-options', 'sidebar-woocommerce-on' ) == 'sidebar-woocommerce-on' ) : ?>

<?php if ( is_active_sidebar( 'store' ) ) : ?>

    <aside class="sidebar sidebar-store" id="secondary" role="complementary">
    
        <?php dynamic_sidebar( 'store' ); ?>
        
    </aside>
    
<?php endif; ?>

<?php endif; 