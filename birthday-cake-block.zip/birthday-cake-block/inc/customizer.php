<?php
/**
 * Birthday Cake Theme Customizer
 *
 * @package Birthday_Cake
 */

/**
 * Add refresh support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function birthday_cake_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'refresh';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'refresh';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'refresh';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'birthday_cake_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'birthday_cake_customize_partial_blogdescription',
		) );
	}
}
add_action( 'customize_register', 'birthday_cake_customize_register' );

function birthday_customizer_social_media_array() {
 	
	$social_sites = array('twitter', 'facebook', 'google-plus', 'flickr', 'pinterest', 'youtube', 'tiktok', 'tumblr', 'snapchat', 'dribbble', 'behance', 'rss', 'linkedin', 'instagram', 'etsy', 'spotify', 'email', 'link', 'search', 'twitch', 'shopping-cart', );
 
	return $social_sites;
}


/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function birthday_cake_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function birthday_cake_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function birthday_cake_customize_preview_js() {
	wp_enqueue_script( 'birthday-cake-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'birthday_cake_customize_preview_js' );


function birthday_customizer_settings( $wp_customize ) {

/** Control for headers
 */
 
 class Sub_Section_Heading_Custom_Control extends WP_Customize_Control {

        //The type of control being rendered
        public $type = 'sub_section_heading';

        //Render the control in the customizer

        public function render_content() {

        ?>
            <div class="sub-section-heading-control">
                <?php if( !empty( $this->label ) ) { ?>
                    <h4 class="section-title" style="text-align:center;text-transform: uppercase;background:#444;color:#FFF;padding:5px;font-size.9em;letter-spacing:.1em;margin:0;">
                          <?php echo esc_html( $this->label ); ?>
                    </h4>
                <?php } ?>

            </div>
        <?php
        }
   } 

$wp_customize->remove_control('header_image');

$wp_customize->add_panel( 'birthday_panel', array(
  'title' => __( 'Birthday Cake Options', 'birthday-cake' ),
  'priority' => 10, // Mixed with top-level-section hierarchy.
) );

 $wp_customize->add_section( 'birthday-settings' , array(
      'title'      => __( 'General Options', 'birthday-cake'),
      'priority' => 20,
      'description' => __('This is a list of all general options for the Birthday Cake theme.', 'birthday-cake'),
	  'panel' => 'birthday_panel', 
  ) );
  
   $wp_customize->add_section( 'birthday-colors' , array(
      'title'      => __( 'Color Options', 'birthday-cake'),
      'priority' => 30,
      'panel' => 'birthday_panel',

  ) );
  
     //radio box sanitization function
        function birthday_sanitize_radio( $input, $setting ){
          
            //input must be a slug: lowercase alphanumeric characters, dashes and underscores are allowed only
            $input = sanitize_key($input);
  
            //get the list of possible radio box options 
            $choices = $setting->manager->get_control( $setting->id )->choices;
                              
            //return input if valid or return default option
            return ( array_key_exists( $input, $choices ) ? $input : $setting->default );                
              
        }
        
             //image input sanitization function  
        function birthday_sanitize_file( $file, $setting ) {
          
            //allowed file types
            $mimes = array(
                'jpg|jpeg|jpe' => 'image/jpeg',
                'gif'          => 'image/gif',
                'png'          => 'image/png'
            );
              
            //check file type from file name
            $file_ext = wp_check_filetype( $file, $mimes );
              
            //if file has a valid mime type return it, otherwise return default
            return ( $file_ext['ext'] ? $file : $setting->default );
        }
        

$wp_customize->add_setting('header1', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header1',
            array(
                'label'   => __( 'Design Elements', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );
 
$wp_customize->add_setting( 'background-options' , array(
      'default'     => 'background-triangles',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'
  ) );

  $wp_customize->add_control( 'background-options', array(
  'label' => __( 'Background Patterns', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'background-options',
  'type' => 'radio',
  'choices' => array(
    'background-dots' => __('Polka Dots', 'birthday-cake'),
    'background-triangles' => __('Triangles', 'birthday-cake'),
    'background-wiggle' => __('Wiggly Lines', 'birthday-cake'),
    'background-sprinkles' => __('Sprinkles', 'birthday-cake'),
    'background-hearts' => __('Hearts', 'birthday-cake'),
    'background-lines' => __('Vertical Lines', 'birthday-cake'),
    'background-white' => __('Plain White', 'birthday-cake'),

  ),
) );

$wp_customize->add_setting('header2', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header2',
            array(
                'label'   => __( 'Header and Menu', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );

  $wp_customize->add_setting( 'sticky-header' , array(
      'default'     => 'sticky',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

      
  ) );

  $wp_customize->add_control( 'sticky-header', array(
  'label' => __('Sticky Header', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'sticky-header',
  'type' => 'radio',
  'choices' => array(
    'sticky' => __('On', 'birthday-cake'),
    'nosticky' => __('Off', 'birthday-cake'),
  ),
) );

 $wp_customize->add_setting( 'header-layout' , array(
      'default'     => 'header-left',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'header-layout', array(
  'label' => __('Header Layout', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'header-layout',
  'type' => 'radio',
  'choices' => array(
    'header-left' => __('Classic Menu', 'birthday-cake'),
    'header-centered' => __('Centered Menu', 'birthday-cake'),
    'header-divided' => __('Split Menu', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'divider-options' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'divider-options', array(
  'label' => __( 'Split Menu Options', 'birthday-cake'),
  'description' => __('Only applies if "split menu" is selected.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'active_callback' => 'split_callback',
  'settings' => 'divider-options',
  'type' => 'radio',
  'choices' => array(
    'divider-logo' => __('Display your logo in the center of the menu. Note: Must have a logo already uploaded. The option to do this is under Site Identity in the Customizer.', 'birthday-cake'),
    'divider-title' => __('Display the name of your site in the center of the menu. Note: Must have "display site title" selected under Site Identity in the Customizer.', 'birthday-cake'),
  ),
) );

  $wp_customize->add_setting( 'wide-logo' , array(
    'default'     => 'wide-logo-no',
    'transport'   => 'refresh',
    'sanitize_callback' => 'birthday_sanitize_radio'
  ) );

  $wp_customize->add_control( 'wide-logo', array(
	'label'        => __('Extra wide logo?', 'birthday-cake'),
	'section'    => 'birthday-settings',
	'description' => __('This option is for those who have an extra wide logo and are using the centered menu layout. Select this if you want your logo to be bigger and wider.', 'birthday-cake'),
	'settings'   => 'wide-logo',
	'type' => 'radio',
  	'choices' => array(
    	'wide-logo-yes' => __('Yep, make my logo extra wide!', 'birthday-cake'),
    	'wide-logo-no' => __('Nope. Leave this off.', 'birthday-cake'),
  ),
) );


  $wp_customize->add_setting( 'primary-color' , array(
    'default'     => '#ef92a5',
    'transport'   => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color'
  ) );

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'primary-color', array(
	'label'        => __('Primary Color', 'birthday-cake'),
	'section'    => 'birthday-colors',
	'settings'   => 'primary-color',
) ) );

  $wp_customize->add_setting( 'accent-color' , array(
    'default'     => '#f0ed6f',
    'transport'   => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color'
  ) );

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'accent-color', array(
	'label'        => 'Accent Color',
	'section'    => 'birthday-colors',
	'settings'   => 'accent-color',
) ) );

  $wp_customize->add_setting( 'link-primary-color' , array(
    'default'     => '#ffffff',
    'transport'   => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color'
  ) );

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link-primary-color', array(
	'label'        => __('Optional: If you chose a lighter PRIMARY color and certain links are now too light/unreadable, choose a darker color for those links here:', 'birthday-cake'),
	'section'    => 'birthday-colors',
	'settings'   => 'link-primary-color',
) ) );

  $wp_customize->add_setting( 'link-accent-color' , array(
    'default'     => '#222222',
    'transport'   => 'refresh',
    'sanitize_callback' => 'sanitize_hex_color'
  ) );

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link-accent-color', array(
	'label'        => __('Optional: If you chose a darker ACCENT color and certain links are now too dark/unreadable, choose a lighter color for those links here:', 'birthday-cake'),
	'section'    => 'birthday-colors',
	'settings'   => 'link-accent-color',
) ) );



$wp_customize->add_setting('header3', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header3',
            array(
                'label'   => __( 'Fonts', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );
 
$wp_customize->add_setting( 'google-fonts' , array(
      'default'     => false,
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'google-fonts', array(
  'label' => __('Select if you want to use Google fonts.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'google-fonts',
  'type' => 'radio',
  'choices' => array(
    'google-fonts-on' => __('Turn Google fonts on', 'birthday-cake'),
    'google-fonts-off' => __('Keep them off (use default fonts)', 'birthday-cake'),
  ),
) );


$wp_customize->add_setting( 'cake-google-header-fonts' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_html'

  ) );

  $wp_customize->add_control( 'cake-google-header-fonts', array(
  'label' => __('Google Header Font', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'cake-google-header-fonts',
  'active_callback' => 'google_callback',
  'type' => 'select',
  'choices' => array(
    'Montserrat' => __('Montserrat', 'birthday-cake'),
    'Lato' => __('Lato', 'birthday-cake'),
    'Roboto' => __('Roboto', 'birthday-cake'),
    'Dosis' => __('Dosis', 'birthday-cake'),
    'Nunito' => __('Nunito', 'birthday-cake'),
    'Oswald' => __('Oswald', 'birthday-cake'),
    'Poppins' => __('Poppins', 'birthday-cake'),
    'Raleway' => __('Raleway', 'birthday-cake'),
    'Quicksand' => __('Quicksand', 'birthday-cake'),
    'Josefin Sans' => __('Josefin Sans', 'birthday-cake'),
    'Poiret One' => __('Poiret One', 'birthday-cake'),
    'Baloo Chettan 2' => __('Baloo', 'birthday-cake'),
    'Roboto Slab' => __('Roboto Slab', 'birthday-cake'),
    'Comfortaa' => __('Comfortaa', 'birthday-cake'),
    'Fredoka One' => __('Fredoka One', 'birthday-cake'),
    'Sen' => __('Sen', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'cake-google-header-bold' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_html'

  ) );

  $wp_customize->add_control( 'cake-google-header-bold', array(
  'label' => __('Google Font Weight', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'cake-google-header-bold',
  'active_callback' => 'google_callback',
  'type' => 'select',
  'choices' => array(
    '400' => __('Regular', 'birthday-cake'),
    '700' => __('Bold', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'cake-google-script-switch' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_attr'

  ) );

  $wp_customize->add_control( 'cake-google-script-switch', array(
  'label' => __('Use a script font?', 'birthday-cake'),
  'description' => __('If you turn this on, you can use a custom font for the first-word script. If off, the first word will use the same font as your header font. Hope that makes sense! ;)', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'cake-google-script-switch',
  'active_callback' => 'google_callback',
  'type' => 'select',
  'choices' => array(
  	'google-font-script-on' => __('Yes!', 'birthday-cake'),
	'google-font-script-off' => __('Nope.', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'cake-google-script-font' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_html'

  ) );

  $wp_customize->add_control( 'cake-google-script-font', array(
  'label' => __('Google Script Font', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'cake-google-script-font',
  'active_callback' => 'google_callback',
  'type' => 'select',
  'choices' => array(
  	'Permanent Marker' => __('Permanent Marker (default)', 'birthday-cake'),
  	'Rock Salt' => __('Rock Salt', 'birthday-cake'),
  	'Sarina' => __('Sarina', 'birthday-cake'),
	'Knewave' => __('Knewave', 'birthday-cake'),
	'Satisfy' => __('Satisfy', 'birthday-cake'),
	'Pacifico' => __('Pacifico', 'birthday-cake'),
	'Over the Rainbow' => __('Over the Rainbow', 'birthday-cake'),
	'Crafty Girls' => __('Crafty Girls', 'birthday-cake'),
	'Leckerli One' => __('Leckerli One', 'birthday-cake'),
	'Give You Glory' => __('Give You Glory', 'birthday-cake'),

  ),
) );


$wp_customize->add_setting( 'cake-google-body-fonts' , array(
      'default'     => true,
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_html'

  ) );

  $wp_customize->add_control( 'cake-google-body-fonts', array(
  'label' => __('Google Body Font', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'cake-google-body-fonts',
  'active_callback' => 'google_callback',
  'type' => 'select',
  'choices' => array(
    'Montserrat' => __('Montserrat', 'birthday-cake'),
    'Lato' => __('Lato', 'birthday-cake'),
    'Roboto' => __('Roboto', 'birthday-cake'),
    'Dosis' => __('Dosis', 'birthday-cake'),
    'Nunito' => __('Nunito', 'birthday-cake'),
    'Oswald' => __('Oswald', 'birthday-cake'),
    'Poppins' => __('Poppins', 'birthday-cake'),
    'Raleway' => __('Raleway', 'birthday-cake'),
    'Quicksand' => __('Quicksand', 'birthday-cake'),
    'Josefin Sans' => __('Josefin Sans', 'birthday-cake'),
    'Poiret One' => __('Poiret One', 'birthday-cake'),
    'Baloo Chettan 2' => __('Baloo', 'birthday-cake'),
    'Roboto Slab' => __('Roboto Slab', 'birthday-cake'),
    'Comfortaa' => __('Comfortaa', 'birthday-cake'),
    'Fredoka One' => __('Fredoka One', 'birthday-cake'),
    'Sen' => __('Sen', 'birthday-cake'),

  ),
) );

$wp_customize->add_setting('header4', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header4',
            array(
                'label'   => __( 'Sidebars', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );

$wp_customize->add_setting( 'sidebar-options' , array(
      'default'     => 'sidebar-on',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'sidebar-options', array(
  'label' => 'Sidebars',
  'section' => 'birthday-settings',
  'settings' => 'sidebar-options',
  'type' => 'radio',
  'choices' => array(
    'sidebar-on' => __('On', 'birthday-cake'),
    'sidebar-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'sidebar-woocommerce-options' , array(
      'default'     => 'sidebar-woocommerce-off',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'sidebar-woocommerce-options', array(
  'label' => __('Woocommerce Sidebars', 'birthday-cake'),
  'description' => __('Requires the Woocommerce plugin.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'sidebar-woocommerce-options',
  'type' => 'radio',
  'choices' => array(
    'sidebar-woocommerce-on' => __('On', 'birthday-cake'),
    'sidebar-woocommerce-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'sidebar-layout-options' , array(
      'default'     => 'sidebar-right',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'sidebar-layout-options', array(
  'label' => __('Sidebar Layout', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'sidebar-layout-options',
  'type' => 'radio',
  'choices' => array(
    'sidebar-left' => __('Display on the left', 'birthday-cake'),
    'sidebar-right' => __('Display on the right', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting('header5', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header5',
            array(
                'label'   => __( 'Blog Page and Posts', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );

$wp_customize->add_setting( 'blog-layout-options' , array(
      'default'     => 'posts-grid-columns-2',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'blog-layout-options', array(
  'label' => __('Blog Index / Category Layout', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'blog-layout-options',
  'type' => 'radio',
  'choices' => array(
    'posts-grid-columns-1' => __('One column', 'birthday-cake'),
    'posts-grid-columns-2' => __('Two columns', 'birthday-cake'),
    'posts-grid-columns-3' => __('Three columns', 'birthday-cake'),
    'posts-grid-columns-4' => __('Four columns (Tip: Turn off sidebars if you choose this option!)', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'turn-off-everything' , array(
      'default'     => 'turn-on-everything',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'turn-off-everything', array(
  'label' => __('Display only blog titles on blog page.', 'birthday-cake'),
  'description' => __('Recommended for three-column or four-column layouts.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'turn-off-everything',
  'type' => 'radio',
  'choices' => array(
    'turn-off-everything' => __('On', 'birthday-cake'),
    'turn-on-everything' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'related-posts' , array(
      'default'     => 'related-posts-on',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'related-posts', array(
  'label' => __('Related posts under blog articles:', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'related-posts',
  'type' => 'radio',
  'choices' => array(
    'related-posts-on' => __('On', 'birthday-cake'),
    'related-posts-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'related_posts_control' , array(
      'default'     => 'tags',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'related_posts_control', array(
  'label' => __('Display related posts by tags or categories?', 'birthday-cake'),
  'section' => 'birthday-settings',
  'active_callback' => 'related_callback',
  'settings' => 'related_posts_control',
  'type' => 'radio',
  'choices' => array(
    'tags' => __('Tags (default)', 'birthday-cake'),
    'categories' => __('Categories', 'birthday-cake'),
  ),
) );


$wp_customize->add_setting( 'social-share-buttons' , array(
      'default'     => 'social-share-on',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'social-share-buttons', array(
  'label' => __('Share buttons under blog articles:', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'social-share-buttons',
  'type' => 'radio',
  'choices' => array(
    'social-share-on' => __('On', 'birthday-cake'),
    'social-share-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'blog-post-tags' , array(
      'default'     => 'blog-post-tags-on',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'blog-post-tags', array(
  'label' => __('Tag list under blog articles:', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'blog-post-tags',
  'type' => 'radio',
  'choices' => array(
    'blog-post-tags-on' => __('On', 'birthday-cake'),
    'blog-post-tags-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'read-more-text' , array(
      'default'     => __('Read More', 'birthday-cake'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( 'read-more-text', array(
   'label' => __('Custom text for "Read More" links:', 'birthday-cake'),
   'section'	=> 'birthday-settings',
   'type'	 => 'text',
   

) );

$wp_customize->add_setting( 'featured-images' , array(
      'default'     => 'featured-images-on',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'featured-images', array(
  'label' => __('Featured images on the top of posts:', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'featured-images',
  'type' => 'radio',
  'choices' => array(
    'featured-images-on' => __('On', 'birthday-cake'),
    'featured-iamges-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'page-featured-images' , array(
      'default'     => 'featured-images-on',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'page-featured-images', array(
  'label' => __('Featured images on pages:', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'page-featured-images',
  'type' => 'radio',
  'choices' => array(
    'featured-images-on' => __('On', 'birthday-cake'),
    'featured-iamges-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'center-images' , array(
      'default'     => 'center-images-off',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'center-images', array(
  'label' => __('Center all blog post images?', 'birthday-cake'),
  'description' => __('If you have an older or migrated site and your images are all over the place, select this option.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'center-images',
  'type' => 'radio',
  'choices' => array(
    'center-images-on' => __('On', 'birthday-cake'),
    'center-images-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'pinterest-share' , array(
      'default'     => 'pinterest-on',
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_radio'

  ) );

  $wp_customize->add_control( 'pinterest-share', array(
  'label' => __('Turn on Pinterest share buttons for blog post images?', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'pinterest-share',
  'type' => 'radio',
  'choices' => array(
    'pinterest-on' => __('On', 'birthday-cake'),
    'pinterest-off' => __('Off', 'birthday-cake'),
  ),
) );

$wp_customize->add_setting( 'comment-option' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'comment-option', array(
  'label' => __('Use a custom comment title?', 'birthday-cake'),
  'description' => __('Check this if you want to change "Leave a Reply" to something else. Type your custom text below. Your changes will appear after you save.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'comment-option',
  'type' => 'checkbox',

) );

$wp_customize->add_setting( 'custom-comment-text' , array(
      'default'     => __('Leave a Comment', 'birthday-cake'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( 'custom-comment-text', array(
   'label' => __('Custom Title', 'birthday-cake'),
   'section'	=> 'birthday-settings',
   'type'	 => 'text',
   

) );

$wp_customize->add_setting('header6', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header6',
            array(
                'label'   => __( '404 Page', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );
 

$wp_customize->add_setting( '404-page-title' , array(
      'default'     => __('Oops! Page Not Found', 'birthday-cake'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( '404-page-title', array(
   'label' => __('Custom title for 404 pages', 'birthday-cake'),
   'section'	=> 'birthday-settings',
   'type'	 => 'text',
   

) );

 $wp_customize->add_setting('404-image', array(
      'default'     => "",
      'transport'   => 'refresh',
      'sanitize_callback' => 'birthday_sanitize_file'
    ));
    
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, '404-image', array(
        'label' => __('Upload an image for the 404 page.', 'birthday-cake'),
        'description' => __('If the image is massive, please size it down before uploading.', 'birthday-cake'),
        'settings'  => '404-image',
        'section'   => 'birthday-settings',
    ) ));

$wp_customize->add_setting( '404-page-message' , array(
      'default'     => __('Sorry, the page you are looking for is not here.', 'birthday-cake'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( '404-page-message', array(
   'label' => __('Custom message for 404 pages', 'birthday-cake'),
   'section'	=> 'birthday-settings',
   'type'	 => 'textarea',

) );

$wp_customize->add_setting('header7', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header7',
            array(
                'label'   => __( 'Footer', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );
 
$wp_customize->add_setting( 'footer-text' , array(
      'default'     => __('Designed by Little Theme Shop', 'birthday-cake'),
      'transport'   => 'refresh',
      'sanitize_callback' => 'sanitize_text_field'
  ) );

  $wp_customize->add_control( 'footer-text', array(
   'label' => __('Custom footer text', 'birthday-cake'),
   'section'	=> 'birthday-settings',
   'type'	 => 'textarea',

) );

$wp_customize->add_setting( 'footer-url' , array(
      'default'     => 'https://littlethemeshop.com',
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_url'
  ) );

  $wp_customize->add_control( 'footer-url', array(
   'label' => __('Custom footer URL', 'birthday-cake'),
   'section'	=> 'birthday-settings',
   'type'	 => 'text',

) );

$wp_customize->add_setting('header8', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header8',
            array(
                'label'   => __( 'Privacy Policy', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );


$wp_customize->add_setting( 'privacy-policy' , array(
      'default'     => '/privacy-policy',
      'transport'   => 'refresh',
      'sanitize_callback' => 'esc_attr'
  ) );

  $wp_customize->add_control( 'privacy-policy', array(
   'label' => __('Your privacy policy URL. This will display on the contact form and the subscribe block.', 'birthday-cake'),
   'section'	=> 'birthday-settings',
   'type'	 => 'text',

) );


$wp_customize->add_setting('header9', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header9',
            array(
                'label'   => __( 'Miscellaneous', 'birthday-cake' ), // Set heading text here
                'section' => 'birthday-settings', // set section id here
            )
 ) );
 

$wp_customize->add_setting( 'lazy-option' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'lazy-option', array(
  'label' => __('Disable lazy loading images?', 'birthday-cake'),
  'description' => __('Check this if you are already running an optimization plugin. If you are unsure, just leave this alone.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'lazy-option',
  'type' => 'checkbox',

) );

	$wp_customize->add_setting( 'enable_under_maintenance', array(
		'default' 			=> '0',
		'sanitize_callback' => 'esc_attr'
	) );

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'enable_under_maintenance', array(
		'label'       		=> esc_attr__( 'Turn "Maintenance Mode" On?', 'birthday-cake' ),
		'section'     		=> 'birthday-settings',
		'settings'			=> 'enable_under_maintenance',
		'type'              => 'radio',
		'choices'           => array(
										'1' => esc_html__( 'Yes', 'birthday-cake' ),
									  	'0' => esc_html__( 'No', 'birthday-cake' ),
								   	),	
	) ) );

	$wp_customize->add_setting( 'enable_under_maintenance_pages', array(
		'default' 			=> '',
		'sanitize_callback' => 'esc_attr'
	) );


	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'enable_under_maintenance_pages', array(
		'label'       		=> esc_attr__( 'Select Page', 'birthday-cake' ),
		'description'       => __( 'Select the page you want visitors to see when your site is in maintenance mode. You can choose any page you want or use the "maintenance mode" page template that comes with this theme.', 'birthday-cake'),
		'section'     		=> 'birthday-settings',
		'settings'			=> 'enable_under_maintenance_pages',
		'type'             	=> 'dropdown-pages',
		'active_callback'   => 'under_construction_page_callback',
	) ));

	/* Custom Callback Functions */
	if ( ! function_exists( 'under_construction_page_callback' ) ) :
		function under_construction_page_callback( $control ) {
			if ( $control->manager->get_setting( 'enable_under_maintenance' )->value() == '1' ) {
		        return true;
		    } else {
		    	return false;
		    }
		}
	endif;

$wp_customize->add_setting('header10', array()); // dummy

$wp_customize->add_control( new Sub_Section_Heading_Custom_Control( 
            $wp_customize, 'header10',
            array(
                'label'   => __( 'Security', 'birthday-cake' ), // Set heading text here
                'description' => __('These settings are only recommended for single-author sites and are useful to avoid brute force attacks and attempted logins from bots.', 'birthday-cake'),
                'section' => 'birthday-settings', // set section id here
            )
 ) );
 
 $wp_customize->add_setting( 'user-link' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'user-link', array(
  'label' => __('Disable links to author pages?', 'birthday-cake'),
  'description' => __('Check this if you do not want your username to be linked to your author page.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'user-link',
  'type' => 'checkbox',

) );

 $wp_customize->add_setting( 'user-name' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'user-name', array(
  'label' => __('Turn off all usernames?', 'birthday-cake'),
  'description' => __('Check this if you do not want your username to be displayed on posts.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'user-name',
  'type' => 'checkbox',

) );

 $wp_customize->add_setting( 'user-redirect' , array(
      'default'     => false,
      'transport'   => 'refresh',
      
  ) );

  $wp_customize->add_control( 'user-redirect', array(
  'label' => __('Redirect author pages to the homepage?', 'birthday-cake'),
  'description' => __('Select this if you do not want bots to have access to yourdomain.com/author/username.', 'birthday-cake'),
  'section' => 'birthday-settings',
  'settings' => 'user-redirect',
  'type' => 'checkbox',

) );
	
}	

function google_callback( $control ) {
   if ( $control->manager->get_setting('google-fonts')->value() == 'google-fonts-on' ) {
      return true;
   } else {
      return false;
   }
}
function split_callback( $control ) {
   if ( $control->manager->get_setting('header-layout')->value() == 'header-divided' ) {
      return true;
   } else {
      return false;
   }
}
function related_callback( $control ) {
   if ( $control->manager->get_setting('related-posts')->value() == 'related-posts-on' ) {
      return true;
   } else {
      return false;
   }
}

/**
 * Customizer settings for social links that appear in the menu/footer
 */
	
function birthday_add_social_sites_customizer($wp_customize) {

 
	$wp_customize->add_section( 'birthday_social_settings', array(
			'title'    => __('Social Media Icons', 'birthday-cake'),
			'priority' => 35,
			'panel' => 'birthday_panel',
	) );
 
	$social_sites = birthday_customizer_social_media_array();
	$priority = 5;
 
	foreach($social_sites as $social_site) {
 
		$wp_customize->add_setting( "$social_site", array(
				'type'              => 'theme_mod',
				'capability'        => 'edit_theme_options',
				'sanitize_callback' => 'esc_attr'
		) );
 
		$wp_customize->add_control( $social_site, array(
				'label'    => __( "$social_site url:", 'birthday-cake' ),
				'section'  => 'birthday_social_settings',
				'type'     => 'text',
				'priority' => $priority,
		) );
 
		$priority = $priority + 5;
	}
}

/* takes user input from the customizer and outputs linked social media icons */
function birthday_social_media_icons() {
 
    $social_sites = birthday_customizer_social_media_array();
 
    /* any inputs that aren't empty are stored in $active_sites array */
    foreach($social_sites as $social_site) {
        if( strlen( get_theme_mod( $social_site ) ) > 0 ) {
            $active_sites[] = $social_site;
        }
    }
 
    /* for each active social site, add it as a list item */
        if ( ! empty( $active_sites ) ) {
 
            echo "<ul class='social-media-icons'>";
 
            foreach ( $active_sites as $active_site ) {
 
	            /* setup the class */
		        $class = 'fa fa-' . $active_site;
 
                if ( $active_site == 'email' ) {
                    ?>
                    <li>
                        <a class="email" target="_blank" href="mailto:<?php echo antispambot( is_email( get_theme_mod( $active_site ) ) ); ?>">
                            <i class="fa fa-envelope" title="<?php _e('email icon', 'birthday-cake'); ?>"></i>
                        </a>
                    </li>
                <?php } else { ?>
                    <li>
                        <a class="<?php echo $active_site; ?>" target="_blank" href="<?php echo esc_url( get_theme_mod( $active_site) ); ?>">
                            <i class="<?php echo esc_attr( $class ); ?>" title="<?php printf( __('%s icon', 'birthday-cake'), $active_site ); ?>"></i>
                        </a>
                    </li>
                <?php
                }
            }
            echo "</ul>";
        }
	}

add_action( 'customize_register', 'birthday_customizer_settings' );

add_action( 'customize_register', 'birthday_add_social_sites_customizer' );
