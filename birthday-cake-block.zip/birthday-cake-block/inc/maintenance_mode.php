<?php
/**
 * Function for "Under Construction" option in the Customizer.
 */


if ( ! function_exists( 'birthdayc_get_address' ) ) {
    function birthdayc_get_address() {
        // return the full address
        return birthdayc_get_protocol().'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    } // end function birthdayc_get_address
}

if ( ! function_exists( 'birthdayc_get_protocol' ) ) {
    function birthdayc_get_protocol() {
        // Set the base protocol to http
        $birthdayc_protocol = 'http';
        // check for https
        if ( isset( $_SERVER["HTTPS"] ) && strtolower( $_SERVER["HTTPS"] ) == "on" ) {
            $birthdayc_protocol .= "s";
        }
        
        return $birthdayc_protocol;
    } // end function birthdayc_get_protocol
}

add_action( 'template_redirect', 'birthdayc_force_under_construction' );
if ( ! function_exists( 'birthdayc_force_under_construction' ) ) {
    function birthdayc_force_under_construction() {

        $birthdayc_userrequest = str_ireplace( home_url('/'), '', birthdayc_get_address() );
        $birthdayc_userrequest = rtrim( $birthdayc_userrequest, '' );
        $birthdayc_enable_under_maintenance = get_theme_mod( 'enable_under_maintenance', 0 );
        if ( $birthdayc_enable_under_maintenance == 1 && !current_user_can( 'level_10' ) && get_theme_mod( 'enable_under_maintenance_pages' ) != '0' ) { 
            $birthdayc_do_redirect = '';
            if( get_option( 'permalink_structure' ) ){
                $get_page = get_page_uri( get_theme_mod( 'enable_under_maintenance_pages' ) );
                $birthdayc_do_redirect = '/'.$get_page;

                // Make sure it gets all the proper decoding and rtrim action
                $birthdayc_userrequest = str_replace( '*', '(.\*)', $birthdayc_userrequest );
                $birthdayc_pattern = '/^' . str_replace( '/', '\/', rtrim( $birthdayc_userrequest, '/' ) ) . '/';
                $birthdayc_do_redirect = str_replace( '*', '$1', $birthdayc_do_redirect );
                $output = preg_replace( $birthdayc_pattern, $birthdayc_do_redirect, $birthdayc_userrequest );
                if ( $output !== $birthdayc_userrequest ) {
                    // pattern matched, perform redirect
                    $birthdayc_do_redirect = $output;
                }

            } else {
                //echo get_theme_mod('enable_under_maintenance_pages');die;
                $birthdayc_getpost = get_page_uri( get_theme_mod( 'enable_under_maintenance_pages' ) );
                if ($birthdayc_getpost) {
                    $birthdayc_do_redirect = '/?page_id='.get_theme_mod( 'enable_under_maintenance_pages' );
                }
            }
            
            
            if( $birthdayc_do_redirect !== '' && trim( $birthdayc_do_redirect, '/' ) !== trim( $birthdayc_userrequest, '/' ) ) {
                // check if destination needs the domain prepended

                if( strpos( $birthdayc_do_redirect, '/' ) === 0 ) {
                    $birthdayc_do_redirect = home_url('/').$birthdayc_do_redirect;
                }

                header ( 'Location: ' . $birthdayc_do_redirect );
                exit();
                
            }
        }
    }
}


 /* Adds "Under Construction" notice to admin bar */
if ( ! function_exists( 'birthdayc_admin_bar_under_construction_notice' ) ) {
    function birthdayc_admin_bar_under_construction_notice() {
        global $wp_admin_bar;
        $birthdayc_enable_under_maintenance = get_theme_mod('enable_under_maintenance', 0 );
        if ( $birthdayc_enable_under_maintenance == 1 ) {
            $wp_admin_bar->add_menu( array(
                'id'     => 'admin-bar-under-construction-notice',
                'parent' => 'top-secondary',
                'href'   => esc_url( home_url( '/' ) ).'wp-admin/customize.php?autofocus%5Bsection%5D=add_under_maintenance_section',
                'title'  => '<span style="color: #FF0000;">'.esc_html__( 'Under Construction', 'birthday-cake' ).'</span>'
            ) );
        }
    }
}
add_action( 'admin_bar_menu', 'birthdayc_admin_bar_under_construction_notice' );