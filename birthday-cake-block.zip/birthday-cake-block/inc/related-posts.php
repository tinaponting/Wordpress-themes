<?php 
/**
 * Function for "related posts."
 */

function related_posts() { ?>

<div class="relatedposts">


<?php if( get_theme_mod( 'related_posts_control', 'tags' ) == 'categories' ) : ?>

<?php
 
  global $post;
  $orig_post = $post;
  $categories = get_the_category($post->ID);
   
  if ($categories) {
  $category_ids = array();
  foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
  $args=array(
  'category__in' => $category_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>4, // Number of related posts to display.
  'ignore_sticky_posts'=>1
  );
   $title = __('Related Posts', 'birthday-cake');
   $success = "<h3>{$title}</h3>";      
   
  $my_query = new wp_query( $args );
 
  if ( $my_query->have_posts() ) {
  echo $success; }

  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>
  
  
   
  <div class="relatedthumb"><div class="thumb-container">
     <a rel="external" href="<?php echo esc_url( get_permalink() );?>"><?php has_post_thumbnail(); the_post_thumbnail( 'medium', [ 'class' => 'lazyload', 'alt' => esc_html ( get_the_title() ) ] ); ?></div>
 		<?php the_title(); ?> 
 	 </a>
  </div>
  
   
  <?php }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>
</div>

 <?php else : ?>

  <?php
 
  global $post;
  $orig_post = $post;
  $tags = wp_get_post_tags($post->ID);
   
  if ($tags) {
  $tag_ids = array();
  foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
  $args=array(
  'tag__in' => $tag_ids,
  'post__not_in' => array($post->ID),
  'posts_per_page'=>4, // Number of related posts to display.
  'ignore_sticky_posts'=>1
  );
   $title = __('Related Posts', 'birthday-cake');
   $success = "<h3>{$title}</h3>";      
   
  $my_query = new wp_query( $args );
 
  if ( $my_query->have_posts() ) {
  echo $success; }

  while( $my_query->have_posts() ) {
  $my_query->the_post();
  ?>
  
  
   
  <div class="relatedthumb"><div class="thumb-container">
     <a rel="external" href="<?php echo esc_url( get_permalink() );?>"><?php has_post_thumbnail(); the_post_thumbnail( 'medium', [ 'class' => 'lazyload', 'alt' => esc_html ( get_the_title() ) ] ); ?></div>
 		<?php the_title(); ?> 
 	 </a>
  </div>
  
   
  <?php }
  }
  $post = $orig_post;
  wp_reset_query();
  ?>
</div>

<?php endif; ?>


<?php }