<?php
/**
*Social Share Buttons for blog posts.
*/

function get_the_post_thumbnail_src($img)
{
  return (preg_match('~\bsrc="([^"]++)"~', $img, $matches)) ? $matches[1] : '';
}
function birthday_cake_social_buttons() {
    global $post;
     
        $sb_url = urlencode(get_permalink());

        $sb_title = str_replace( ' ', '%20', get_the_title());
        
        $sb_thumb = get_the_post_thumbnail_src(get_the_post_thumbnail());
 
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$sb_title.'&amp;url='.$sb_url;
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$sb_url;
        $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$sb_url.'&amp;title='.$sb_title;

       if(!empty($sb_thumb)) {
            $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;media='.esc_url($sb_thumb).'&amp;description='.$sb_title;
        }
        else {
            $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
        }
 
         $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;media='.esc_url($sb_thumb).'&amp;description='.$sb_title;
       
         $content = "";
        $content .= '<div class="social-box"><div class="social-btn">';
        $content .= '<a class="col-1 sbtn s-twitter" href="'.esc_url($twitterURL).'" target="_blank" rel="nofollow"><i class="fa fa-twitter"></i></a>';
        $content .= '<a class="col-1 sbtn s-facebook" href="'.esc_url($facebookURL).'" target="_blank" rel="nofollow"><i class="fa fa-facebook"></i></a>';
        $content .= '<a class="col-2 sbtn s-pinterest" href="'.esc_url($pinterestURL).'" data-pin-custom="true" target="_blank" rel="nofollow"><i class="fa fa-pinterest"></i></a>';
        $content .= '<a class="col-2 sbtn s-linkedin" href="'.esc_url($linkedInURL).'" target="_blank" rel="nofollow"><i class="fa fa-linkedin"></i></a>';
        $content .= '</div></div>';
        echo $content;
        
  }  
    