<?php
/**
 /* Admin page that gives instruction to the user.
*/


function birthday_admin_page(){
$welcome_img = get_template_directory_uri() . '/images/bc-header.jpg';
$welcome_url = 'https://littlethemeshop.com/documentation/birthday-cake-block';
$import_url = 'https://littlethemeshop.com/documentation/importing-demo-content-block/';
	?>
	<div class="welcome-wrap">
		<img src="<?php echo $welcome_img; ?>">
		<h1><?php esc_html_e('Getting Started', 'birthday-cake'); ?></h1>
		 	
		 	<p><?php esc_html_e('Hey, there! Thanks for downloading Birthday Cake. Ready to build your cute website? Here&#39;s how to set up your new theme in minutes. If you don&#39;t want to watch the video below, there are written instructions listed below it.', 'birthday-cake'); ?></p>

<iframe style="margin:0 auto;display:block;" width="560" height="315" src="https://www.youtube.com/embed/32DEnDJl65Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
 		
 		<p><strong><?php esc_html_e('Step 1:', 'birthday-cake'); ?></strong>
            <?php esc_html_e( 'Activate plugins: Once the theme is activated, you should get a pop-up notifying you which plugins need to be downloaded and activated. If you don’t get a popup, simply click on "Install Plugins" under "Appearance." This theme requires the Little Homepage Blocks plugin. WooCommerce is recommended but optional', 'birthday-cake'); ?>
        </p>
         <p><strong><?php esc_html_e('Step 2:', 'birthday-cake'); ?></strong>
            <?php esc_html_e( 'Import demo content: If you want to import demo content, activate the "One Click Demo Import" plugin in Step 1 and click on "Import Demo Data" under "Appearance" in your dashboard.', 'birthday-cake'); ?>
                <?php printf(
   				 esc_html__( 'For more information on importing, read %1$s.', 'birthday-cake' ),
   				 sprintf(
					'<a href="%s">%s</a>',
        			$import_url,
        			esc_html__( 'Importing Demo Data', 'birthday-cake' )
       				 )
   				 ); ?></p>
                <p><strong><?php _e('Step 3:', 'birthday-cake'); ?></strong>
                    <?php esc_html_e( 'If you skipped Step 2, that&#39;s OK. Activating the homepage manually is just as easy:', 'birthday-cake'); ?>
                </p>
                <ol>
                	<li><?php esc_html_e( 'Create two new pages by clicking on "Pages" and "Add New." Name them anything, but ideally, name one “My Homepage” and the other “Blog.”', 'birthday-cake'); ?></li>
                	<li><?php esc_html_e( 'While editing the “My Homepage” page you just created, in the righthand sidebar locate Templates. From the dropdown menu, select Homepage Blocks. Save.', 'birthday-cake'); ?></li>
                	<li><?php esc_html_e( 'Next, go to "Settings" and click on "Reading". From here, click on “A static page” under “Homepage Settings.” For “Homepage,” select the page you just created and do the same thing for “Posts Page.” Save changes when you’re done.', 'birthday-cake'); ?></li>
        		</ol>
        <p><strong><?php _e('Step 4:', 'birthday-cake'); ?></strong>
            <?php esc_html_e( 'Start Building the Homepage: While viewing your homepage, click on "Edit Page" at the top in the black admin bar. From here, you can start building your page by adding blocks. For site-wide options (like colors, menu layout, etc.), those can be found under Appearance > Customize > Birthday Cake Options.', 'birthday-cake'); ?></p>

           <p><?php printf(
   				 esc_html__( 'If you have any other questions, make sure to read the %1$s.', 'birthday-cake' ),
   				 sprintf(
					'<a href="%s">%s</a>',
        			$welcome_url,
        			esc_html__( 'documentation', 'birthday-cake' )
       				 )
   				 ); ?></p>
	</div>
	<?php
}

