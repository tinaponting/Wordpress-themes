<?php
/**
 * Template Name: Big Poster w/ No Sidebar
 * Template Post Type: post
 */


get_header();
?>

	<?php
		while ( have_posts() ) :
			the_post(); ?>
			
	<?php birthday_cake_post_thumbnail(); ?>

<div id="primary" class="content-area">

	<main id="main" class="site-main">
	
		<style type="text/css"> .star-rating { display: none !important; } </style>

			<?php get_template_part( 'template-parts/content-poster', get_post_type() );

			the_post_navigation( array(
					'in_same_term' => true,
					'taxonomy' => 'category',
					));

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>
		
	</main><!-- #main -->
					
</div><!-- #primary -->
	
<?php get_footer();
