<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Birthday_Cake
 */

get_header();
?>

    <div id="primary" class="content-area <?php echo get_theme_mod('sidebar-layout-options', 'sidebar-right'); ?>">

        <main id="main" class="site-main">
			<a id="content"></a>
            <header class="page-header">
                <span class="cute-top"></span>
                <?php if (is_author() ) { ?>
                    <h1 class="page-title"><?php the_author_meta( 'display_name'); ?></h1>
                    <div class="author-description"><?php echo esc_html( get_the_author_meta( 'description' ) ); ?></div>
				<?php } elseif (is_tag() ) { ?>
                <?php single_term_title( '<h1 class="page-title">', '</h1>' ); the_archive_description( '<div class="archive-description">', '</div>' ); ?>
                <?php } elseif (is_category() ) { 
                
                $category = get_category(get_queried_object_id());
if ( $category->category_parent > 0 ) {

 $term = get_queried_object();
     $parent_category = get_term( $category->parent );

echo '<h1 class="page-title"><a href="' . esc_url( get_category_link($parent_category->term_id)) . '">' . esc_html($parent_category->name) . ' </a></h1>';
   $children = get_terms( [
    'taxonomy'   => $term->taxonomy,
    'parent'     => $term->parent,
    'hide_empty' => false
] );
echo '<p class="subcategories">';

        foreach( $children as $subcat )
        {
            echo '<a href="' . esc_url(get_term_link($subcat, $subcat->taxonomy)) . '">' . $subcat->name . '</a> ';
        }
    echo '</p>';    
  } 
  
  else {

$terms = get_terms([
    'taxonomy' => get_queried_object()->taxonomy,
    'parent'   => get_queried_object_id(),
]);

single_term_title( '<h1 class="page-title">', '</h1>' );

echo '</h1><p class="subcategories">';
foreach ( $terms as $term) {
    echo '<a href="' . get_term_link( $term ) . '">' . $term->name . '</a> ';  
}
echo '</p>';

the_archive_description( '<div class="archive-description">', '</div>' );
  
  }     
?>

 
                
                <?php } else { ?>
                	<?php the_archive_title( '<h1 class="page-title search-result">', '</h1>' );
						the_archive_description( '<div class="archive-description">', '</div>' );
						?>
                <?php } ?>
            </header>
            <!-- .page-header -->
			

            <div class="posts-grid <?php echo get_theme_mod('blog-layout-options', 'posts-grid-columns-2'); ?>">
                <?php if ( have_posts() ) : ?>

                    <?php /* Start the Loop */ while ( have_posts() ) : the_post(); 
                    
                    /* * Include the Post-Type-specific template for the content. 
                    * If you want to override this in a child theme, then include a file * called content-___.php 
                    (where ___ is the Post Type name) and that will be used instead. */ 
                    
                    get_template_part( 'template-parts/content-category', get_post_type() ); 
                    
                    endwhile; the_posts_navigation(); 
                    
                    	else : get_template_part( 'template-parts/content-none', 'none' ); 
                    
                    endif; ?>

            </div>
        </main>
        <!-- #main -->

        <?php get_sidebar(); ?>

    </div>
    <!-- #primary -->

        <?php get_footer();