<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Birthday_Cake
 */

get_header();
?>
<a id="content"></a>
<div id="primary" class="content-area <?php echo get_theme_mod('sidebar-layout-options', 'sidebar-right'); ?>">
    <main id="main" class="site-main">
        <div class="posts-grid <?php echo get_theme_mod('blog-layout-options', 'posts-grid-columns-2'); ?>">
			
<?php $sticky = get_option( 'sticky_posts' );
 	$args = array(
    'posts_per_page' => 1,
    'post__in' => $sticky,
    'ignore_sticky_posts' => 1
	);
	
	// Custom query.
	$query = new WP_Query( $args );
 
	// Check that we have query results.
	if ( $query->have_posts() ) {
 
    // Start looping over the query results.
    while ( $query->have_posts() ) {
 	 $query->the_post(); $do_not_duplicate[] = $post->ID;
 		if(!is_paged()) {

		get_template_part( 'template-parts/content-sticky', get_post_type() );
			 }
		}
	}
		$args = array( 'post_type' => 'post', 'post__not_in' => $do_not_duplicate, 'paged' => get_query_var( 'paged' ) );
   	    $wp_query = new WP_Query($args);
         if ( have_posts() ) : while ( have_posts() ) : the_post(); 
         
			get_template_part( 'template-parts/content-category', get_post_type() );
			
			endwhile; wp_reset_postdata();
            
            the_posts_navigation(); else : get_template_part( 'template-parts/content-none', 'none' ); 
            	
            endif; ?>


        </div>
    </main>
    <!-- #main -->
    <!-- #primary -->

    <?php get_sidebar(); ?>
    
</div>


<?php get_footer();