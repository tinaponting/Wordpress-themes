<?php
/**
 * The header for the theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Birthday_Cake
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
	

</head>

<?php $backclass = get_theme_mod( 'background-options', 'background-triangles' ); ?>


<body <?php body_class( $backclass ); ?>>
<?php wp_body_open(); ?>


<div id="full-screen-search">
			<button type="button" class="close" id="full-screen-search-close">X</button>
			<form role="search" method="get" action="<?php echo home_url( '/' ); ?>" id="full-screen-search-form">
				<div id="full-screen-search-container">
					<input type="text" name="s" placeholder="<?php _e( 'Search!', 'birthday-cake' ); ?>" id="full-screen-search-input" />
				</div>
			</form>
</div>

<?php if(is_front_page() ) { ?>
<div id="page" class="site-home">
<?php } else { ?>
<div id="page" class="site">
<?php } ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'birthday-cake' ); ?></a>

<?php if( get_theme_mod( 'header-layout', 'header-left' ) == 'header-divided' ) : ?>

<?php include( get_template_directory() . '/header-divided.php'); ?>

<?php else : ?>

<?php include( get_template_directory() . '/header-og.php'); ?>

<?php endif; ?>
