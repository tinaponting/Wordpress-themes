<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Birthday_Cake
 */

?>

    <article id="post-<?php the_ID(); ?>" class="sticky" <?php post_class(); ?>>

        <div class="post-thumbnail">
			<?php has_post_thumbnail(); the_post_thumbnail( 'large', [ 'alt' => esc_html ( get_the_title() ) ] ); ?>
		</div>

            <header class="entry-header">
            
                <div class="cat-head">
                
                <?php if (has_category() ) { ?>
                
                    <?php $category = get_the_category(); 
						echo '<a href="'.esc_url( get_category_link($category[0]->cat_ID) ).'"> '.$category[0]->cat_name.' </a>'; ?>
					<?php } ?>
				</div>
                		
                	<h2 class="sticky-title"><a href="<?php echo esc_url( get_permalink() );?>"><?php the_title(); ?></a></h2>
                	<p><?php echo get_the_excerpt(); ?></p>
                	<a class="more-link" href="<?php echo esc_url( get_permalink() );?>"><?php echo get_theme_mod( 'read-more-text', esc_html__('Read More', 'birthday-cake') ) ?></a>
            </header>
          
    </article>
    <!-- #post-<?php the_ID(); ?> -->