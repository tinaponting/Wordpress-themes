<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Birthday_Cake
 */

?>

<div class="page-layout">

    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

     <?php if( get_theme_mod( 'page-featured-images', 'featured-images-on' ) == 'featured-images-on' ) : ?>

		<?php birthday_cake_post_thumbnail(); ?>
	
	 <?php endif; ?>

             <div class="entry-content">

                <header class="entry-page-header">
                
                    <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                    <?php if ( has_excerpt() ) { ?>
                    <?php the_excerpt(); ?>
                    <?php } ?>
                            
                </header>
                            <!-- .entry-header -->

<?php
		the_content( sprintf(
			wp_kses(
				/* translators: %s: Name of current post. Only visible to screen readers */
				__( '%s <span class="screen-reader-text"> "%s"</span>', 'birthday-cake' ),
				array(
					'span' => array(
						'class' => array(),
					),
				)
			),
			get_theme_mod( 'read-more-text', esc_html__('Read More', 'birthday-cake') ),
			get_the_title()
		) );

		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'birthday-cake' ),
			'after'  => '</div>',
		) );
		?>
              </div> <!-- .entry-content -->


     </article> <!-- #post -->
     
 </div>