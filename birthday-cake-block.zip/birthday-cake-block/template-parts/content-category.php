<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Birthday_Cake
 */

?>


<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php birthday_cake_post_thumbnail(); ?>

	 <div class="entry-meta">
            <?php if (has_category() ) { ?>
                <?php $category = get_the_category(); 
			echo '<a href="'.esc_url( get_category_link($category[0]->cat_ID) ).'"> '.$category[0]->cat_name.' </a>'; ?> &#10148; <?php } ?>
                    <?php echo get_the_date(); ?>
            </div>
	
		<h2 class="grid-title">
	
			<a href="<?php echo esc_url( get_permalink() );?>"><?php the_title(); ?></a>
		</h2>
	
	<?php if( get_theme_mod( 'turn-off-everything', 'turn-on-everything' ) == 'turn-on-everything' ) : ?>

	<p class="grid-excerpt"><?php echo get_the_excerpt(); ?></p> 
	
	<a class="grid-more-link" href="<?php echo esc_url( get_permalink() );?>"><?php echo get_theme_mod( 'read-more-text', esc_html__('Read More', 'birthday-cake') ) ?></a>
	
	<?php if( get_theme_mod( 'social-share-buttons', 'social-share-on' ) == 'social-share-on' ) : ?>

	<?php birthday_cake_social_buttons(); ?>
	
					<?php endif; ?>
			<?php endif; ?>


</article><!-- #post-<?php the_ID(); ?> -->
