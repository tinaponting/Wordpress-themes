<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Birthday_Cake
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header" style="padding-top:50px;">
	
		<div class="cat-head">
		  <?php if (has_category() ) { ?>
                <?php $category = get_the_category(); 
			echo '<a href="'.esc_url( get_category_link($category[0]->cat_ID) ).'"> '.$category[0]->cat_name.' </a>'; ?><?php } ?>
		</div>
		<?php
		if ( is_singular() ) :
			the_title( '<h1 class="entry-title">', '</h1>' );
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta">
				<?php
				birthday_cake_posted_on();
				birthday_cake_posted_by();
				?>
				  <i class="fa fa-comment"></i> <?php comments_popup_link( esc_html__('Leave a comment', 'birthday-cake'), esc_html__('1 comment', 'birthday-cake'),esc_html__('% comments', 'birthday-cake') ); ?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->


	<div class="entry-content little-homepage-container">
		<?php
		the_content( sprintf(
			wp_kses(
				/* translators: %s: Name of current post. Only visible to screen readers */
				__( '%s <span class="screen-reader-text"> "%s"</span>', 'birthday-cake' ),
				array(
					'span' => array(
						'class' => array(),
					),
				)
			),
			get_theme_mod( 'read-more-text', esc_html__('Read More', 'birthday-cake') ),
			get_the_title()
		) );

		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'birthday-cake' ),
			'after'  => '</div>',
		) );
		?>
		
		
		
	</div><!-- .entry-content -->

	<footer class="entry-footer">
	<div class="flex-footer-container">
			<?php if( get_theme_mod( 'social-share-buttons', 'social-share-on' ) == 'social-share-on' ) : ?>

		<?php birthday_cake_social_buttons(); ?>
		
				<?php endif; ?>
				
			<?php if( get_theme_mod( 'blog-post-tags', 'blog-post-tags-on' ) == 'blog-post-tags-on' ) : ?>

		<?php birthday_cake_entry_footer(); ?>
						<?php endif; ?>

		</div>
		<?php if( get_theme_mod( 'related-posts', 'related-posts-on' ) == 'related-posts-on' ) : ?>

		<?php related_posts(); ?>
		
		<?php endif; ?>

	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
