<?php
/**
 * Birthday Cake functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Birthday_Cake
 */

if ( ! function_exists( 'birthday_cake_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function birthday_cake_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Birthday Cake, use a find and replace
		 * to change 'birthday-cake' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'birthday-cake', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'main-menu' => esc_html__( 'Primary', 'birthday-cake' ),
			'footer-menu' => esc_html__( 'Footer', 'birthday-cake' ),

		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	
	
			// Add support for default block styles.
		add_theme_support( 'wp-block-styles' );

			// Add support for full and wide align images.
		add_theme_support( 'align-wide' );

		add_theme_support( 'responsive-embeds' );
	
			// Add WooCommerce support
		add_theme_support( 'woocommerce' );
	
			// Add support for WooCommerce image gallery features
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
	
	
	}
endif;
add_action( 'after_setup_theme', 'birthday_cake_setup' );



/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function birthday_cake_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'birthday_cake_content_width', 1200 );
}
add_action( 'after_setup_theme', 'birthday_cake_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function register_widget_areas() {

		register_sidebar( array(
			'name'          => esc_html__( 'Sidebar', 'birthday-cake' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'birthday-cake' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
	) );
		register_sidebar( array(
            'name' => esc_html__( 'Store Page', 'birthday-cake' ),
            'id' => 'store',
            'description' => esc_html__( 'Add widgets here for product and shop page.', 'birthday-cake' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h2 class="widget-title">',
          	'after_title' => '</h2>'
        ) );

        
	}
	
	
add_action( 'widgets_init', 'register_widget_areas' );


/**
 * Allow pages to have categories so that they appear in the content slider.
 */
function reg_tax() {
        register_taxonomy_for_object_type('category', 'page');
        add_post_type_support('page', 'category');
    }
    
add_action('admin_init', 'reg_tax');
    

/**
 * Enqueue scripts and styles.
 */
function birthday_cake_scripts() {

	wp_enqueue_style( 'birthday-cake-style', get_template_directory_uri() . '/style.min.css', array(), NULL);
	
	wp_style_add_data( 'birthday-cake-style', 'rtl', 'replace' ); 
	
    if( !class_exists('Jetpack')) {
		
		if (get_theme_mod( 'lazy-option', false ) == false) {
		
			wp_enqueue_script( 'birthday-cake-js', get_template_directory_uri() . '/js/all.min.js', array(), NULL, true );
	
    }
    else {
	wp_enqueue_script( 'birthday-cake-js', get_template_directory_uri() . '/js/all-no-lazy.min.js', array(), NULL, true );
    }
 }
    
else {
	wp_enqueue_script( 'birthday-cake-js', get_template_directory_uri() . '/js/all-no-lazy.min.js', array(), NULL, true );
}

	global $is_IE;
	global $is_edge;
	if( $is_IE ) {
	wp_enqueue_style( 'birthday-cake-ie', get_template_directory_uri() . '/ie.css', array(), null );

	}	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

		if (!is_admin() ) {
	wp_deregister_script('jquery');
    wp_register_script( 'jquery', includes_url( '/js/jquery/jquery.min.js' ), false, NULL, true );
    wp_enqueue_script( 'jquery' );
	}

}

add_action( 'wp_enqueue_scripts', 'birthday_cake_scripts', 9999 );



function font_preload() {
                
                 echo '<link rel="preload" href="' . get_template_directory_uri() . '/fonts/Raleway/Raleway-Regular.woff" as="font" type="font/woff2" crossorigin="anonymous">';
                 echo '<link rel="preload" href="' . get_template_directory_uri() . '/fonts/Raleway/Raleway-ExtraBold.woff" as="font" type="font/woff2" crossorigin="anonymous">';
                 echo '<link rel="preload" href="' . get_template_directory_uri() . '/fonts/Permanent_Marker/PermanentMarker-Regular.woff2" as="font" type="font/woff2" crossorigin="anonymous">';
          
        }
        add_action('wp_head', 'font_preload', 0);


/**
*Add social share buttons to Woocommerce pages
*/
 
function woocommerce_social_icons() {
?>
    	  <?php birthday_cake_social_buttons(); ?>

    	<?php
}

add_action( 'woocommerce_share' , 'woocommerce_social_icons', 30 );


/**
* A fix to keep sticky posts where they belong. Sigh.
*/

add_action( 'pre_get_posts', function( $birthdaysticky ) 

{
    if ( $birthdaysticky->is_home() && $birthdaysticky->is_main_query() && $birthdaysticky->get( 'paged' ) > 1 )
        $birthdaysticky->set( 'post__not_in', get_option( 'sticky_posts' ) );

} );

/**
* Keeps the "testimonials" category out of the blog index.
*/

function cake_exclude_category( $query ) {
    if ( $query->is_home() ) {
        $query->set( 'tax_query', array(array('taxonomy' => 'category','field' => 'slug','terms' => array( 'testimonials', 'portfolio' ),'operator'=> 'NOT IN')));

    }
}

add_action( 'pre_get_posts', 'cake_exclude_category' );


/**
* The custom color CSS from the Customizer.
*/

function birthday_customizer_css() {

	if( get_theme_mod( 'google-fonts', 'google-fonts-off' ) == 'google-fonts-on' ) { ?>


   <style type="text/css">
@import url('https://fonts.googleapis.com/css?family=<?php echo urlencode(get_theme_mod('cake-google-header-fonts', 'Raleway')); ?>:<?php echo get_theme_mod('cake-google-header-bold', '400'); ?>|<?php echo urlencode(get_theme_mod('cake-google-script-font', 'Permanent Marker')); ?>|<?php echo urlencode(get_theme_mod('cake-google-body-fonts', 'Raleway')); ?>:400&display=swap'); h1, h2, h3, h4, h5, h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a { font-family: '<?php echo get_theme_mod('cake-google-header-fonts', 'Raleway'); ?>', sans-serif !important; } a, p, input { --primary-color: <?php echo get_theme_mod('primary-color', '#ef92a5'); ?>; font-family: '<?php echo get_theme_mod('cake-google-body-fonts', 'Raleway'); ?>', sans-serif; } <?php if( get_theme_mod( 'cake-google-script-switch', 'google-font-script-on' ) == 'google-font-script-on' ) { ?>.first-word, .little-widgets-profile-title, .wp-block-pullquote p, .little-widgets-hero-information h1.little-widgets-title { font-family: '<?php echo get_theme_mod('cake-google-script-font', 'Permanent Marker'); ?>', sans-serif !important; text-transform: capitalize; } <?php } else { ?>.first-word, .little-widgets-profile-title, .wp-block-pullquote p {font-family: '<?php echo get_theme_mod('cake-google-header-fonts', 'Raleway'); ?>' !important; } <?php } ?>body { --primary-color: <?php echo get_theme_mod('primary-color', '#ef92a5'); ?>; --accent-color: <?php echo get_theme_mod('accent-color', '#f0ed6f'); ?>; --link-primary-color: <?php echo get_theme_mod('link-primary-color', '#ffffff'); ?>; --link-accent-color: <?php echo get_theme_mod('link-accent-color', '#222222'); ?>; } <?php if( get_theme_mod( 'wide-logo', 'wide-logo-no' ) == 'wide-logo-yes' ) : ?>.custom-logo {max-width: 600px;} <?php endif; ?><?php if( get_theme_mod( 'center-images', 'center-images-off' ) == 'center-images-on' ) : ?>.entry-content img, .entry-content figure, figcaption { display: block !important; margin: 0 auto !important; float: none !important; } <?php endif; ?>
	</style>		

      <?php } else { ?>
      
         <style type="text/css">
body { --primary-color: <?php echo get_theme_mod('primary-color', '#ef92a5'); ?>; --accent-color: <?php echo get_theme_mod('accent-color', '#f0ed6f'); ?>; --link-primary-color: <?php echo get_theme_mod('link-primary-color', '#ffffff'); ?>; --link-accent-color: <?php echo get_theme_mod('link-accent-color', '#222222'); ?>; } <?php if( get_theme_mod( 'wide-logo', 'wide-logo-no' ) == 'wide-logo-yes' ) : ?>.custom-logo {max-width: 600px;} <?php endif; ?><?php if( get_theme_mod( 'center-images', 'center-images-off' ) == 'center-images-on' ) : ?>.entry-content img, .entry-content figure, figcaption { display: block !important; margin: 0 auto !important; float: none !important; } <?php endif; ?>
         </style>
    <?php
	}
}

function birthday_customizer_css_admin() {

	if( get_theme_mod( 'google-fonts', 'google-fonts-off' ) == 'google-fonts-on' ) { ?>


   <style type="text/css">
@import url('https://fonts.googleapis.com/css?family=<?php echo urlencode(get_theme_mod('cake-google-header-fonts', 'Raleway')); ?>:<?php echo get_theme_mod('cake-google-header-bold', '400'); ?>|<?php echo urlencode(get_theme_mod('cake-google-script-font', 'Permanent Marker')); ?>|<?php echo urlencode(get_theme_mod('cake-google-body-fonts', 'Raleway')); ?>:400&display=swap'); .editor-post-title, .editor-styles-wrapper h1, .editor-styles-wrapper h2, .editor-styles-wrapper h3, .editor-styles-wrapper h4, .editor-styles-wrapper h5, .editor-styles-wrapper h6, .editor-styles-wrapper h1 a, .editor-styles-wrapper h2 a, .editor-styles-wrapper h3 a, .editor-styles-wrapper h4 a, .editor-styles-wrapper h5 a, .editor-styles-wrapper h6 a { font-family: '<?php echo get_theme_mod('cake-google-header-fonts', 'Raleway'); ?>', sans-serif !important; } .editor-styles-wrapper a, .editor-styles-wrapper p, .editor-styles-wrapper input { --primary-color: <?php echo get_theme_mod('primary-color', '#ef92a5'); ?>; font-family: '<?php echo get_theme_mod('cake-google-body-fonts', 'Raleway'); ?>', sans-serif; } <?php if( get_theme_mod( 'cake-google-script-switch', 'google-font-script-on' ) == 'google-font-script-on' ) { ?>.first-word, .little-widgets-profile-title, .wp-block-pullquote p, .little-widgets-hero-information h1.little-widgets-title { font-family: '<?php echo get_theme_mod('cake-google-script-font', 'Permanent Marker'); ?>', sans-serif !important; text-transform: capitalize; } <?php } else { ?>.first-word, .little-widgets-profile-title, .wp-block-pullquote p {font-family: '<?php echo get_theme_mod('cake-google-header-fonts', 'Raleway'); ?>' !important; } <?php } ?>body { --primary-color: <?php echo get_theme_mod('primary-color', '#ef92a5'); ?>; --accent-color: <?php echo get_theme_mod('accent-color', '#f0ed6f'); ?>; --link-primary-color: <?php echo get_theme_mod('link-primary-color', '#ffffff'); ?>; --link-accent-color: <?php echo get_theme_mod('link-accent-color', '#222222'); ?>; } div.little-widget_widget_little_widgets_profile .little-widgets-profile-title { color: <?php echo get_theme_mod('about-widget-text-color'); ?>; } <?php if( get_theme_mod( 'wide-logo', 'wide-logo-no' ) == 'wide-logo-yes' ) : ?>.custom-logo {max-width: 600px;} <?php endif; ?><?php if( get_theme_mod( 'center-images', 'center-images-off' ) == 'center-images-on' ) : ?>.entry-content img, .entry-content figure, figcaption { display: block !important; margin: 0 auto !important; float: none !important; } <?php endif; ?>
	</style>		

      <?php } else { ?>
      
         <style type="text/css">
body { --primary-color: <?php echo get_theme_mod('primary-color', '#ef92a5'); ?>; --accent-color: <?php echo get_theme_mod('accent-color', '#f0ed6f'); ?>; --link-primary-color: <?php echo get_theme_mod('link-primary-color', '#ffffff'); ?>; --link-accent-color: <?php echo get_theme_mod('link-accent-color', '#222222'); ?>; } div.little-widget_widget_little_widgets_profile .little-widgets-profile-title { color: <?php echo get_theme_mod('about-widget-text-color'); ?>; } <?php if( get_theme_mod( 'wide-logo', 'wide-logo-no' ) == 'wide-logo-yes' ) : ?>.custom-logo {max-width: 600px;} <?php endif; ?><?php if( get_theme_mod( 'center-images', 'center-images-off' ) == 'center-images-on' ) : ?>.entry-content img, .entry-content figure, figcaption { display: block !important; margin: 0 auto !important; float: none !important; } <?php endif; ?>
         </style>
    <?php
	}
}

add_action( 'wp_head', 'birthday_customizer_css');
add_action( 'admin_head', 'birthday_customizer_css_admin' );

 
  

/** Filter excerpt length to 35 words. */

function birthday_custom_excerpt_length( $length ) {
return 35;
}
add_filter( 'excerpt_length', 'birthday_custom_excerpt_length', 999 );

/** Aaaand let's remove those ugly brackets while we're at it. **/

function pretty_excerpt_more( $more ) {
    return '...';
}
add_filter('excerpt_more', 'pretty_excerpt_more');


// trim excerpt whitespace
if ( !function_exists( 'mp_trim_excerpt_whitespace' ) ) {
  function mp_trim_excerpt_whitespace( $excerpt ) {
    return trim( $excerpt );
  }
  add_filter( 'get_the_excerpt', 'mp_trim_excerpt_whitespace', 1 );
}

/** Fallback for posts with no featured images set. */

function fallback_featured() {
          global $post;
          if ( empty( $post->ID ) ) { 

}
else {
          $already_has_thumb = has_post_thumbnail($post->ID);
              if (!$already_has_thumb)  {
              $attached_image = get_children( "post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=1" );
                 end($attached_image); 
                          if ($attached_image) {
                                foreach ($attached_image as $attachment_id => $attachment) {
                                set_post_thumbnail($post->ID, $attachment_id);
                                }
                           }
                        }
      } }
      
add_action('the_post', 'fallback_featured');
add_action('save_post', 'fallback_featured');
add_action('draft_to_publish', 'fallback_featured');
add_action('new_to_publish', 'fallback_featured');
add_action('pending_to_publish', 'fallback_featured');
add_action('future_to_publish', 'fallback_featured');


add_post_type_support( 'page', 'excerpt' );


/**
 * The auto-updater.
 */

require get_template_directory() . '/update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://littlethemeshop.com/updater/extrasugarextrasalt-block.json',
	__FILE__, 
	'birthday-cake-block',
	48 // <-- hours
);

/**
 * Add a "Birthday Cake" link in the admin menu.
 */
 
function birthday_admin_menu() {
	add_menu_page( __('Birthday Cake Menu', 'birthday-cake'), esc_html__('Birthday Cake', 'birthday-cake'), 'manage_options', 'birthday-welcome-page', 'birthday_admin_page', 'dashicons-smiley', 4  );
}
add_action( 'admin_menu', 'birthday_admin_menu', 9);

/**
 * Demo importer.
 */
 
require_once get_template_directory() . '/demo-import/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'birthday_cake_register_required_plugins' );
 
// Register the required plugins for this theme
function birthday_cake_register_required_plugins() {
    $plugins = array( 
        array(
            'name' => 'One Click Demo Import',
            'slug' => 'one-click-demo-import',
            'required' => true,
        ) ,
         array(
            'name' => 'Woocommerce',
            'slug' => 'woocommerce',
            'required' => false,
        ) ,
        
        array(
			'name'               => 'Little Homepage Blocks', // The plugin name.
			'slug'               => 'little-homepage-blocks', // The plugin slug (typically the folder name).
			'source'             => get_template_directory() . '/plugins/little-homepage-blocks.zip', // The plugin source.
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
    );
    $config = array(
        'id'           => 'tgmpa',       // Unique ID for hashing notices for multiple instances of TGMPA.
        'default_path' => '',                      // Default absolute path to bundled plugins.
        'menu'         => 'tgmpa-install-plugins', // Menu slug.
        'parent_slug'  => 'themes.php',            // Parent menu slug.
        'capability'   => 'manage_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
        'has_notices'  => true,                    // Show admin notices or not.
        'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
        'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => true,                    // Automatically activate plugins after installation or not.
        'message'      => '',                      // Message to output right before the plugins table.
    );
    tgmpa($plugins, $config);
} 



// Import all the files
function ocdi_import_files() {
    return array(
        array(
            'import_file_name'             => 'Demo Import',
            'local_import_file'            => trailingslashit( get_template_directory() ) . 'demo-import/birthday-cake-demo-content.xml',
            'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'demo-import/birthday-cake-demo.wie',
            'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'demo-import/birthday-cake-demo.dat',
            'import_preview_image_url'     => get_template_directory_uri() . '/screenshot.png',
            'import_notice'                => __( 'The import will take a few minutes. Do not close the window or refresh the page until the data is imported.', 'birthday-cake' ),
            'preview_url'                  => 'https://birthdaycake.littlethemeshop.com',
        ),

    );
}
add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );


function ocdi_after_import_setup() {
  $primary_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
  $footer_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
    set_theme_mod( 'nav_menu_locations', array(
		'main-menu' => $primary_menu->term_id,
		'footer-menu' => $footer_menu->term_id,
        )
    );

// Assign home page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Homepage Blocks' );
 	$posts_page_id = get_page_by_title( 'Blog' );
    update_option( 'show_on_front', 'page' );
    update_option( 'page_for_posts', $posts_page_id->ID );
    update_option( 'page_on_front', $front_page_id->ID );
}
add_action( 'pt-ocdi/after_import', 'ocdi_after_import_setup');

// Disable plugin branding
add_filter('pt-ocdi/disable_pt_branding', '__return_true');



/**
 * Optimize WooCommerce Scripts
 * Remove WooCommerce Generator tag, styles, and scripts from non WooCommerce pages.
 */
add_action( 'wp_enqueue_scripts', 'dequeue_woocommerce_styles_scripts', 99 );

function dequeue_woocommerce_styles_scripts() {
    if ( function_exists( 'is_woocommerce' ) ) {
        if ( ! is_woocommerce() && ! is_cart() && ! is_checkout() ) {
            # Styles
            wp_dequeue_style( 'woocommerce-general' );
            wp_dequeue_style( 'woocommerce-layout' );
            wp_dequeue_style( 'woocommerce-smallscreen' );
            wp_dequeue_style( 'woocommerce_frontend_styles' );
            wp_dequeue_style( 'woocommerce_fancybox_styles' );
            wp_dequeue_style( 'woocommerce_chosen_styles' );
            wp_dequeue_style( 'woocommerce_prettyPhoto_css' );
            wp_dequeue_style( 'woocommerce-general' );
            wp_dequeue_style( 'wc-block-vendors-style');
            wp_dequeue_style( 'wc-block-style');

            # Scripts
            wp_dequeue_script( 'wc_price_slider' );
            wp_dequeue_script( 'wc-single-product' );
            wp_dequeue_script( 'wc-add-to-cart' );
            wp_dequeue_script( 'wc-cart-fragments' );
            wp_dequeue_script( 'wc-checkout' );
            wp_dequeue_script( 'wc-add-to-cart-variation' );
            wp_dequeue_script( 'wc-single-product' );
            wp_dequeue_script( 'wc-cart' );
            wp_dequeue_script( 'wc-chosen' );
            wp_dequeue_script( 'woocommerce' );
            wp_dequeue_script( 'prettyPhoto' );
            wp_dequeue_script( 'prettyPhoto-init' );
            wp_dequeue_script( 'jquery-blockui' );
            wp_dequeue_script( 'jquery-placeholder' );
            wp_dequeue_script( 'fancybox' );
            wp_dequeue_script( 'jqueryui' );
        }
    }
}



function searchform( $form ) {
 
    $form = '<form role="search" method="get" id="searchform" action="' . home_url( '/' ) . '" >
    <div><label class="screen-reader-text" for="s">' . __('Search for:') . '</label>
    <input type="text" value="' . get_search_query() . '" name="s" id="s" />
    <input type="submit" id="searchsubmit" value="'. esc_attr__('Search') .'" />
    </div>
    </form>';
 
    return $form;
}
 
add_shortcode('searchform', 'searchform');


if (is_admin() && isset($_GET['activated'])){

    wp_redirect(admin_url("admin.php?page=birthday-welcome-page"));
}

add_filter( 'wp_lazy_loading_enabled', '__return_false' );



/**
 * Redirect Author Page.
 */
 
if( get_theme_mod( 'user-redirect', false ) == true ) {

add_action('template_redirect', 'lts_disable_author_page');

function lts_disable_author_page() {
    global $wp_query;

    if ( is_author() ) {
        // Redirect to homepage, set status to 301 permenant redirect. 
        // Function defaults to 302 temporary redirect. 
        wp_redirect(get_option('home'), 301); 
        exit; 
    	}
	}
} else {
 // nada
}

/**
 * The Welcome/Getting Started page in the admin menu.
 */
require_once get_template_directory() . '/inc/welcome.php';

/**
 * Implement the "Maintenance Mode" feature.
 */
require_once get_template_directory() . '/inc/maintenance_mode.php';

/**
 * Implement the share buttons feature.
 */
require_once get_template_directory() . '/inc/social-share-buttons.php';

/**
 * Add class and convert images for lazy loading, but disable all lazy loading for Jetpack users
 */

if( get_theme_mod( 'lazy-option', false ) == true OR is_admin() OR class_exists( 'Jetpack' ) ) {

 
add_filter( 'jetpack_lazy_images_blocked_classes', 'exclude_custom_logo_class_from_lazy_load', 999, 1 );
             
function exclude_custom_logo_class_from_lazy_load( $classes ) {
   $classes[] = 'custom-logo';
   return $classes;
}


function image_opacity() { ?>

<style type="text/css">

img, .lazyload {opacity:1;}

</style>

<?php }

function image_opacity_admin() { ?>

<style type="text/css">

img, .lazyload {opacity:1 !important;}

</style>

<?php }

add_action( 'wp_head', 'image_opacity');
add_action( 'admin_head', 'image_opacity_admin' );



} else { 

require_once get_template_directory() . '/inc/lazy-load-converter.php'; 

}

/**
 * Custom template tags for this theme.
 */
require_once get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require_once get_template_directory() . '/inc/template-functions.php';

/**
 * Functions for the divided menu layout.
 */
require_once get_template_directory() . '/inc/divided-menu.php';

/**
 * Functions for related posts.
 */
require_once get_template_directory() . '/inc/related-posts.php';

/**
 * Customizer options
 */
require_once get_template_directory() . '/inc/customizer.php';

/**
 * Implement the Custom Header feature.
 */
require_once get_template_directory() . '/inc/custom-header.php';



add_action( 'after_setup_theme', 'lts_gutenberg_css' );

function lts_gutenberg_css(){

add_theme_support('editor-styles');
add_editor_style( 'style.min.css' ); 

}

/**
 * Proper ob_end_flush() for all levels
 *
 * This replaces the WordPress `wp_ob_end_flush_all()` function
 * with a replacement that doesn't cause PHP notices.
 */
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );
add_action( 'shutdown', function() {
   while ( @ob_end_flush() );
} );


if( get_theme_mod( 'comment-option', false ) == true ) {

//change text to leave a reply on comment form
function lts_comment_reform ($arg) {
$arg['title_reply'] = __('' . get_theme_mod('custom-comment-text', 'Say Something!') . '');
return $arg;
}
add_filter('comment_form_defaults','lts_comment_reform');

} 